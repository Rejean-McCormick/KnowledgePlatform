/** @type { import('@storybook/react-webpack5').StorybookConfig } */
const config = {
  stories: [
    '../src/components/**/*.stories.@(js|jsx|ts|tsx)',  // Bulk import all stories from the components folder
    '../src/**/*.mdx',  // MDX stories for documentation
  ],
  addons: [
    '@storybook/preset-create-react-app',
    '@storybook/addon-onboarding',
    '@storybook/addon-links',
    '@storybook/addon-essentials',
    '@chromatic-com/storybook',
    '@storybook/addon-interactions',
  ],
  framework: {
    name: '@storybook/react-webpack5',
    options: {},
  },
  staticDirs: ['../public'],  // Updated static directory path for consistency
};

export default config;
