// /src/notifications/notificationService.js

const { getSocketServer } = require('../real-time/socketServer');
const logger = require('../utils/loggerService');

class NotificationService {
  constructor() {
    this.io = getSocketServer();
  }

  /**
   * Send a notification about a new vote.
   * @param {String} voteId - The ID of the new vote.
   * @param {Object} voteData - Details about the vote (e.g., vote options, context).
   */
  notifyNewVote(voteId, voteData) {
    try {
      this.io.emit('newVote', { voteId, voteData });
      logger.info(`Notification sent for new vote ${voteId}`);
    } catch (error) {
      logger.error(`Error notifying new vote: ${error.message}`);
    }
  }

  /**
   * Send a notification when a user's role changes.
   * @param {String} userId - The ID of the user whose role has changed.
   * @param {String} newRole - The new role assigned to the user.
   */
  notifyRoleChange(userId, newRole) {
    try {
      this.io.emit('roleChanged', { userId, newRole });
      logger.info(`Notification sent for role change of user ${userId} to ${newRole}`);
    } catch (error) {
      logger.error(`Error notifying role change for user ${userId}: ${error.message}`);
    }
  }

  /**
   * Send a notification when a user earns a new badge.
   * @param {String} userId - The ID of the user who earned a badge.
   * @param {String} badge - The badge that the user earned.
   */
  notifyBadgeAchievement(userId, badge) {
    try {
      this.io.emit('badgeAchievement', { userId, badge });
      logger.info(`Notification sent for user ${userId} earning badge ${badge}`);
    } catch (error) {
      logger.error(`Error notifying badge achievement for user ${userId}: ${error.message}`);
    }
  }
}

module.exports = new NotificationService();
