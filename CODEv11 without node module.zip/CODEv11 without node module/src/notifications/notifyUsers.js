// /src/notifications/notifyUsers.js

const { getSocketServer } = require('../real-time/socketServer');
const logger = require('../utils/loggerService');

class NotifyUsers {
  constructor() {
    this.io = getSocketServer();
  }

  /**
   * Send a notification to all users about vote results.
   * @param {String} voteId - The ID of the vote.
   * @param {Object} voteResults - The final results of the vote.
   */
  notifyVoteResults(voteId, voteResults) {
    try {
      this.io.emit('voteResults', { voteId, voteResults });
      logger.info(`Vote results notification sent for vote ${voteId}`);
    } catch (error) {
      logger.error(`Error sending vote results notification for vote ${voteId}: ${error.message}`);
    }
  }

  /**
   * Send a notification when a user earns a new badge.
   * @param {String} userId - The ID of the user.
   * @param {String} badge - The badge awarded to the user.
   */
  notifyBadgeUpdate(userId, badge) {
    try {
      this.io.emit('badgeUpdate', { userId, badge });
      logger.info(`Badge update notification sent for user ${userId} with badge ${badge}`);
    } catch (error) {
      logger.error(`Error sending badge update for user ${userId}: ${error.message}`);
    }
  }

  /**
   * Notify users of other platform-wide events.
   * @param {String} eventTitle - The title of the event.
   * @param {Object} eventData - Additional data about the event.
   */
  notifyPlatformEvent(eventTitle, eventData) {
    try {
      this.io.emit('platformEvent', { eventTitle, eventData });
      logger.info(`Platform-wide event notification sent: ${eventTitle}`);
    } catch (error) {
      logger.error(`Error sending platform event notification: ${error.message}`);
    }
  }
}

module.exports = new NotifyUsers();
