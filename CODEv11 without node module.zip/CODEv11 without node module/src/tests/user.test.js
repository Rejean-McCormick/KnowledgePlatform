const { getUserProfile, updateUserRole, assignBadge } = require('../src/services/userService');
const { User } = require('../src/models/User');

jest.mock('../src/models/User'); // Mock the User model

describe('User Service Unit Tests', () => {

  // Test user profile retrieval
  describe('getUserProfile', () => {
    test('should return user profile for a valid user ID', async () => {
      const mockUserProfile = {
        id: 1,
        username: 'testuser',
        email: 'testuser@example.com',
        role: 'student',
        badges: ['early_adopter'],
      };

      User.findById.mockResolvedValue(mockUserProfile);

      const userProfile = await getUserProfile(1);

      expect(userProfile).toHaveProperty('username', 'testuser');
      expect(userProfile).toHaveProperty('role', 'student');
      expect(userProfile.badges).toContain('early_adopter');
    });

    test('should throw an error if user not found', async () => {
      User.findById.mockResolvedValue(null);

      await expect(getUserProfile(999)).rejects.toThrow('User not found');
    });
  });

  // Test user role updates
  describe('updateUserRole', () => {
    test('should update user role successfully', async () => {
      const mockUser = {
        id: 1,
        username: 'testuser',
        role: 'student',
        save: jest.fn(),
      };

      User.findById.mockResolvedValue(mockUser);

      await updateUserRole(1, 'specialist');

      expect(mockUser.role).toBe('specialist');
      expect(mockUser.save).toHaveBeenCalled();
    });

    test('should throw an error for invalid role', async () => {
      const mockUser = {
        id: 1,
        username: 'testuser',
        role: 'student',
        save: jest.fn(),
      };

      User.findById.mockResolvedValue(mockUser);

      await expect(updateUserRole(1, 'invalid_role')).rejects.toThrow('Invalid role');
    });

    test('should throw an error if user not found', async () => {
      User.findById.mockResolvedValue(null);

      await expect(updateUserRole(999, 'specialist')).rejects.toThrow('User not found');
    });
  });

  // Test badge assignment
  describe('assignBadge', () => {
    test('should assign a badge to the user', async () => {
      const mockUser = {
        id: 1,
        username: 'testuser',
        badges: [],
        save: jest.fn(),
      };

      User.findById.mockResolvedValue(mockUser);

      await assignBadge(1, 'contributor');

      expect(mockUser.badges).toContain('contributor');
      expect(mockUser.save).toHaveBeenCalled();
    });

    test('should not assign the same badge twice', async () => {
      const mockUser = {
        id: 1,
        username: 'testuser',
        badges: ['contributor'],
        save: jest.fn(),
      };

      User.findById.mockResolvedValue(mockUser);

      await assignBadge(1, 'contributor');

      expect(mockUser.badges.length).toBe(1); // Badge should not be added again
      expect(mockUser.save).not.toHaveBeenCalled(); // No save should be triggered
    });

    test('should throw an error if user not found', async () => {
      User.findById.mockResolvedValue(null);

      await expect(assignBadge(999, 'contributor')).rejects.toThrow('User not found');
    });
  });
});
