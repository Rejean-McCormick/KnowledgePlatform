const { weightedAverage, sum } = require('../src/utils/mathUtils');
const { calculateVoteWeight } = require('../src/services/voteWeighting');
const { getUserReputation } = require('../src/services/userMetrics');

describe('Unit Tests', () => {

  // Test vote weight calculation
  describe('Vote Weighting Service', () => {
    test('should calculate correct weighted average', () => {
      const values = [4, 3, 5];
      const weights = [2, 1, 3];
      const result = weightedAverage(values, weights);
      expect(result).toBeCloseTo(4.33, 2);
    });

    test('should return the sum of an array of numbers', () => {
      const numbers = [1, 2, 3, 4];
      const result = sum(numbers);
      expect(result).toEqual(10);
    });

    test('should calculate vote weight based on user metrics', () => {
      const userMetrics = {
        reputation: 80,
        influenceScore: 50,
        ethicalStanding: 90
      };
      const result = calculateVoteWeight(userMetrics);
      expect(result).toBeGreaterThan(1);
      expect(result).toBeLessThanOrEqual(10);
    });
  });

  // Test user metrics calculation
  describe('User Metrics Service', () => {
    test('should calculate user reputation correctly', () => {
      const votes = [
        { issue: 'Issue 1', reputationImpact: 10 },
        { issue: 'Issue 2', reputationImpact: 5 },
        { issue: 'Issue 3', reputationImpact: 15 },
      ];
      const result = getUserReputation(votes);
      expect(result).toEqual(30);
    });

    test('should return zero for user with no votes', () => {
      const votes = [];
      const result = getUserReputation(votes);
      expect(result).toEqual(0);
    });
  });

  // Test edge cases and error handling
  describe('Error Handling', () => {
    test('should handle empty weights array for weighted average', () => {
      const values = [4, 3, 5];
      const weights = [];
      expect(() => weightedAverage(values, weights)).toThrowError('Weights array cannot be empty');
    });

    test('should handle invalid input for vote weight calculation', () => {
      const invalidMetrics = {
        reputation: 'high', // should be a number
        influenceScore: 50,
        ethicalStanding: 90
      };
      expect(() => calculateVoteWeight(invalidMetrics)).toThrowError('Invalid user metrics');
    });
  });
});
