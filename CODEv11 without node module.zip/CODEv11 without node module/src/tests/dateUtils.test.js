const { formatDate, getCurrentDateTime, addDays, subtractDays, isBefore, isAfter } = require('../src/utils/dateUtils');
const moment = require('moment-timezone');

describe('Date Utils Tests', () => {

  // Test date formatting with time zones
  describe('formatDate', () => {
    test('should format date to the specified format and time zone', () => {
      const date = new Date('2023-09-23T12:00:00Z');
      const formattedDate = formatDate(date, 'YYYY-MM-DD HH:mm:ss', 'America/New_York');

      expect(formattedDate).toBe('2023-09-23 08:00:00'); // 4 hours behind UTC
    });

    test('should default to UTC if no time zone is provided', () => {
      const date = new Date('2023-09-23T12:00:00Z');
      const formattedDate = formatDate(date, 'YYYY-MM-DD HH:mm:ss');

      expect(formattedDate).toBe('2023-09-23 12:00:00');
    });
  });

  // Test getting the current date and time in a specific time zone
  describe('getCurrentDateTime', () => {
    test('should return the current date and time in the specified time zone', () => {
      const mockDate = '2023-09-23T12:00:00Z';
      jest.spyOn(moment.tz, 'guess').mockReturnValue('UTC'); // Mock time zone guess
      jest.spyOn(global, 'Date').mockImplementation(() => new Date(mockDate));

      const currentDateTime = getCurrentDateTime('America/Los_Angeles');

      expect(currentDateTime).toBe('2023-09-23 05:00:00'); // 7 hours behind UTC
    });

    test('should default to UTC if no time zone is provided', () => {
      const mockDate = '2023-09-23T12:00:00Z';
      jest.spyOn(global, 'Date').mockImplementation(() => new Date(mockDate));

      const currentDateTime = getCurrentDateTime();

      expect(currentDateTime).toBe('2023-09-23 12:00:00');
    });
  });

  // Test adding days to a date
  describe('addDays', () => {
    test('should add days to a given date', () => {
      const date = new Date('2023-09-23T00:00:00Z');
      const result = addDays(date, 5);

      expect(result.toISOString()).toBe('2023-09-28T00:00:00.000Z');
    });
  });

  // Test subtracting days from a date
  describe('subtractDays', () => {
    test('should subtract days from a given date', () => {
      const date = new Date('2023-09-23T00:00:00Z');
      const result = subtractDays(date, 3);

      expect(result.toISOString()).toBe('2023-09-20T00:00:00.000Z');
    });
  });

  // Test checking if one date is before another
  describe('isBefore', () => {
    test('should return true if the first date is before the second', () => {
      const date1 = new Date('2023-09-20T00:00:00Z');
      const date2 = new Date('2023-09-23T00:00:00Z');

      const result = isBefore(date1, date2);

      expect(result).toBe(true);
    });

    test('should return false if the first date is not before the second', () => {
      const date1 = new Date('2023-09-25T00:00:00Z');
      const date2 = new Date('2023-09-23T00:00:00Z');

      const result = isBefore(date1, date2);

      expect(result).toBe(false);
    });
  });

  // Test checking if one date is after another
  describe('isAfter', () => {
    test('should return true if the first date is after the second', () => {
      const date1 = new Date('2023-09-25T00:00:00Z');
      const date2 = new Date('2023-09-23T00:00:00Z');

      const result = isAfter(date1, date2);

      expect(result).toBe(true);
    });

    test('should return false if the first date is not after the second', () => {
      const date1 = new Date('2023-09-20T00:00:00Z');
      const date2 = new Date('2023-09-23T00:00:00Z');

      const result = isAfter(date1, date2);

      expect(result).toBe(false);
    });
  });
});
