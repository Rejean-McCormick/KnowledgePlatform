const { submitVote, calculateResults } = require('../src/services/voteService');
const { getUserMetrics } = require('../src/services/userMetrics');

jest.mock('../src/services/userMetrics'); // Mock the user metrics service

describe('Vote Service Unit Tests', () => {
  let voteData;

  beforeEach(() => {
    voteData = {
      OptionA: { votes: 0, weight: 0 },
      OptionB: { votes: 0, weight: 0 },
    };
  });

  // Test vote submission handling
  describe('submitVote', () => {
    test('should submit a vote and update the vote data correctly', async () => {
      const user = { id: 1, role: 'student' };
      const voteOption = 'OptionA';

      // Mock the getUserMetrics function to return specific user metrics
      getUserMetrics.mockResolvedValue({
        reputation: 50,
        influenceScore: 30,
        ethicalStanding: 70,
      });

      await submitVote(user, voteOption, voteData);

      expect(voteData.OptionA.votes).toBe(1);
      expect(voteData.OptionA.weight).toBeGreaterThan(1);
      expect(voteData.OptionB.votes).toBe(0); // Ensure no changes to other options
    });

    test('should handle specialists having higher vote weight', async () => {
      const user = { id: 2, role: 'specialist' };
      const voteOption = 'OptionA';

      // Mock user metrics for a specialist
      getUserMetrics.mockResolvedValue({
        reputation: 80,
        influenceScore: 60,
        ethicalStanding: 90,
      });

      await submitVote(user, voteOption, voteData);

      expect(voteData.OptionA.votes).toBe(1);
      expect(voteData.OptionA.weight).toBeGreaterThan(5); // Specialists should have higher weight
    });

    test('should throw an error for invalid vote option', async () => {
      const user = { id: 1, role: 'student' };
      const invalidVoteOption = 'InvalidOption';

      await expect(submitVote(user, invalidVoteOption, voteData)).rejects.toThrow(
        'Invalid vote option'
      );
    });
  });

  // Test vote result calculation
  describe('calculateResults', () => {
    test('should calculate vote results based on weighted votes', () => {
      // Simulate vote data
      voteData = {
        OptionA: { votes: 3, weight: 15 },
        OptionB: { votes: 2, weight: 10 },
      };

      const results = calculateResults(voteData);

      expect(results).toHaveProperty('OptionA', 15);
      expect(results).toHaveProperty('OptionB', 10);
    });

    test('should handle cases with no votes submitted', () => {
      const emptyVoteData = {
        OptionA: { votes: 0, weight: 0 },
        OptionB: { votes: 0, weight: 0 },
      };

      const results = calculateResults(emptyVoteData);

      expect(results).toHaveProperty('OptionA', 0);
      expect(results).toHaveProperty('OptionB', 0);
    });
  });
});
