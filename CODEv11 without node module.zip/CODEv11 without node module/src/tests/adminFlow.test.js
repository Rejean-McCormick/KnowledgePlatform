import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import App from './App'; // Assuming App contains routing and layout

// Admin Flow Test
test('end-to-end admin flow for managing users and content', async () => {
  // Render the app with routing
  render(<App />, { wrapper: MemoryRouter });

  // Navigate to Admin Dashboard
  fireEvent.click(screen.getByText(/Admin Dashboard/i));
  expect(screen.getByText(/Admin Tools/i)).toBeInTheDocument();

  // Navigate to Manage Users Page
  fireEvent.click(screen.getByText(/Manage Users/i));
  expect(screen.getByText(/User Management/i)).toBeInTheDocument();

  // Simulate selecting a user to edit
  fireEvent.click(screen.getByText(/John Doe/i));
  expect(screen.getByLabelText(/Role/i)).toBeInTheDocument();

  // Change user role and save
  fireEvent.change(screen.getByLabelText(/Role/i), { target: { value: 'Moderator' } });
  fireEvent.click(screen.getByText(/Save Changes/i));

  // Wait for confirmation message
  await waitFor(() => screen.getByText(/User updated successfully/i));
  expect(screen.getByText(/John Doe/i)).toBeInTheDocument();

  // Navigate to Manage Content Page
  fireEvent.click(screen.getByText(/Moderate Content/i));
  expect(screen.getByText(/Content Moderation/i)).toBeInTheDocument();

  // Simulate approving content
  fireEvent.click(screen.getByText(/Approve/i));
  await waitFor(() => screen.getByText(/Content approved successfully/i));

  // Simulate rejecting content
  fireEvent.click(screen.getByText(/Reject/i));
  await waitFor(() => screen.getByText(/Content rejected successfully/i));
});
 
