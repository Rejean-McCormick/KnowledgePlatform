import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import App from './App'; // Assuming App contains routing and layout

// Vote Flow Test
test('end-to-end vote flow on topics with real-time updates and vote weighting', async () => {
  // Render the app with routing
  render(<App />, { wrapper: MemoryRouter });

  // Navigate to Topics Page
  fireEvent.click(screen.getByText(/Topics/i));
  expect(screen.getByText(/Explore Topics/i)).toBeInTheDocument();

  // Simulate selecting a topic to vote on
  fireEvent.click(screen.getByText(/Climate Change Discussions/i));
  expect(screen.getByText(/Vote on this topic/i)).toBeInTheDocument();

  // Submit a vote
  fireEvent.click(screen.getByLabelText('Vote: 8'));
  fireEvent.click(screen.getByText(/Submit Vote/i));

  // Wait for vote confirmation and real-time update
  await waitFor(() => screen.getByText(/Your vote has been submitted/i));
  expect(screen.getByText(/Vote Count:/i)).toBeInTheDocument();

  // Check if vote weighting has been applied
  expect(screen.getByText(/Your vote weight:/i)).toBeInTheDocument();
  expect(screen.getByText(/Vote Weight: 7/i)).toBeInTheDocument(); // Assuming weight is calculated based on user metrics

  // Check if real-time vote count updates
  await waitFor(() => screen.getByText(/Current Votes:/i));
  expect(screen.getByText(/Current Votes: 100/i)); // Example of real-time vote count after update
});
 
