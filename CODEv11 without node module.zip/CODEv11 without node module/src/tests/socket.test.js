const io = require('socket.io-client');
const http = require('http');
const { setupWebSocket } = require('../src/real-time/socketServer'); // Import WebSocket setup
const app = require('../src/server'); // Assuming your Express server is exported here

let server;
let socketUrl = 'http://localhost:3000';
let clientSocket;

describe('WebSocket Tests', () => {
  beforeAll((done) => {
    // Set up server and WebSocket
    server = http.createServer(app);
    setupWebSocket(server);
    server.listen(3000, () => {
      done();
    });
  });

  afterAll((done) => {
    // Close server and WebSocket connection
    if (clientSocket) clientSocket.disconnect();
    server.close(done);
  });

  beforeEach((done) => {
    // Connect a client to the WebSocket server before each test
    clientSocket = io.connect(socketUrl, {
      transports: ['websocket'],
      'force new connection': true,
    });
    clientSocket.on('connect', () => {
      done();
    });
  });

  afterEach((done) => {
    // Disconnect the client socket after each test
    if (clientSocket.connected) {
      clientSocket.disconnect();
    }
    done();
  });

  test('should receive real-time vote updates via WebSocket', (done) => {
    const voteResults = {
      issue: 'Issue 1',
      OptionA: 10,
      OptionB: 15,
    };

    // Listen for voteResults event
    clientSocket.on('voteResults', (data) => {
      expect(data).toHaveProperty('OptionA', 10);
      expect(data).toHaveProperty('OptionB', 15);
      done();
    });

    // Emit voteResults from the server to simulate real-time vote update
    clientSocket.emit('voteResults', voteResults);
  });

  test('should receive notification broadcast via WebSocket', (done) => {
    const notification = {
      message: 'New voting session started',
      type: 'info',
    };

    // Listen for notification event
    clientSocket.on('notification', (data) => {
      expect(data).toHaveProperty('message', 'New voting session started');
      expect(data).toHaveProperty('type', 'info');
      done();
    });

    // Emit notification from the server to simulate a notification broadcast
    clientSocket.emit('notification', notification);
  });

  test('should handle disconnect and reconnect events', (done) => {
    // Handle disconnect event
    clientSocket.on('disconnect', () => {
      expect(clientSocket.connected).toBe(false);
      done();
    });

    // Simulate client disconnect
    clientSocket.disconnect();
  });
});
