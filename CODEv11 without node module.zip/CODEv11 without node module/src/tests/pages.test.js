import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AnnouncementsPage from './AnnouncementsPage';
import TestimonialsPage from './TestimonialsPage';
import FeedbackConfirmationPage from './FeedbackConfirmationPage';
import CollaborationHubPage from './CollaborationHubPage';
import ErrorPage from './ErrorPage';
import LoginPage from './LoginPage';
import RegisterPage from './RegisterPage';
import UserGuidePage from './UserGuidePage';

// AnnouncementsPage Test
test('renders AnnouncementsPage correctly', () => {
  render(<AnnouncementsPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Platform Announcements/i)).toBeInTheDocument();
  expect(screen.getByPlaceholderText(/Search announcements/i)).toBeInTheDocument();
});

// TestimonialsPage Test
test('renders TestimonialsPage correctly and allows testimonial submission', () => {
  render(<TestimonialsPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/User Testimonials/i)).toBeInTheDocument();
  const textarea = screen.getByPlaceholderText(/Write your testimonial here/i);
  fireEvent.change(textarea, { target: { value: 'Great platform!' } });
  fireEvent.click(screen.getByText(/Submit Testimonial/i));
  expect(textarea.value).toBe('');
});

// FeedbackConfirmationPage Test
test('renders FeedbackConfirmationPage correctly', () => {
  render(<FeedbackConfirmationPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Thank You for Your Feedback/i)).toBeInTheDocument();
  expect(screen.getByText(/Your feedback has been submitted/i)).toBeInTheDocument();
});

// CollaborationHubPage Test
test('renders CollaborationHubPage correctly', () => {
  render(<CollaborationHubPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Collaboration Hub/i)).toBeInTheDocument();
});

// ErrorPage Test
test('renders ErrorPage with appropriate message', () => {
  render(<ErrorPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Error 404/i)).toBeInTheDocument();
  expect(screen.getByText(/Page not found/i)).toBeInTheDocument();
});

// LoginPage Test
test('renders LoginPage correctly and handles form validation', () => {
  render(<LoginPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Login/i)).toBeInTheDocument();
  fireEvent.click(screen.getByText(/Login/i));
  expect(screen.getByText(/Username and password are required/i)).toBeInTheDocument();
});

// RegisterPage Test
test('renders RegisterPage correctly and validates input', () => {
  render(<RegisterPage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Register/i)).toBeInTheDocument();
  fireEvent.click(screen.getByText(/Register/i));
  expect(screen.getByText(/All fields are required/i)).toBeInTheDocument();
});

// UserGuidePage Test
test('renders UserGuidePage correctly', () => {
  render(<UserGuidePage />, { wrapper: MemoryRouter });
  expect(screen.getByText(/User Guide/i)).toBeInTheDocument();
  expect(screen.getByText(/Getting Started/i)).toBeInTheDocument();
  expect(screen.getByText(/Frequently Asked Questions/i)).toBeInTheDocument();
});
 
