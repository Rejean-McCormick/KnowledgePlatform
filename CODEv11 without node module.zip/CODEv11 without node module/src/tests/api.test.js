const request = require('supertest');
const app = require('../src/server'); // Assuming your Express server is exported here

let authToken = '';
let adminToken = '';

describe('API Tests', () => {

  // User Registration and Login
  describe('User Authentication', () => {
    test('should register a new user successfully', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'apiuser',
          email: 'apiuser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(201);
      expect(res.body).toHaveProperty('user');
      expect(res.body.user).toHaveProperty('username', 'apiuser');
    });

    test('should log in the user and return a JWT token', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'apiuser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('token');
      authToken = res.body.token; // Store token for authenticated requests
    });
  });

  // Vote Submission and Results
  describe('Voting API', () => {
    test('should submit a vote successfully', async () => {
      const res = await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          option: 'Option A',
          role: 'student',
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('updatedVotes');
    });

    test('should fetch vote results', async () => {
      const res = await request(app)
        .get('/api/votes/results')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('Option A');
      expect(res.body['Option A']).toBeGreaterThanOrEqual(0);
    });
  });

  // Badge Assignment and Tracking
  describe('Badge Tracking API', () => {
    test('should allow the admin to assign a badge to a user', async () => {
      // First, log in as admin
      const adminLoginRes = await request(app)
        .post('/api/admin/auth/login')
        .send({
          email: 'admin@example.com',
          password: 'adminpassword',
        });

      expect(adminLoginRes.statusCode).toEqual(200);
      adminToken = adminLoginRes.body.token; // Store token for admin requests

      // Assign badge
      const res = await request(app)
        .post('/api/admin/users/1/assign-badge')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ badge: 'contributor' });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('message', 'Badge assigned successfully');
    });

    test('should retrieve user badges', async () => {
      const res = await request(app)
        .get('/api/users/1/badges')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toContain('contributor');
    });
  });

  // Token Validation and Protected Routes
  describe('Protected Routes', () => {
    test('should restrict access to protected routes without a token', async () => {
      const res = await request(app)
        .get('/api/users/me');

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'No token provided.');
    });

    test('should allow access to protected routes with a valid token', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('username', 'apiuser');
    });

    test('should restrict access to protected routes with an invalid token', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('Authorization', 'Bearer invalidtoken');

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'Invalid token.');
    });
  });
});
