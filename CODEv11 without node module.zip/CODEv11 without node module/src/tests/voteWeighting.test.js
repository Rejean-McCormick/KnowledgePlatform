const { calculateVoteWeight } = require('../src/utils/voteWeighting');
const { callOpenAI } = require('../src/services/openaiService');

jest.mock('../src/services/openaiService'); // Mock the OpenAI service to simulate API calls

describe('Vote Weighting Tests', () => {
  // Test vote weight calculation without AI influence
  describe('Manual Vote Weight Calculation', () => {
    test('should calculate vote weight based on user metrics', () => {
      const userMetrics = {
        reputation: 60,
        influenceScore: 40,
        ethicalStanding: 80,
        role: 'student',
      };

      const voteWeight = calculateVoteWeight(userMetrics);

      expect(voteWeight).toBeGreaterThan(1);
      expect(voteWeight).toBeLessThanOrEqual(10);
    });

    test('should assign higher vote weight to specialists', () => {
      const specialistMetrics = {
        reputation: 80,
        influenceScore: 60,
        ethicalStanding: 90,
        role: 'specialist',
      };

      const studentMetrics = {
        reputation: 80,
        influenceScore: 60,
        ethicalStanding: 90,
        role: 'student',
      };

      const specialistVoteWeight = calculateVoteWeight(specialistMetrics);
      const studentVoteWeight = calculateVoteWeight(studentMetrics);

      expect(specialistVoteWeight).toBeGreaterThan(studentVoteWeight);
    });

    test('should throw error for invalid user metrics', () => {
      const invalidMetrics = {
        reputation: 'high', // should be a number
        influenceScore: 50,
        ethicalStanding: 90,
      };

      expect(() => calculateVoteWeight(invalidMetrics)).toThrowError('Invalid user metrics');
    });
  });

  // Test vote weight calculation with AI-driven adjustments
  describe('AI-Driven Vote Weight Adjustment', () => {
    test('should adjust vote weight based on AI output', async () => {
      // Mock OpenAI API response
      callOpenAI.mockResolvedValue(8); // Simulate that the AI returns a vote weight of 8

      const userMetrics = {
        reputation: 70,
        influenceScore: 50,
        ethicalStanding: 85,
        role: 'specialist',
      };

      const voteWeight = await calculateVoteWeight(userMetrics);

      expect(voteWeight).toBe(8); // Expect AI-driven vote weight
    });

    test('should handle fallback if OpenAI API fails', async () => {
      // Mock OpenAI API failure
      callOpenAI.mockRejectedValue(new Error('OpenAI API error'));

      const userMetrics = {
        reputation: 50,
        influenceScore: 30,
        ethicalStanding: 70,
        role: 'student',
      };

      const voteWeight = await calculateVoteWeight(userMetrics);

      // Expect manual fallback to calculate vote weight
      expect(voteWeight).toBeGreaterThan(1);
      expect(voteWeight).toBeLessThanOrEqual(10);
    });
  });
});
