const request = require('supertest');
const app = require('../src/server'); // Assuming your Express server is exported here

let authToken = '';
let adminToken = '';

describe('End-to-End User Flow Tests', () => {
  beforeAll(async () => {
    // Log in as admin to use for badge assignment later
    const adminLoginRes = await request(app)
      .post('/api/admin/auth/login')
      .send({
        email: 'admin@example.com',
        password: 'adminpassword',
      });

    expect(adminLoginRes.statusCode).toEqual(200);
    adminToken = adminLoginRes.body.token;
  });

  // Test user registration, login, voting, and badge tracking
  describe('Complete User Flow', () => {

    test('should register a new user', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'e2eUser',
          email: 'e2euser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(201);
      expect(res.body).toHaveProperty('user');
      expect(res.body.user).toHaveProperty('username', 'e2eUser');
    });

    test('should log in the user and get a token', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'e2euser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('token');
      authToken = res.body.token;
    });

    test('should submit a vote and get real-time results', async () => {
      const res = await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          option: 'Option A',
          role: 'student',
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('updatedVotes');

      // Check vote results
      const resultsRes = await request(app)
        .get('/api/votes/results')
        .set('Authorization', `Bearer ${authToken}`);

      expect(resultsRes.statusCode).toEqual(200);
      expect(resultsRes.body).toHaveProperty('Option A');
      expect(resultsRes.body['Option A']).toBeGreaterThanOrEqual(1);
    });

    test('should allow admin to assign a badge to the user', async () => {
      const res = await request(app)
        .post('/api/admin/users/1/assign-badge')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          badge: 'contributor',
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('message', 'Badge assigned successfully');
    });

    test('should allow user to view their badges', async () => {
      const res = await request(app)
        .get('/api/users/me/badges')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toContain('contributor');
    });
  });

  // Test invalid flows (optional, for error-handling scenarios)
  describe('Invalid User Flow', () => {
    test('should not allow voting without authentication', async () => {
      const res = await request(app)
        .post('/api/votes')
        .send({
          option: 'Option A',
        });

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'No token provided.');
    });

    test('should not allow admin actions without an admin token', async () => {
      const res = await request(app)
        .post('/api/admin/users/1/assign-badge')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          badge: 'contributor',
        });

      expect(res.statusCode).toEqual(403);
      expect(res.body).toHaveProperty('message', 'Access denied.');
    });
  });
});
