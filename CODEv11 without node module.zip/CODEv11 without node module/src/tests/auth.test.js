const request = require('supertest');
const app = require('../src/server'); // Assuming your Express server is exported from here

describe('Authentication Tests', () => {
  
  // Test user registration
  describe('User Registration', () => {
    test('should register a new user successfully', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'newuser',
          email: 'newuser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(201);
      expect(res.body).toHaveProperty('user');
      expect(res.body.user).toHaveProperty('username', 'newuser');
    });

    test('should not register a user with an existing email', async () => {
      // Assume the email is already registered
      await request(app)
        .post('/api/auth/register')
        .send({
          username: 'existinguser',
          email: 'existinguser@example.com',
          password: 'password123',
        });

      const res = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'anotheruser',
          email: 'existinguser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(400);
      expect(res.body).toHaveProperty('message', 'Email is already in use.');
    });

    test('should validate required fields during registration', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          username: '',
          email: '',
          password: '',
        });

      expect(res.statusCode).toEqual(400);
      expect(res.body).toHaveProperty('errors');
    });
  });

  // Test user login
  describe('User Login', () => {
    test('should log in a user with correct credentials', async () => {
      // Register the user first
      await request(app)
        .post('/api/auth/register')
        .send({
          username: 'testuser',
          email: 'testuser@example.com',
          password: 'password123',
        });

      // Log in the registered user
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'testuser@example.com',
          password: 'password123',
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('token');
      expect(res.body.user).toHaveProperty('username', 'testuser');
    });

    test('should not log in a user with incorrect credentials', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'nonexistentuser@example.com',
          password: 'wrongpassword',
        });

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'Invalid email or password.');
    });

    test('should validate required fields during login', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: '',
          password: '',
        });

      expect(res.statusCode).toEqual(400);
      expect(res.body).toHaveProperty('errors');
    });
  });

  // Test token validation
  describe('Token Validation', () => {
    let authToken;

    beforeAll(async () => {
      // Register and log in a user to get a token
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          username: 'tokenuser',
          email: 'tokenuser@example.com',
          password: 'password123',
        });

      authToken = res.body.token;
    });

    test('should allow access to protected routes with valid token', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('username', 'tokenuser');
    });

    test('should restrict access to protected routes with no token', async () => {
      const res = await request(app)
        .get('/api/users/me');

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'No token provided.');
    });

    test('should restrict access to protected routes with invalid token', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('Authorization', 'Bearer invalidtoken');

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'Invalid token.');
    });
  });
});
