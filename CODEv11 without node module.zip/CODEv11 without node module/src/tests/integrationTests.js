const request = require('supertest');
const app = require('../src/server'); // Assuming your Express server is exported from here
const io = require('socket.io-client');

let authToken = '';
let adminToken = '';

describe('Integration Tests', () => {
  beforeAll(async () => {
    // Register a user
    await request(app)
      .post('/api/auth/register')
      .send({
        username: 'testuser',
        email: 'testuser@example.com',
        password: 'password123',
      });

    // Log in as user
    const userLoginResponse = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'testuser@example.com',
        password: 'password123',
      });

    authToken = userLoginResponse.body.token;

    // Log in as admin
    const adminLoginResponse = await request(app)
      .post('/api/admin/auth/login')
      .send({
        email: 'admin@example.com',
        password: 'adminpassword',
      });

    adminToken = adminLoginResponse.body.token;
  });

  afterAll(() => {
    app.close();
  });

  // Test user authentication and access to protected routes
  describe('User Authentication and Authorization', () => {
    test('should authenticate user and access protected route', async () => {
      const res = await request(app)
        .get('/api/users/me')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('username', 'testuser');
    });

    test('should restrict access to protected route without token', async () => {
      const res = await request(app).get('/api/users/me');
      expect(res.statusCode).toEqual(401);
    });
  });

  // Test vote submission and real-time updates
  describe('Vote Submission and Real-Time Updates', () => {
    let socket;

    beforeEach((done) => {
      socket = io.connect('http://localhost:3000', {
        transports: ['websocket'],
        'force new connection': true,
      });

      socket.on('connect', () => {
        done();
      });
    });

    afterEach((done) => {
      if (socket.connected) {
        socket.disconnect();
      }
      done();
    });

    test('should submit a vote and receive real-time update', async () => {
      // Submit a vote
      const res = await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ option: 'Option A', role: 'specialist' });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('updatedVotes');

      // Listen for real-time vote updates
      socket.on('voteResults', (data) => {
        expect(data).toHaveProperty('Option A');
        expect(data['Option A']).toBeGreaterThan(0);
      });
    });
  });

  // Test admin access and system metrics retrieval
  describe('Admin Dashboard', () => {
    test('should allow admin to access user metrics and system performance', async () => {
      const metricsRes = await request(app)
        .get('/api/admin/users/metrics')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(metricsRes.statusCode).toEqual(200);
      expect(metricsRes.body).toBeInstanceOf(Array);

      const performanceRes = await request(app)
        .get('/api/admin/system/performance')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(performanceRes.statusCode).toEqual(200);
      expect(performanceRes.body).toHaveProperty('apiResponseTime');
    });

    test('should restrict non-admin users from accessing admin routes', async () => {
      const res = await request(app)
        .get('/api/admin/users/metrics')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(403);
    });
  });
});
