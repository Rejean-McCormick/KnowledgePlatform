const request = require('supertest');
const app = require('../src/server'); // Assuming your Express server is exported here
const { calculateVoteWeight } = require('../src/services/voteWeighting');

let authToken = '';
let adminToken = '';

describe('Vote Submission Tests', () => {
  beforeAll(async () => {
    // Register a user
    await request(app)
      .post('/api/auth/register')
      .send({
        username: 'testvoter',
        email: 'testvoter@example.com',
        password: 'password123',
      });

    // Log in as user
    const userLoginResponse = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'testvoter@example.com',
        password: 'password123',
      });

    authToken = userLoginResponse.body.token;

    // Log in as admin (optional, if needed for test setup)
    const adminLoginResponse = await request(app)
      .post('/api/admin/auth/login')
      .send({
        email: 'admin@example.com',
        password: 'adminpassword',
      });

    adminToken = adminLoginResponse.body.token;
  });

  afterAll(() => {
    app.close();
  });

  // Test vote submission
  describe('Vote Submission', () => {
    test('should allow a user to submit a vote successfully', async () => {
      const res = await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          option: 'Option A',
          role: 'student', // Role could be 'student' or 'specialist'
        });

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('updatedVotes');
    });

    test('should not allow a user to submit a vote without authentication', async () => {
      const res = await request(app)
        .post('/api/votes')
        .send({
          option: 'Option A',
        });

      expect(res.statusCode).toEqual(401);
      expect(res.body).toHaveProperty('message', 'No token provided.');
    });

    test('should validate that vote option is provided', async () => {
      const res = await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          option: '',
        });

      expect(res.statusCode).toEqual(400);
      expect(res.body).toHaveProperty('message', 'Vote option is required.');
    });
  });

  // Test vote weighting
  describe('Vote Weighting', () => {
    test('should calculate vote weight based on user metrics', async () => {
      const userMetrics = {
        reputation: 50,
        influenceScore: 30,
        ethicalStanding: 70,
      };

      const voteWeight = calculateVoteWeight(userMetrics);

      expect(voteWeight).toBeGreaterThan(1);
      expect(voteWeight).toBeLessThanOrEqual(10);
    });

    test('should assign higher vote weight to specialists', async () => {
      const studentMetrics = {
        reputation: 50,
        influenceScore: 30,
        ethicalStanding: 70,
        role: 'student',
      };

      const specialistMetrics = {
        reputation: 50,
        influenceScore: 30,
        ethicalStanding: 70,
        role: 'specialist',
      };

      const studentVoteWeight = calculateVoteWeight(studentMetrics);
      const specialistVoteWeight = calculateVoteWeight(specialistMetrics);

      expect(specialistVoteWeight).toBeGreaterThan(studentVoteWeight);
    });
  });

  // Test vote result calculation
  describe('Vote Result Calculation', () => {
    test('should calculate vote results after submission', async () => {
      // Submit votes
      await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ option: 'Option A', role: 'student' });

      await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ option: 'Option B', role: 'student' });

      // Retrieve updated vote results
      const res = await request(app)
        .get('/api/votes/results')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('Option A');
      expect(res.body).toHaveProperty('Option B');
      expect(res.body['Option A']).toBeGreaterThanOrEqual(0);
      expect(res.body['Option B']).toBeGreaterThanOrEqual(0);
    });

    test('should aggregate votes with correct weighting', async () => {
      // Submit votes with different roles
      await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ option: 'Option A', role: 'specialist' });

      await request(app)
        .post('/api/votes')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ option: 'Option B', role: 'student' });

      // Retrieve vote results and check weighted results
      const res = await request(app)
        .get('/api/votes/results')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.statusCode).toEqual(200);
      expect(res.body).toHaveProperty('Option A');
      expect(res.body).toHaveProperty('Option B');

      // Expect the specialist vote to have more weight
      expect(res.body['Option A']).toBeGreaterThan(res.body['Option B']);
    });
  });
});
