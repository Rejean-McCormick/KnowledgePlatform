import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import App from './App'; // Assuming App contains the main routing and layout

// User Flow Test
test('end-to-end user flow from login to content submission', async () => {
  // Render the app with routing
  render(<App />, { wrapper: MemoryRouter });

  // Navigate to Login Page
  fireEvent.click(screen.getByText(/Login/i));
  expect(screen.getByText(/Login to Your Account/i)).toBeInTheDocument();

  // Fill in and submit login form
  fireEvent.change(screen.getByLabelText(/Username/i), { target: { value: 'testuser' } });
  fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'password123' } });
  fireEvent.click(screen.getByText(/Login/i));

  // Wait for redirection after login
  await waitFor(() => screen.getByText(/Welcome, testuser/i));
  expect(screen.getByText(/Dashboard/i)).toBeInTheDocument();

  // Navigate to content submission page
  fireEvent.click(screen.getByText(/Submit Content/i));
  expect(screen.getByText(/Submit Your Article/i)).toBeInTheDocument();

  // Fill in and submit content form
  fireEvent.change(screen.getByLabelText(/Title/i), { target: { value: 'My First Article' } });
  fireEvent.change(screen.getByLabelText(/Body/i), { target: { value: 'This is the content of my article.' } });
  fireEvent.click(screen.getByText(/Submit/i));

  // Wait for confirmation message
  await waitFor(() => screen.getByText(/Your content has been submitted/i));
  expect(screen.getByText(/Thank you for your submission/i)).toBeInTheDocument();

  // Navigate to the topics page
  fireEvent.click(screen.getByText(/Topics/i));
  expect(screen.getByText(/Explore Topics/i)).toBeInTheDocument();
});
 
