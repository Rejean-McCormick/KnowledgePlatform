import { formatDate, timeAgo, handleTimeZone } from './dateUtils';
import { validateEmail, validatePassword, isRequired } from './validationUtils';
import { formatNumber, truncateString } from './formatUtils';
import { calculateVoteWeight, add, subtract } from './mathUtils';

// dateUtils Test
test('formatDate formats the date correctly', () => {
  const date = new Date('2023-09-24T12:00:00Z');
  expect(formatDate(date)).toBe('Sep 24, 2023');
});

test('timeAgo calculates relative time correctly', () => {
  const date = new Date(Date.now() - 1000 * 60 * 60 * 24 * 2); // 2 days ago
  expect(timeAgo(date)).toBe('2 days ago');
});

test('handleTimeZone converts time to the correct zone', () => {
  const date = new Date('2023-09-24T12:00:00Z');
  expect(handleTimeZone(date, 'America/New_York')).toBe('Sep 24, 2023, 08:00 AM');
});

// validationUtils Test
test('validateEmail validates correct email format', () => {
  expect(validateEmail('test@example.com')).toBe(true);
  expect(validateEmail('invalid-email')).toBe(false);
});

test('validatePassword checks password strength', () => {
  expect(validatePassword('Str0ngPass!')).toBe(true);
  expect(validatePassword('weakpass')).toBe(false);
});

test('isRequired validates required fields', () => {
  expect(isRequired('')).toBe(false);
  expect(isRequired('filled')).toBe(true);
});

// formatUtils Test
test('formatNumber formats large numbers correctly', () => {
  expect(formatNumber(1000000)).toBe('1,000,000');
});

test('truncateString truncates strings correctly', () => {
  expect(truncateString('This is a long string', 10)).toBe('This is a...');
});

// mathUtils Test
test('calculateVoteWeight calculates correct vote weight', () => {
  const userMetrics = { reputation: 100, expertise: 50, ethics: 80 };
  expect(calculateVoteWeight(userMetrics)).toBe(7); // Example weight calculation
});

test('add function works correctly', () => {
  expect(add(2, 3)).toBe(5);
});

test('subtract function works correctly', () => {
  expect(subtract(5, 3)).toBe(2);
});
 
