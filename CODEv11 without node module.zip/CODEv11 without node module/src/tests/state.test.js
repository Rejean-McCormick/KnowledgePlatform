import { renderHook, act } from '@testing-library/react-hooks';
import { AuthProvider, useAuth } from './authContext';
import { VoteProvider, useVote } from './voteContext';

// AuthContext Test
test('authContext provides initial state and updates on login', () => {
  const { result } = renderHook(() => useAuth(), { wrapper: AuthProvider });

  // Check initial state
  expect(result.current.user).toBe(null);

  // Simulate login
  act(() => {
    result.current.login({ username: 'testuser', token: 'abc123' });
  });

  // Check updated state
  expect(result.current.user.username).toBe('testuser');
  expect(result.current.isAuthenticated).toBe(true);

  // Simulate logout
  act(() => {
    result.current.logout();
  });

  // Check state after logout
  expect(result.current.user).toBe(null);
  expect(result.current.isAuthenticated).toBe(false);
});

// VoteContext Test
test('voteContext manages vote state and handles vote submission', () => {
  const { result } = renderHook(() => useVote(), { wrapper: VoteProvider });

  // Check initial state
  expect(result.current.votes).toEqual({});

  // Simulate vote submission
  act(() => {
    result.current.submitVote('topic123', 5);
  });

  // Check state after vote submission
  expect(result.current.votes['topic123']).toBe(5);

  // Simulate vote update
  act(() => {
    result.current.updateVote('topic123', 8);
  });

  // Check updated vote
  expect(result.current.votes['topic123']).toBe(8);
});
 
