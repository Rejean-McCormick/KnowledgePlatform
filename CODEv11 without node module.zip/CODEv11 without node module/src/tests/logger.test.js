const { logInfo, logError, logRequest } = require('../src/utils/loggerService');
const fs = require('fs');
const path = require('path');

// Mock fs functions to prevent actual file writes
jest.mock('fs');

describe('Logger Service Tests', () => {
  const logFilePath = path.join(__dirname, '../logs/app.log');

  afterEach(() => {
    jest.clearAllMocks(); // Clear mock calls after each test
  });

  // Test logging informational messages
  describe('logInfo', () => {
    test('should log informational messages to the log file', () => {
      const message = 'Server started successfully';

      logInfo(message);

      // Expect fs.appendFileSync to be called with the correct arguments
      expect(fs.appendFileSync).toHaveBeenCalledWith(
        logFilePath,
        expect.stringContaining(message)
      );
    });
  });

  // Test logging errors
  describe('logError', () => {
    test('should log errors to the log file', () => {
      const errorMessage = 'Database connection failed';
      const errorStack = 'Error: Connection timeout';

      logError(errorMessage, errorStack);

      // Expect fs.appendFileSync to be called with error message and stack
      expect(fs.appendFileSync).toHaveBeenCalledWith(
        logFilePath,
        expect.stringContaining(errorMessage)
      );
      expect(fs.appendFileSync).toHaveBeenCalledWith(
        logFilePath,
        expect.stringContaining(errorStack)
      );
    });
  });

  // Test logging API requests
  describe('logRequest', () => {
    test('should log API requests with method, URL, and status code', () => {
      const req = {
        method: 'GET',
        url: '/api/votes',
      };
      const res = {
        statusCode: 200,
      };

      logRequest(req, res);

      // Expect fs.appendFileSync to be called with request info
      expect(fs.appendFileSync).toHaveBeenCalledWith(
        logFilePath,
        expect.stringContaining('GET /api/votes 200')
      );
    });

    test('should log API requests with error status codes', () => {
      const req = {
        method: 'POST',
        url: '/api/auth/login',
      };
      const res = {
        statusCode: 401,
      };

      logRequest(req, res);

      // Expect fs.appendFileSync to be called with request info and error status code
      expect(fs.appendFileSync).toHaveBeenCalledWith(
        logFilePath,
        expect.stringContaining('POST /api/auth/login 401')
      );
    });
  });
});
