import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Header from './Header';
import Footer from './Footer';
import Button from './Button';
import Modal from './Modal';
import LoadingSpinner from './LoadingSpinner';
import NotificationBanner from './NotificationBanner';
import SearchBar from './SearchBar';
import UserAvatar from './UserAvatar';
import Sidebar from './Sidebar';

// Header Test
test('renders Header with navigation links', () => {
  render(<Header />, { wrapper: MemoryRouter });
  expect(screen.getByText(/Home/i)).toBeInTheDocument();
  expect(screen.getByText(/About/i)).toBeInTheDocument();
  expect(screen.getByAltText(/Platform Logo/i)).toBeInTheDocument();
});

// Footer Test
test('renders Footer with copyright and social media links', () => {
  render(<Footer />);
  expect(screen.getByText(/© 2024 Knowledge Platform/i)).toBeInTheDocument();
  expect(screen.getByAltText(/Facebook/i)).toBeInTheDocument();
  expect(screen.getByAltText(/LinkedIn/i)).toBeInTheDocument();
});

// Button Test
test('renders Button and responds to click event', () => {
  const handleClick = jest.fn();
  render(<Button onClick={handleClick} label="Click Me" />);
  const button = screen.getByText(/Click Me/i);
  fireEvent.click(button);
  expect(handleClick).toHaveBeenCalledTimes(1);
});

// Modal Test
test('renders Modal and closes on ESC key press', () => {
  render(<Modal isOpen={true} onClose={jest.fn()} />);
  expect(screen.getByRole('dialog')).toBeInTheDocument();
  fireEvent.keyDown(window, { key: 'Escape' });
  expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
});

// LoadingSpinner Test
test('renders LoadingSpinner correctly', () => {
  render(<LoadingSpinner />);
  expect(screen.getByTestId('loading-spinner')).toBeInTheDocument();
});

// NotificationBanner Test
test('renders NotificationBanner with success message and allows dismissing', () => {
  render(<NotificationBanner type="success" message="Operation successful" />);
  expect(screen.getByText(/Operation successful/i)).toBeInTheDocument();
  fireEvent.click(screen.getByRole('button', { name: /dismiss/i }));
  expect(screen.queryByText(/Operation successful/i)).not.toBeInTheDocument();
});

// SearchBar Test
test('renders SearchBar and handles input change', () => {
  const handleSearch = jest.fn();
  render(<SearchBar onSearch={handleSearch} />);
  const input = screen.getByPlaceholderText(/Search/i);
  fireEvent.change(input, { target: { value: 'React' } });
  expect(input.value).toBe('React');
  fireEvent.keyDown(input, { key: 'Enter' });
  expect(handleSearch).toHaveBeenCalledWith('React');
});

// UserAvatar Test
test('renders UserAvatar with initials when no image provided', () => {
  render(<UserAvatar name="John Doe" />);
  expect(screen.getByText('JD')).toBeInTheDocument();
});

// Sidebar Test
test('renders Sidebar and allows collapsing', () => {
  const { container } = render(<Sidebar />);
  expect(screen.getByText(/Dashboard/i)).toBeInTheDocument();
  fireEvent.click(screen.getByLabelText(/collapse sidebar/i));
  expect(container.querySelector('.collapsed')).toBeInTheDocument();
});
 
