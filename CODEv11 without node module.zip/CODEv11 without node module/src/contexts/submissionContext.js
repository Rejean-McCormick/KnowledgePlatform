import React, { createContext, useState, useEffect, useContext } from 'react';

const SubmissionContext = createContext();

export const SubmissionProvider = ({ children }) => {
  const [drafts, setDrafts] = useState({});
  const [currentSubmission, setCurrentSubmission] = useState(null);

  useEffect(() => {
    const savedDrafts = JSON.parse(localStorage.getItem('drafts')) || {};
    setDrafts(savedDrafts);
  }, []);

  const saveDraft = (id, content) => {
    const updatedDrafts = { ...drafts, [id]: content };
    setDrafts(updatedDrafts);
    localStorage.setItem('drafts', JSON.stringify(updatedDrafts));
  };

  const loadDraft = (id) => {
    return drafts[id] || '';
  };

  const clearDraft = (id) => {
    const { [id]: _, ...remainingDrafts } = drafts;
    setDrafts(remainingDrafts);
    localStorage.setItem('drafts', JSON.stringify(remainingDrafts));
  };

  const submitContent = (content) => {
    // Simulate content submission
    setCurrentSubmission(content);
    clearDraft(content.id);
  };

  return (
    <SubmissionContext.Provider
      value={{ drafts, currentSubmission, saveDraft, loadDraft, clearDraft, submitContent }}
    >
      {children}
    </SubmissionContext.Provider>
  );
};

export const useSubmission = () => {
  return useContext(SubmissionContext);
};
 
