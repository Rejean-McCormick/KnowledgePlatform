import React, { createContext, useState, useEffect, useContext } from 'react';
import { getAuthToken, logout, isAuthenticated } from '../utils/authUtils';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuth, setIsAuth] = useState(false);
  const [role, setRole] = useState(null);

  useEffect(() => {
    const token = getAuthToken();
    if (token && isAuthenticated(token)) {
      try {
        // Ideally, decode user data from the token or fetch it from an API
        const userData = {
          id: 1,  // Replace with decoded or fetched user data
          name: 'John Doe',
          role: 'admin',
        };
        setUser(userData);
        setRole(userData.role);
        setIsAuth(true);
      } catch (error) {
        console.error('Error processing user data:', error);
        logout(); // Log out the user in case of any error
      }
    } else {
      logout();  // If token is invalid or missing, log out the user
    }
  }, []);

  const loginUser = (userData) => {
    setUser(userData);
    setRole(userData.role);
    setIsAuth(true);
  };

  const logoutUser = () => {
    logout();
    setUser(null);
    setRole(null);
    setIsAuth(false);
  };

  const hasRole = (requiredRole) => role === requiredRole;

  return (
    <UserContext.Provider value={{ user, isAuth, role, loginUser, logoutUser, hasRole }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
