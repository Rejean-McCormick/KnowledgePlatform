import React, { createContext, useState, useContext } from 'react';

const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [messages, setMessages] = useState([]);

  const sendMessage = (userMessage) => {
    const newMessage = { id: Date.now(), type: 'user', text: userMessage };
    setMessages((prevMessages) => [...prevMessages, newMessage]);

    // Simulate AI response after delay
    setTimeout(() => {
      const aiResponse = { id: Date.now(), type: 'ai', text: generateAIResponse(userMessage) };
      setMessages((prevMessages) => [...prevMessages, aiResponse]);
    }, 1000);
  };

  const generateAIResponse = (userMessage) => {
    // Placeholder for AI message generation logic
    return `AI Response to: ${userMessage}`;
  };

  return (
    <ChatContext.Provider value={{ messages, sendMessage }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  return useContext(ChatContext);
};
 
