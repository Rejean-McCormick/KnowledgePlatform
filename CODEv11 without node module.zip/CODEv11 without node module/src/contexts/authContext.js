import React, { createContext, useState, useEffect, useContext } from 'react';
import { getAuthToken, setAuthToken, clearAuthToken, isAuthenticated } from '../utils/authUtils';
 // Logout already in authUtils

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuth, setIsAuth] = useState(false);
  const [authToken, setAuthTokenState] = useState(null);

  useEffect(() => {
    const token = getAuthToken();
    if (token && isAuthenticated()) {
      setAuthTokenState(token);
      setIsAuth(true);
    } else {
      handleLogout();
    }
  }, []);

  const handleLogin = (token) => {
    setAuthToken(token);  // Store token in localStorage (authUtils)
    setAuthTokenState(token);
    setIsAuth(true);  // Set state to logged in
  };

  const handleLogout = () => {
    clearAuthToken();  // Clear token in localStorage (authUtils)
    setAuthTokenState(null);
    setIsAuth(false);  // Set state to logged out
  };

  return (
    <AuthContext.Provider value={{ isAuth, authToken, handleLogin, handleLogout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
