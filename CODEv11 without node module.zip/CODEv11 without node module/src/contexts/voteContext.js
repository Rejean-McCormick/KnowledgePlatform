import React, { createContext, useReducer, useContext, useEffect } from 'react';
import { io } from 'socket.io-client';

// Define the initial state
const initialState = {
  votes: [],
  userVote: null,
  loading: true,
};

// Create a context
const VoteContext = createContext();

// Define actions for vote state management
const VOTE_SUBMITTED = 'VOTE_SUBMITTED';
const VOTE_UPDATED = 'VOTE_UPDATED';
const SET_LOADING = 'SET_LOADING';
const SET_USER_VOTE = 'SET_USER_VOTE';

// Reducer function to manage the state
function voteReducer(state, action) {
  switch (action.type) {
    case VOTE_SUBMITTED:
      return {
        ...state,
        votes: [...state.votes, action.payload],
      };
    case VOTE_UPDATED:
      return {
        ...state,
        votes: state.votes.map((vote) =>
          vote.id === action.payload.id ? action.payload : vote
        ),
      };
    case SET_LOADING:
      return {
        ...state,
        loading: action.payload,
      };
    case SET_USER_VOTE:
      return {
        ...state,
        userVote: action.payload,
      };
    default:
      return state;
  }
}

// Context provider component
export const VoteProvider = ({ children }) => {
  const [state, dispatch] = useReducer(voteReducer, initialState);

  // Establish WebSocket connection for real-time updates with reconnection attempts
  useEffect(() => {
    const socket = io(process.env.REACT_APP_SOCKET_URL, {
      reconnectionAttempts: 3,  // Retry connection up to 3 times
      reconnectionDelay: 1000,  // Wait 1 second between attempts
    });

    // Handle vote results received from the server
    socket.on('voteResults', (voteResults) => {
      dispatch({ type: VOTE_UPDATED, payload: voteResults });
    });

    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
    });

    // Clean up the WebSocket connection when the component unmounts
    return () => {
      socket.disconnect();
    };
  }, []);

  // Submit a vote
  const submitVote = async (voteData) => {
    dispatch({ type: SET_LOADING, payload: true });
    try {
      const response = await fetch('/api/votes', {
        method: 'POST',
        body: JSON.stringify(voteData),
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        throw new Error(`Failed to submit vote: ${response.status}`);
      }
      const result = await response.json();
      dispatch({ type: VOTE_SUBMITTED, payload: result });
      dispatch({ type: SET_USER_VOTE, payload: result });
    } catch (error) {
      console.error('Error submitting vote:', error);
      // Optionally, add additional error handling here, like updating a state to show error messages to users
    } finally {
      dispatch({ type: SET_LOADING, payload: false });
    }
  };

  // Return the context provider with necessary values
  return (
    <VoteContext.Provider value={{ ...state, submitVote }}>
      {children}
    </VoteContext.Provider>
  );
};

// Custom hook to use the vote context
export const useVoteContext = () => useContext(VoteContext);
