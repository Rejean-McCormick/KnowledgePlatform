// /src/security/dataPrivacy.js

const User = require('../models/userModel');
const logger = require('../utils/loggerService');

class DataPrivacyService {
  /**
   * Handle user consent for data collection.
   * @param {String} userId - The ID of the user giving consent.
   * @param {Boolean} consentGiven - Whether the user has given consent.
   */
  async handleUserConsent(userId, consentGiven) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      user.dataConsent = consentGiven;
      await user.save();

      logger.info(`User ${userId} consent updated to: ${consentGiven}`);
      return { message: 'User consent updated successfully.' };
    } catch (error) {
      logger.error(`Error updating user consent for ${userId}: ${error.message}`);
      throw new Error('Failed to update user consent.');
    }
  }

  /**
   * Anonymize user data upon request.
   * @param {String} userId - The ID of the user requesting anonymization.
   */
  async anonymizeUserData(userId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // Anonymize user data
      user.name = 'Anonymous';
      user.email = `${userId}@anon.com`;
      user.dataConsent = false; // Disable further data collection
      await user.save();

      logger.info(`User data anonymized for ${userId}`);
      return { message: 'User data anonymized successfully.' };
    } catch (error) {
      logger.error(`Error anonymizing data for ${userId}: ${error.message}`);
      throw new Error('Failed to anonymize user data.');
    }
  }

  /**
   * Handle data deletion requests to comply with GDPR/CCPA.
   * @param {String} userId - The ID of the user requesting data deletion.
   */
  async deleteUserData(userId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // Permanently delete the user
      await user.remove();

      logger.info(`User data deleted for ${userId}`);
      return { message: 'User data deleted successfully.' };
    } catch (error) {
      logger.error(`Error deleting data for ${userId}: ${error.message}`);
      throw new Error('Failed to delete user data.');
    }
  }

  /**
   * Fetch a user's data for access requests.
   * @param {String} userId - The ID of the user requesting their data.
   * @returns {Object} The user's data.
   */
  async fetchUserData(userId) {
    try {
      const user = await User.findById(userId).select('-password -_id');
      if (!user) {
        throw new Error('User not found');
      }

      logger.info(`User data fetched for ${userId}`);
      return user;
    } catch (error) {
      logger.error(`Error fetching data for ${userId}: ${error.message}`);
      throw new Error('Failed to fetch user data.');
    }
  }
}

module.exports = new DataPrivacyService();
