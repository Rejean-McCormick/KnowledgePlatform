// /src/security/rateLimiter.js

const rateLimit = require('express-rate-limit');
const logger = require('../utils/loggerService');

// Define a rate limit for API requests
const apiRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 100, // limit each user to 100 requests per windowMs
  message: {
    message: 'Too many requests from this IP, please try again after 15 minutes.',
  },
  headers: true,
  handler: function (req, res, next, options) {
    logger.warn(`Rate limit exceeded for IP: ${req.ip}`);
    res.status(options.statusCode).send(options.message);
  }
});

// Define a more strict rate limit for key services like voting and collaboration
const votingRateLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes window
  max: 50, // limit each user to 50 voting or collaboration requests per windowMs
  message: {
    message: 'Too many voting or collaboration requests, please try again later.',
  },
  headers: true,
  handler: function (req, res, next, options) {
    logger.warn(`Voting/Collaboration rate limit exceeded for IP: ${req.ip}`);
    res.status(options.statusCode).send(options.message);
  }
});

module.exports = {
  apiRateLimiter,
  votingRateLimiter,
};
