const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config/authConfig');
const logger = require('../utils/loggerService');
const User = require('../models/User');

class AuthMiddleware {
  /**
   * Middleware to validate JWT tokens for protected routes.
   * Ensures that only authenticated users can access protected data.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object.
   * @param {Function} next - The next middleware function in the stack.
   */
  async validateToken(req, res, next) {
    try {
      // Get token from Authorization header
      const token = req.headers.authorization && req.headers.authorization.split(' ')[1];
      if (!token) {
        return res.status(401).json({ message: 'No token provided. Access denied.' });
      }

      // Verify the token
      const decoded = jwt.verify(token, jwtSecret);
      req.user = await User.findById(decoded.id); // Attach full user data to request
      if (!req.user) {
        return res.status(401).json({ message: 'Invalid token. User not found.' });
      }

      logger.info(`User authenticated with ID: ${req.user.id}`);
      next();
    } catch (error) {
      logger.error(`Invalid token: ${error.message}`);
      return res.status(401).json({ message: 'Invalid token. Access denied.' });
    }
  }

  /**
   * Middleware to restrict access to specific roles (e.g., 'admin', 'specialist').
   * @param {Array} roles - Array of allowed roles.
   * @returns {Function} Middleware function to restrict access.
   */
  restrictToRoles(roles) {
    return (req, res, next) => {
      const userRole = req.user.role; // Extract role from authenticated user
      if (!roles.includes(userRole)) {
        return res.status(403).json({ message: 'Access forbidden: insufficient role.' });
      }
      next();
    };
  }

  /**
   * Middleware to ensure user is part of the Council of Influence.
   * Only Council members can access certain features.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object.
   * @param {Function} next - The next middleware function in the stack.
   */
  checkCouncilMember(req, res, next) {
    if (req.user.isCouncilMember) {
      return next();
    }
    return res.status(403).json({ message: 'Access restricted to Council of Influence members.' });
  }
}

module.exports = new AuthMiddleware();
