// /src/security/ethicsModeration.js

const User = require('../models/userModel');
const logger = require('../utils/loggerService');

class EthicsModerationService {
  /**
   * Track user behavior and penalize unethical actions.
   * Reduces vote weight or temporarily suspends user accounts.
   * 
   * @param {String} userId - The ID of the user being monitored.
   * @param {Object} behaviorReport - An object containing the report of unethical behavior.
   * @returns {Object} Updated user status or penalties applied.
   */
  async trackBehavior(userId, behaviorReport) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // Analyze the behavior report to determine the severity of the action
      const { unethicalActions, severity } = behaviorReport;

      if (severity > 5) {
        // Severe actions result in temporary suspension
        user.isSuspended = true;
        user.suspensionReason = 'Severe unethical behavior';
        await user.save();
        logger.info(`User ${userId} suspended due to severe unethical behavior.`);
        return { status: 'User suspended', suspensionReason: 'Severe unethical behavior' };
      }

      // For moderate unethical actions, reduce the user's vote weight
      if (severity > 2) {
        user.voteWeight = Math.max(1, user.voteWeight - 2); // Decrease vote weight by 2 points
        await user.save();
        logger.info(`User ${userId} vote weight reduced due to unethical behavior.`);
        return { status: 'Vote weight reduced', newVoteWeight: user.voteWeight };
      }

      logger.info(`User ${userId} behavior report processed without penalties.`);
      return { status: 'No penalties applied' };
    } catch (error) {
      logger.error(`Error processing behavior report for user ${userId}: ${error.message}`);
      throw new Error('Failed to process behavior report.');
    }
  }

  /**
   * Reinstate user privileges after suspension or penalty period.
   * @param {String} userId - The ID of the user being reinstated.
   * @returns {Object} Updated user status after reinstatement.
   */
  async reinstateUser(userId) {
    try {
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // Reinstate user's voting rights and lift suspension if applicable
      user.isSuspended = false;
      user.suspensionReason = null;
      user.voteWeight = Math.min(10, user.voteWeight + 2); // Restore vote weight
      await user.save();

      logger.info(`User ${userId} reinstated with normal privileges.`);
      return { status: 'User reinstated', newVoteWeight: user.voteWeight };
    } catch (error) {
      logger.error(`Error reinstating user ${userId}: ${error.message}`);
      throw new Error('Failed to reinstate user.');
    }
  }
}

module.exports = new EthicsModerationService();
