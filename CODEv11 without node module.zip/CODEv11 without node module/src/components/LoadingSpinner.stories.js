import React from 'react';
import LoadingSpinner from './LoadingSpinner';

export default {
  title: 'Components/LoadingSpinner',
  component: LoadingSpinner,
};

export const DefaultSpinner = () => <LoadingSpinner />;
