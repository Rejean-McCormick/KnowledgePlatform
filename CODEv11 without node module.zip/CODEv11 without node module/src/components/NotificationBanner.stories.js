import React from 'react';
import NotificationBanner from './NotificationBanner';

export default {
  title: 'Components/NotificationBanner',
  component: NotificationBanner,
};

const Template = (args) => <NotificationBanner {...args} />;

export const InfoNotification = Template.bind({});
InfoNotification.args = {
  message: 'This is an info notification',
  type: 'info',
  onClose: () => alert('Notification closed'),
};

export const SuccessNotification = Template.bind({});
SuccessNotification.args = {
  message: 'This is a success notification',
  type: 'success',
  onClose: () => alert('Notification closed'),
};
