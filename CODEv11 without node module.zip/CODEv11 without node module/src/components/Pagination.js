// Pagination.js

import React from 'react';
import PropTypes from 'prop-types';
import './Pagination.module.css'; // Assuming you have a CSS module for styling

const Pagination = ({ totalPages, currentPage, onPageChange }) => {
  const createPagination = () => {
    let pages = [];

    for (let i = 1; i <= totalPages; i++) {
      pages.push(
        <button
          key={i}
          className={`page-item ${i === currentPage ? 'active' : ''}`}
          onClick={() => onPageChange(i)}
          disabled={i === currentPage}
        >
          {i}
        </button>
      );
    }

    return pages;
  };

  const handlePrevClick = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNextClick = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  return (
    <div className="pagination-container">
      <button
        className="prev-button"
        onClick={handlePrevClick}
        disabled={currentPage === 1}
      >
        Prev
      </button>
      {createPagination()}
      <button
        className="next-button"
        onClick={handleNextClick}
        disabled={currentPage === totalPages}
      >
        Next
      </button>
    </div>
  );
};

// Define the expected prop types
Pagination.propTypes = {
  totalPages: PropTypes.number.isRequired,
  currentPage: PropTypes.number.isRequired,
  onPageChange: PropTypes.func.isRequired,
};

export default Pagination;
