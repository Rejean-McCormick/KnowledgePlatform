import React from 'react';
import PropTypes from 'prop-types';
import './UserAvatar.module.css';

const UserAvatar = ({ imageUrl, name }) => {
  const getInitials = (fullName) => {
    return fullName
      .split(' ')
      .map((n) => n[0])
      .join('');
  };

  return (
    <div className="user-avatar" aria-label={name} role="img">
      {imageUrl ? (
        <img src={imageUrl} alt={`${name}'s avatar`} className="avatar-image" />
      ) : (
        <div className="avatar-fallback">{getInitials(name)}</div>
      )}
    </div>
  );
};

UserAvatar.propTypes = {
  imageUrl: PropTypes.string,
  name: PropTypes.string.isRequired,
};

export default UserAvatar;
 
