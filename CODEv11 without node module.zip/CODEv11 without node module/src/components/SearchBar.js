import React, { useState } from 'react';
import PropTypes from 'prop-types';
import './SearchBar.module.css';

const SearchBar = ({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (event) => {
    event.preventDefault();
    if (searchTerm.trim() !== '') {
      onSearch(searchTerm);
    } else {
      alert('Please enter a valid search term');
    }
  };

  return (
    <form className="search-bar" onSubmit={handleSearch} role="search">
      <label htmlFor="search-input" className="sr-only">Search</label>
      <input
        type="text"
        id="search-input"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search..."
        aria-label="Search for content"
      />
      <button type="submit" className="search-button" aria-label="Submit search">
        Search
      </button>
    </form>
  );
};

SearchBar.propTypes = {
  onSearch: PropTypes.func.isRequired,
};

export default SearchBar;
 
