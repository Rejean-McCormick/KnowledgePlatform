import React from 'react';
import PropTypes from 'prop-types';
import './NotificationBanner.module.css'; // Importing the CSS module for notification banner styles

/**
 * NotificationBanner Component: A reusable banner to display notifications or alerts.
 *
 * Props:
 * - message: The text content of the notification.
 * - type: Type of notification (success, error, warning).
 */
const NotificationBanner = ({ message, type = 'info' }) => {
  const bannerClass = `notification-banner ${type}`;

  return (
    <div className={bannerClass} role="alert">
      <p>{message}</p>
    </div>
  );
};

// Prop types validation for NotificationBanner component
NotificationBanner.propTypes = {
  message: PropTypes.string.isRequired, // The notification message text
  type: PropTypes.oneOf(['success', 'error', 'warning', 'info']), // Type of notification
};

// Default props for NotificationBanner
NotificationBanner.defaultProps = {
  type: 'info',
};

export default NotificationBanner;
