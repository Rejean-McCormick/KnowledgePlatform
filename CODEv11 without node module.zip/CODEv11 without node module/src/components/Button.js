import React from 'react';
import PropTypes from 'prop-types';
import './Button.module.css'; // Importing the CSS module for button styles

/**
 * Button component: A reusable button element that triggers an action on click.
 * It can be customized with different labels, actions, and states.
 *
 * Props:
 * - label: The text displayed on the button.
 * - onClick: The function to be called when the button is clicked.
 * - disabled: Disables the button when set to true.
 * - type: The type of the button (submit, button, etc.).
 */
const Button = ({ label, onClick, disabled, type = 'button' }) => {
  return (
    <button
      className="button" // Apply CSS styles from the module
      onClick={onClick}
      disabled={disabled}
      type={type}
    >
      {label}
    </button>
  );
};

// Define prop types for the Button component
Button.propTypes = {
  label: PropTypes.string.isRequired, // The button label is required and must be a string
  onClick: PropTypes.func.isRequired, // onClick handler is required and must be a function
  disabled: PropTypes.bool,           // disabled is optional and should be a boolean
  type: PropTypes.string,             // type is optional and should be a string, default is 'button'
};

// Define default props in case they are not passed
Button.defaultProps = {
  disabled: false,    // Default button is not disabled
  type: 'button',     // Default button type is 'button'
};

export default Button;
