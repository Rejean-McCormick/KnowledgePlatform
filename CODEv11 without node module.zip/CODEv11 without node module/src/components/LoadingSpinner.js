import React from 'react';
import PropTypes from 'prop-types';
import './LoadingSpinner.module.css'; // Importing CSS for loading spinner styles

/**
 * LoadingSpinner Component: A reusable spinner for indicating data fetching or processing.
 *
 * Props:
 * - size: The size of the spinner (small, medium, large).
 * - color: Optional prop to specify the color of the spinner.
 */
const LoadingSpinner = ({ size = 'medium', color = 'blue' }) => {
  return (
    <div className={`spinner spinner-${size}`} style={{ borderColor: color }}>
      <div className="spinner-inner" />
    </div>
  );
};

// Prop types validation for LoadingSpinner component
LoadingSpinner.propTypes = {
  size: PropTypes.oneOf(['small', 'medium', 'large']), // Spinner size should be one of the allowed values
  color: PropTypes.string, // Optional color prop
};

// Default props for LoadingSpinner
LoadingSpinner.defaultProps = {
  size: 'medium',
  color: 'blue',
};

export default LoadingSpinner;
