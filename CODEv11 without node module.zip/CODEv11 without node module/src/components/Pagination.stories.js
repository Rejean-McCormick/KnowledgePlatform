import React from 'react';
import Pagination from './Pagination';

export default {
  title: 'Components/Pagination',
  component: Pagination,
};

const Template = (args) => <Pagination {...args} />;

export const DefaultPagination = Template.bind({});
DefaultPagination.args = {
  totalPages: 10,
  currentPage: 1,
  onPageChange: (page) => alert(`Page changed to: ${page}`),
};
