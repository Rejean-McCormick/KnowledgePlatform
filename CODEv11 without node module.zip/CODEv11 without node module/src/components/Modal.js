import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import './Modal.module.css';

/**
 * Modal Component: A reusable, accessible modal window with customizable content.
 *
 * Props:
 * - isOpen: Boolean that determines if the modal is visible.
 * - onClose: Function to close the modal.
 * - title: The title of the modal.
 * - children: The content to be displayed inside the modal.
 * - footer: Optional content for the footer (e.g., buttons).
 */
const Modal = ({ isOpen, onClose, title, children, footer }) => {
  // Close modal on 'ESC' key press for better accessibility
  useEffect(() => {
    const handleEsc = (event) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null; // Don't render if modal is closed

  return (
    <div className="modal-overlay" aria-modal="true" role="dialog">
      <div className="modal">
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="modal-close-button" onClick={onClose} aria-label="Close">
            &times;
          </button>
        </div>
        <div className="modal-content">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
};

// PropTypes validation
Modal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  title: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired,
  footer: PropTypes.node, // Optional footer for buttons or additional content
};

// Default props
Modal.defaultProps = {
  footer: null,
};

export default Modal;
