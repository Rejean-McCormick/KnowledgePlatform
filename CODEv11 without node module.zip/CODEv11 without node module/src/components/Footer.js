import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.module.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <p>&copy; 2024 Knowledge Platform. All rights reserved.</p>
        <ul className="footer-nav">
          <li>
            <Link to="/terms" aria-label="Terms of Service">Terms of Service</Link>
          </li>
          <li>
            <Link to="/privacy" aria-label="Privacy Policy">Privacy Policy</Link>
          </li>
        </ul>
        <ul className="social-media">
          <li>
            <a href="https://facebook.com" aria-label="Facebook">
              <img src="/images/facebook-icon.png" alt="Facebook" />
            </a>
          </li>
          <li>
            <a href="https://twitter.com" aria-label="Twitter">
              <img src="/images/twitter-icon.png" alt="Twitter" />
            </a>
          </li>
          <li>
            <a href="https://linkedin.com" aria-label="LinkedIn">
              <img src="/images/linkedin-icon.png" alt="LinkedIn" />
            </a>
          </li>
        </ul>
      </div>
    </footer>
  );
};

export default Footer;
 
