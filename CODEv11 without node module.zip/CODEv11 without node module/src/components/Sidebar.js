import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.module.css';

const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const handleToggle = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <aside className={`sidebar ${isCollapsed ? 'collapsed' : ''}`} aria-label="Sidebar Navigation">
      <button
        type="button"
        className="toggle-button"
        onClick={handleToggle}
        aria-expanded={!isCollapsed}
        aria-controls="sidebar-nav"
        aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {isCollapsed ? '>' : '<'}
      </button>
      <nav id="sidebar-nav" className="sidebar-nav" role="navigation">
        <ul>
          <li>
            <Link to="/dashboard" aria-label="Dashboard">Dashboard</Link>
          </li>
          <li>
            <Link to="/admin/users" aria-label="Manage Users">Manage Users</Link>
          </li>
          <li>
            <Link to="/admin/content" aria-label="Moderate Content">Moderate Content</Link>
          </li>
          <li>
            <Link to="/admin/settings" aria-label="Settings">Settings</Link>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
 
