import React from 'react';
import Button from './Button';

export default {
  title: 'Components/Button',
  component: Button,
};

const Template = (args) => <Button {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  type: 'button',
  styleType: 'primary',
  ariaLabel: 'Primary Button',
  children: 'Primary Button',
};

export const Secondary = Template.bind({});
Secondary.args = {
  type: 'button',
  styleType: 'secondary',
  ariaLabel: 'Secondary Button',
  children: 'Secondary Button',
};

export const Disabled = Template.bind({});
Disabled.args = {
  type: 'button',
  styleType: 'primary',
  ariaLabel: 'Disabled Button',
  children: 'Disabled Button',
  onClick: () => alert('Button Clicked'),
};
