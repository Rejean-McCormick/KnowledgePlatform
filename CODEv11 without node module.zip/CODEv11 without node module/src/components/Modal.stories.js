import React from 'react';
import Modal from './Modal';

export default {
  title: 'Components/Modal',
  component: Modal,
};

const Template = (args) => <Modal {...args} />;

export const OpenModal = Template.bind({});
OpenModal.args = {
  isOpen: true,
  ariaLabel: 'Modal Window',
  children: 'This is an open modal!',
  onClose: () => alert('Modal closed'),
};
