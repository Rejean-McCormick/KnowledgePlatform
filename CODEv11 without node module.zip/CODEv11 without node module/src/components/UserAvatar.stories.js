import React from 'react';
import UserAvatar from './UserAvatar';

export default {
  title: 'Components/UserAvatar',
  component: UserAvatar,
};

const Template = (args) => <UserAvatar {...args} />;

export const WithImage = Template.bind({});
WithImage.args = {
  imageUrl: 'https://example.com/avatar.jpg',
  name: 'John Doe',
};

export const WithoutImage = Template.bind({});
WithoutImage.args = {
  imageUrl: '',
  name: 'John Doe',
};
