const mongoose = require('mongoose');

const mentorshipSchema = new mongoose.Schema({
  mentor: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },  // References the mentor (User)
  mentee: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },  // References the mentee (User)
  goals: {
    type: String, 
    required: true, 
  },  // Specific goals or objectives for the mentorship
  progress: { 
    type: Number, 
    default: 0 
  },  // Tracks the progress of the mentorship (0 to 100)
  meetingLogs: [{ 
    date: { type: Date }, 
    notes: { type: String } 
  }],  // Logs of mentor-mentee meetings
  feedback: {
    mentorFeedback: { 
      type: String 
    },  // Feedback provided by the mentor
    menteeFeedback: { 
      type: String 
    },  // Feedback provided by the mentee
  },
  ratings: {
    mentorRating: { 
      type: Number, 
      min: 1, 
      max: 5 
    },  // Rating given by the mentee to the mentor
    menteeRating: { 
      type: Number, 
      min: 1, 
      max: 5 
    },  // Rating given by the mentor to the mentee
  },
  startDate: { 
    type: Date, 
    default: Date.now 
  },  // The date the mentorship started
  endDate: { 
    type: Date 
  },  // Optional: The date the mentorship ended
  status: {
    type: String,
    enum: ['active', 'completed', 'cancelled'],  // Tracks the current status of the mentorship
    default: 'active',
  },
  completionCriteria: { 
    type: String 
  },  // Optional criteria for completing the mentorship
});

module.exports = mongoose.model('Mentorship', mentorshipSchema);
