const { User } = require('../models/User');

// Badge System Configuration
const badgeCriteria = {
  contributor: { votesSubmitted: 10, reputation: 50 },
  influencer: { influenceScore: 100 },
  ethicalLeader: { ethicalStanding: 90 },
  earlyAdopter: { registrationDate: '2023-01-01' }, // Example for early adopters
};

// Check if a user qualifies for a specific badge
const qualifiesForBadge = (user, badge) => {
  const criteria = badgeCriteria[badge];

  switch (badge) {
    case 'contributor':
      return user.votesSubmitted >= criteria.votesSubmitted && user.reputation >= criteria.reputation;
    case 'influencer':
      return user.influenceScore >= criteria.influenceScore;
    case 'ethicalLeader':
      return user.ethicalStanding >= criteria.ethicalStanding;
    case 'earlyAdopter':
      return new Date(user.registrationDate) <= new Date(criteria.registrationDate);
    default:
      return false;
  }
};

// Assign badges to users based on their metrics
const assignBadges = async (userId) => {
  const user = await User.findById(userId);
  if (!user) {
    throw new Error('User not found');
  }

  const newBadges = [];
  for (const badge in badgeCriteria) {
    if (qualifiesForBadge(user, badge) && !user.badges.includes(badge)) {
      user.badges.push(badge);
      newBadges.push(badge);
    }
  }

  if (newBadges.length > 0) {
    await user.save();
  }

  return newBadges;
};

// Get all badges that a user has earned
const getUserBadges = async (userId) => {
  const user = await User.findById(userId);
  if (!user) {
    throw new Error('User not found');
  }

  return user.badges;
};

// Progress tracking for next badge
const getUserProgress = async (userId) => {
  const user = await User.findById(userId);
  if (!user) {
    throw new Error('User not found');
  }

  const progress = {};

  for (const badge in badgeCriteria) {
    if (!user.badges.includes(badge)) {
      const criteria = badgeCriteria[badge];

      switch (badge) {
        case 'contributor':
          progress[badge] = {
            votesSubmitted: `${user.votesSubmitted}/${criteria.votesSubmitted}`,
            reputation: `${user.reputation}/${criteria.reputation}`,
          };
          break;
        case 'influencer':
          progress[badge] = {
            influenceScore: `${user.influenceScore}/${criteria.influenceScore}`,
          };
          break;
        case 'ethicalLeader':
          progress[badge] = {
            ethicalStanding: `${user.ethicalStanding}/${criteria.ethicalStanding}`,
          };
          break;
        case 'earlyAdopter':
          progress[badge] = user.registrationDate <= criteria.registrationDate ? 'Qualified' : 'Not Qualified';
          break;
        default:
          progress[badge] = 'No progress';
      }
    }
  }

  return progress;
};

module.exports = {
  assignBadges,
  getUserBadges,
  getUserProgress,
};
