const mongoose = require('mongoose');

const badgeSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true 
  },  // Name of the badge
  description: { 
    type: String, 
    required: true 
  },  // Description of what the badge represents
  criteria: { 
    type: String, 
    required: true 
  },  // Criteria for earning the badge (e.g., vote count, reputation)
  category: { 
    type: String, 
    enum: ['contribution', 'ethical', 'voting', 'special'], 
    required: true 
  },  // Category or type of the badge
  iconUrl: { 
    type: String 
  },  // URL to the badge icon
  awardedAt: { 
    type: Date, 
    default: Date.now 
  },  // Date when the badge was awarded
  users: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  }],  // Users who have earned this badge
  isRevocable: { 
    type: Boolean, 
    default: false 
  },  // Whether the badge can be revoked
  expiresAt: { 
    type: Date 
  },  // Optional: Expiration date for the badge, if temporary
});

module.exports = mongoose.model('Badge', badgeSchema);
