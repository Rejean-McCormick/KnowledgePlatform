const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { 
    type: String, 
    required: true, 
    unique: true 
  }, // Tracks the username
  email: { 
    type: String, 
    required: true, 
    unique: true 
  }, // User's email address
  password: { 
    type: String, 
    required: true 
  }, // User's hashed password
  reputation: { 
    type: Number, 
    default: 0 
  }, // Tracks user's reputation based on contributions
  influenceScore: { 
    type: Number, 
    default: 0 
  }, // Tracks user's influence score, impacted by AI moderation
  ethicalStanding: { 
    type: Number, 
    default: 0 
  }, // Tracks user's ethical behavior
  role: {
    type: String,
    enum: ['student', 'specialist', 'mentor', 'mentee', 'admin', 'shadow', 'titan', 'councilMember'], // Dynamic roles assigned by AI
    default: 'student'
  },
  badges: [
    { type: String }
  ], // Array of badges awarded to the user
  registrationDate: { 
    type: Date, 
    default: Date.now 
  }, // Date the user registered
  lastLogin: { 
    type: Date 
  }, // Tracks the user's last login
  hasAgreedToTerms: { 
    type: Boolean, 
    default: false 
  }, // Tracks user agreement to the platform's terms of service
  hasUpdatedPrivacyPolicy: { 
    type: Boolean, 
    default: false 
  }, // Tracks user consent to updated privacy policies
  voteHistory: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Vote' 
  }], // References to the user's votes
  contributions: { 
    type: Number, 
    default: 0 
  }, // Tracks user contributions, like votes and discussions
  isCouncilMember: { 
    type: Boolean, 
    default: false 
  }, // Whether the user is a part of the Council of Influence
  suspended: { 
    type: Boolean, 
    default: false 
  }, // Tracks if the user is suspended due to unethical behavior
  suspensionReason: { 
    type: String, 
    default: null 
  }, // Reason for user suspension, if applicable
  voteWeight: { 
    type: Number, 
    default: 1 
  }, // User's default vote weight, can be adjusted by AI
}, {
  timestamps: true // Automatically adds createdAt and updatedAt fields
});

// Pre-save hook to assign badges based on contributions
userSchema.pre('save', function(next) {
  if (this.contributions >= 100 && !this.badges.includes('Contributor')) {
    this.badges.push('Contributor');
  }
  next();
});

module.exports = mongoose.model('User', userSchema);
