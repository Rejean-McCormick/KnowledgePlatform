const mongoose = require('mongoose');

const voteSchema = new mongoose.Schema({
  issue: { 
    type: String, 
    required: true 
  },  // The issue or question being voted on
  option: { 
    type: String, 
    required: true 
  },  // The option selected by the user
  weight: { 
    type: Number, 
    required: true 
  },  // Vote weight, influenced by AI and user metrics
  user: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },  // Reference to the user who voted
  voteSessionId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'VoteSession', 
    required: true 
  },  // The session or context for the vote
  isAIAdjusted: { 
    type: Boolean, 
    default: false 
  },  // Whether the vote weight was adjusted by AI
  expertiseScore: { 
    type: Number, 
    default: 0 
  },  // User expertise score at the time of voting
  councilVerified: { 
    type: Boolean, 
    default: false 
  },  // Whether the vote was verified by the Council of Influence
  validationErrors: [{ 
    type: String 
  }],  // Possible errors during vote submission or validation
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'flagged'],  // Status of the vote in case of moderation
    default: 'pending',
  },
  createdAt: { 
    type: Date, 
    default: Date.now 
  },  // The date the vote was cast
}, {
  timestamps: true,  // Automatically add createdAt and updatedAt fields
});

module.exports = mongoose.model('Vote', voteSchema);
