const mongoose = require('mongoose');

const voteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  itemId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  voteValue: {
    type: String,
    enum: ['for', 'against'],
    required: true,
  },
  weightedVote: {
    type: Number,
    required: true,
  },
  isAIAdjusted: {
    type: Boolean,
    default: false,
  },
  expertiseScore: {
    type: Number,
    default: 0,
  },
  councilVerified: {
    type: Boolean,
    default: false,
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'flagged'],
    default: 'pending',
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
});

const Vote = mongoose.model('Vote', voteSchema);

module.exports = Vote;
