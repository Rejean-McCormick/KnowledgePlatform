const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  name: {
    type: String,
    trim: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },
  password: {
    type: String,
    required: true,
  },
  reputation: {
    type: Number,
    default: 0, // Tracks user's reputation
  },
  expertise: {
    type: Number,
    default: 0, // Tracks user's expertise
  },
  influenceScore: {
    type: Number,
    default: 0, // Tracks user's influence score
  },
  ethicalStanding: {
    type: Number,
    default: 0, // Tracks user's ethical behavior
  },
  role: {
    type: String,
    enum: ['student', 'specialist', 'mentor', 'mentee', 'admin', 'shadow', 'titan', 'klown'], // Dynamic roles
    default: 'student',
  },
  badges: [
    {
      type: String,
      enum: ['contributor', 'influencer', 'ethical leader'],
    },
  ],
  registrationDate: {
    type: Date,
    default: Date.now, // Date the user registered
  },
  lastLogin: {
    type: Date, // Tracks the last login date of the user
  },
  isCouncilMember: {
    type: Boolean,
    default: false, // Council of Influence member
  },
  suspended: {
    type: Boolean,
    default: false, // If the user is suspended
  },
  suspensionReason: {
    type: String, // Reason for suspension
    default: null,
  },
  voteWeight: {
    type: Number,
    default: 1, // Default vote weight
  },
  dataConsent: {
    type: Boolean,
    default: true, // Tracks data processing consent
  },
  hasAgreedToTerms: {
    type: Boolean,
    default: false, // Tracks user agreement to terms
  },
  hasUpdatedPrivacyPolicy: {
    type: Boolean,
    default: false, // Tracks privacy policy agreement
  },
  contributions: {
    type: Number,
    default: 0, // Tracks user contributions
  },
  voteHistory: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Vote', // References the user's vote history
    },
  ],
}, {
  timestamps: true, // Adds createdAt and updatedAt fields
});

// Pre-save hook to handle badge awarding based on contributions
userSchema.pre('save', function (next) {
  if (this.contributions > 100 && !this.badges.includes('contributor')) {
    this.badges.push('contributor');
  }
  next();
});

const User = mongoose.model('User', userSchema);

module.exports = User;
