// /src/config/database.js

const mongoose = require('mongoose');
const { Pool } = require('pg');
const logger = require('../utils/loggerService');

// Environment variables for database configuration
const isMongoDB = process.env.DB_TYPE === 'mongodb';
const dbURI = process.env.DB_URI;
const postgresConfig = {
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DATABASE,
  password: process.env.PG_PASSWORD,
  port: process.env.PG_PORT,
};

// Connect to MongoDB
async function connectMongoDB() {
  try {
    await mongoose.connect(dbURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    logger.info('Connected to MongoDB');
  } catch (error) {
    logger.error(`MongoDB connection error: ${error.message}`);
    process.exit(1); // Exit process on failure
  }
}

// Connect to PostgreSQL
async function connectPostgreSQL() {
  try {
    const pool = new Pool(postgresConfig);
    await pool.connect();
    logger.info('Connected to PostgreSQL');
    return pool;
  } catch (error) {
    logger.error(`PostgreSQL connection error: ${error.message}`);
    process.exit(1); // Exit process on failure
  }
}

// Determine which database to connect to
async function connectDatabase() {
  if (isMongoDB) {
    await connectMongoDB();
  } else {
    await connectPostgreSQL();
  }
}

module.exports = connectDatabase;
