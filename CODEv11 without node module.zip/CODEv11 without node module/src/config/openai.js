// /src/config/openai.js

module.exports = {
  openaiApiKey: process.env.OPENAI_API_KEY || 'your-openai-api-key-here',
  openaiEndpoint: process.env.OPENAI_ENDPOINT || 'https://api.openai.com/v1/completions',
};
