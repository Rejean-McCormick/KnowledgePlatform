// /src/config/authConfig.js

module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'defaultSecretKey', // Secret key for signing JWTs
  jwtExpiration: process.env.JWT_EXPIRATION || '1h', // Token expiration time (default: 1 hour)
};
