const i18n = require('i18n');
const path = require('path');

// Configure i18n for localization
i18n.configure({
  locales: ['en', 'es', 'fr', 'de'], // Supported languages: English, Spanish, French, German
  directory: path.join(__dirname, '../locales'), // Directory where translation files are stored
  defaultLocale: 'en', // Default language
  objectNotation: true, // Allows for nested translation keys
  cookie: 'locale', // Cookie name to store user preference
  queryParameter: 'lang', // Query parameter for language selection (e.g., ?lang=es)
  directoryPermissions: '755',
  autoReload: true, // Automatically reload translation files if they are changed
  syncFiles: true, // Keep all language files in sync with each other
});

// Middleware to set the language based on user preference
const setLocale = (req, res, next) => {
  const userLanguage = req.query.lang || req.cookies.locale || req.headers['accept-language'] || 'en';
  req.setLocale(userLanguage);
  next();
};

// Function to translate messages in the API
const translateMessage = (key, req, params = {}) => {
  return req.__(key, params); // Use i18n's translation function with the key and optional params
};

module.exports = {
  i18n,
  setLocale,
  translateMessage,
};
