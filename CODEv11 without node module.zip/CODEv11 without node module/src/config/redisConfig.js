// /src/config/redisConfig.js

const redis = require('redis');
const logger = require('../utils/loggerService');

// Configure Redis client
const redisClient = redis.createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379',
  legacyMode: true, // Enables backward compatibility with older Redis client versions
});

redisClient.on('connect', () => {
  logger.info('Connected to Redis cache');
});

redisClient.on('error', (error) => {
  logger.error(`Redis connection error: ${error.message}`);
});

/**
 * Function to initialize Redis client connection.
 */
async function initializeRedis() {
  try {
    await redisClient.connect();
    logger.info('Redis client connected');
  } catch (error) {
    logger.error(`Error initializing Redis: ${error.message}`);
    process.exit(1); // Exit the process if Redis connection fails
  }
}

module.exports = {
  getRedisClient: () => redisClient,
  initializeRedis,
};
