const { exec } = require('child_process');
const fs = require('fs');
const logger = require('../src/utils/loggerService');

// Define backup and restore paths
const backupDir = '/backups'; // Directory where backups are stored
const databaseBackupFile = `${backupDir}/platform_db_backup.sql`;
const logBackupFile = `${backupDir}/logs_backup.tar.gz`;

// Step 1: Check for backup availability
const checkBackupAvailability = () => {
  if (!fs.existsSync(databaseBackupFile) || !fs.existsSync(logBackupFile)) {
    throw new Error('Required backups are missing. Cannot proceed with recovery.');
  }
  logger.logInfo('Backups found. Proceeding with recovery.');
};

// Step 2: Restore the database from backup
const restoreDatabase = () => {
  logger.logInfo('Starting database restoration...');

  exec(`psql -U your_db_user -d your_db_name < ${databaseBackupFile}`, (error, stdout, stderr) => {
    if (error) {
      logger.logError('Error restoring the database', error);
      throw new Error('Failed to restore the database.');
    }
    logger.logInfo('Database restored successfully.');
  });
};

// Step 3: Restore log files
const restoreLogs = () => {
  logger.logInfo('Restoring log files from backup...');

  exec(`tar -xzvf ${logBackupFile} -C /logs`, (error, stdout, stderr) => {
    if (error) {
      logger.logError('Error restoring logs', error);
      throw new Error('Failed to restore log files.');
    }
    logger.logInfo('Log files restored successfully.');
  });
};

// Step 4: Restart platform services
const restartServices = () => {
  logger.logInfo('Restarting platform services...');

  exec('sudo systemctl restart platform-api platform-web', (error, stdout, stderr) => {
    if (error) {
      logger.logError('Error restarting services', error);
      throw new Error('Failed to restart platform services.');
    }
    logger.logInfo('Platform services restarted successfully.');
  });
};

// Step 5: Verify system health after recovery
const verifySystemHealth = () => {
  logger.logInfo('Verifying system health...');

  exec('curl -f http://localhost:3000/health', (error, stdout, stderr) => {
    if (error) {
      logger.logError('System health check failed', error);
      throw new Error('System health verification failed.');
    }
    logger.logInfo('System is healthy and operational.');
  });
};

// Main function to execute disaster recovery
const executeDisasterRecovery = async () => {
  try {
    logger.logInfo('Starting disaster recovery plan...');
    checkBackupAvailability();
    await restoreDatabase();
    await restoreLogs();
    await restartServices();
    verifySystemHealth();
    logger.logInfo('Disaster recovery completed successfully.');
  } catch (error) {
    logger.logError('Disaster recovery failed', error);
    throw new Error('Disaster recovery failed. Please check the logs for more details.');
  }
};

module.exports = {
  executeDisasterRecovery,
};
