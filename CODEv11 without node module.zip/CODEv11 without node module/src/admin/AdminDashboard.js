import React, { useEffect, useState } from 'react';

const AdminDashboard = () => {
  const [userMetrics, setUserMetrics] = useState([]);
  const [voteData, setVoteData] = useState([]);
  const [systemPerformance, setSystemPerformance] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch data for user metrics, votes, and system performance
    const fetchDashboardData = async () => {
      try {
        const [usersRes, votesRes, performanceRes] = await Promise.all([
          fetch('/api/admin/users/metrics'),
          fetch('/api/admin/votes'),
          fetch('/api/admin/system/performance')
        ]);

        const usersData = await usersRes.json();
        const votesData = await votesRes.json();
        const performanceData = await performanceRes.json();

        setUserMetrics(usersData);
        setVoteData(votesData);
        setSystemPerformance(performanceData);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching admin dashboard data:', error);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return <p>Loading admin dashboard...</p>;
  }

  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>

      <div className="section user-metrics">
        <h2>User Metrics</h2>
        <ul>
          {userMetrics.map((user) => (
            <li key={user.id}>
              <strong>{user.username}</strong>: Reputation - {user.reputation}, Influence Score - {user.influenceScore}
            </li>
          ))}
        </ul>
      </div>

      <div className="section vote-data">
        <h2>Vote Data</h2>
        <ul>
          {voteData.map((vote) => (
            <li key={vote.id}>
              <strong>Issue:</strong> {vote.issue}, <strong>Total Votes:</strong> {vote.totalVotes}
            </li>
          ))}
        </ul>
      </div>

      <div className="section system-performance">
        <h2>System Performance</h2>
        <ul>
          <li><strong>API Response Time:</strong> {systemPerformance.apiResponseTime} ms</li>
          <li><strong>Server Uptime:</strong> {systemPerformance.uptime} hours</li>
          <li><strong>Active Connections:</strong> {systemPerformance.activeConnections}</li>
        </ul>
      </div>
    </div>
  );
};

export default AdminDashboard;
