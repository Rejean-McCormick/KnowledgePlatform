import React, { useState, useContext } from 'react';
import { useHistory } from 'react-router-dom';
import { userContext } from '../state/userContext';

const AdminAuth = () => {
  const { setUser } = useContext(userContext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const history = useHistory();

  const handleAdminLogin = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/admin/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (response.ok) {
        // Store the admin user data and token in context
        setUser({
          id: data.admin.id,
          username: data.admin.username,
          token: data.token,
          role: 'admin',
        });
        history.push('/admin/dashboard'); // Redirect to admin dashboard
      } else {
        setError(data.message || 'Admin login failed. Please try again.');
      }
    } catch (error) {
      console.error('Error during admin login:', error);
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="admin-auth-page">
      <h1>Admin Login</h1>
      {error && <p className="error-message">{error}</p>}

      <form onSubmit={handleAdminLogin}>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" disabled={isLoading}>
          {isLoading ? 'Logging in...' : 'Login'}
        </button>
      </form>
    </div>
  );
};

export default AdminAuth;
