import React, { useEffect, useState } from 'react';
import { fetchUsers, assignMentor, fetchMentorships } from '../services/mentorshipService';

const AdminMentorship = () => {
  const [users, setUsers] = useState([]);
  const [mentorships, setMentorships] = useState([]);
  const [selectedMentor, setSelectedMentor] = useState(null);
  const [selectedMentee, setSelectedMentee] = useState(null);
  const [isAssigning, setIsAssigning] = useState(false);

  useEffect(() => {
    // Fetch users and mentorships when the component is mounted
    const fetchData = async () => {
      try {
        const usersData = await fetchUsers();
        const mentorshipData = await fetchMentorships();
        setUsers(usersData);
        setMentorships(mentorshipData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  const handleAssignMentor = async () => {
    if (!selectedMentor || !selectedMentee) {
      alert('Please select both a mentor and a mentee.');
      return;
    }

    setIsAssigning(true);

    try {
      await assignMentor(selectedMentor, selectedMentee);
      alert('Mentor assigned successfully!');
      
      // Refresh mentorships list
      const mentorshipData = await fetchMentorships();
      setMentorships(mentorshipData);
    } catch (error) {
      console.error('Error assigning mentor:', error);
      alert('Error assigning mentor.');
    } finally {
      setIsAssigning(false);
    }
  };

  return (
    <div className="admin-mentorship">
      <h1>Mentorship Management</h1>
      <div className="mentorship-form">
        <h2>Assign a Mentor</h2>
        <div className="form-group">
          <label htmlFor="mentorSelect">Select Mentor:</label>
          <select
            id="mentorSelect"
            value={selectedMentor || ''}
            onChange={(e) => setSelectedMentor(e.target.value)}
          >
            <option value="" disabled>Select a mentor</option>
            {users
              .filter((user) => user.role === 'mentor')
              .map((user) => (
                <option key={user.id} value={user.id}>
                  {user.username}
                </option>
              ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="menteeSelect">Select Mentee:</label>
          <select
            id="menteeSelect"
            value={selectedMentee || ''}
            onChange={(e) => setSelectedMentee(e.target.value)}
          >
            <option value="" disabled>Select a mentee</option>
            {users
              .filter((user) => user.role === 'mentee')
              .map((user) => (
                <option key={user.id} value={user.id}>
                  {user.username}
                </option>
              ))}
          </select>
        </div>

        <button onClick={handleAssignMentor} disabled={isAssigning}>
          {isAssigning ? 'Assigning...' : 'Assign Mentor'}
        </button>
      </div>

      <div className="mentorship-progress">
        <h2>Mentorship Progress</h2>
        {mentorships.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>Mentor</th>
                <th>Mentee</th>
                <th>Progress</th>
              </tr>
            </thead>
            <tbody>
              {mentorships.map((mentorship) => (
                <tr key={mentorship.id}>
                  <td>{mentorship.mentor.username}</td>
                  <td>{mentorship.mentee.username}</td>
                  <td>{mentorship.progress}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No mentorships available.</p>
        )}
      </div>
    </div>
  );
};

export default AdminMentorship;
