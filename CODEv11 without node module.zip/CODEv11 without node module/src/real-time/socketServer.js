const { Server } = require('socket.io');
const logger = require('../utils/loggerService');
const voteService = require('../services/voteService');

class SocketServer {
  constructor(server) {
    // Initialize WebSocket server
    this.io = new Server(server, {
      cors: {
        origin: '*', // Allow all origins
        methods: ['GET', 'POST'],
      },
    });

    // Handle incoming connections
    this.io.on('connection', (socket) => {
      logger.info(`User connected: ${socket.id}`);

      // Handle room joins for real-time vote result updates
      socket.on('joinRoom', (roomId) => {
        socket.join(roomId);
        logger.info(`User ${socket.id} joined room ${roomId}`);
      });

      // Handle real-time voting updates with voteService
      socket.on('voteUpdate', async (data) => {
        try {
          const { user, option, roomId } = data;
          const updatedVotes = await voteService.submitVote(user, option);
          this.io.to(roomId).emit('updateVoteResults', updatedVotes);
          logger.info(`Vote results updated in room ${roomId}`);
        } catch (error) {
          logger.error('Error processing vote:', error);
        }
      });

      // Handle role changes and send updates in real time
      socket.on('roleChange', (data) => {
        const { userId, newRole } = data;
        this.io.emit('roleUpdated', { userId, newRole });
        logger.info(`Role updated for user ${userId} to ${newRole}`);
      });

      // Handle disconnection
      socket.on('disconnect', () => {
        logger.info(`User disconnected: ${socket.id}`);
      });
    });
  }

  /**
   * Notify users of vote results in a specific room.
   * @param {String} roomId - The ID of the room.
   * @param {Object} voteResults - The vote results to send.
   */
  notifyVoteResults(roomId, voteResults) {
    this.io.to(roomId).emit('updateVoteResults', voteResults);
    logger.info(`Notified room ${roomId} of vote results`);
  }

  /**
   * Notify users of role changes.
   * @param {String} userId - The ID of the user.
   * @param {String} newRole - The new role of the user.
   */
  notifyRoleChange(userId, newRole) {
    this.io.emit('roleUpdated', { userId, newRole });
    logger.info(`Notified all users of role change for user ${userId} to ${newRole}`);
  }
}

module.exports = SocketServer;
