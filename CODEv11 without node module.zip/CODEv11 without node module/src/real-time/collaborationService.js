// /src/services/collaborationService.js

const { getSocketServer } = require('../real-time/socketServer');
const logger = require('../utils/loggerService');

class CollaborationService {
  constructor() {
    this.io = getSocketServer();
    this.activeRooms = {}; // To track active collaboration rooms
  }

  /**
   * Join or create a collaboration room for discussion before vote submission.
   * @param {String} roomId - The ID of the room for the vote discussion.
   * @param {String} userId - The ID of the user joining the room.
   */
  joinCollaborationRoom(roomId, userId) {
    try {
      if (!this.activeRooms[roomId]) {
        this.activeRooms[roomId] = [];
      }

      this.activeRooms[roomId].push(userId);
      logger.info(`User ${userId} joined room ${roomId}`);

      // Notify others in the room
      this.io.to(roomId).emit('userJoined', { userId, roomId });

      return this.activeRooms[roomId];
    } catch (error) {
      logger.error(`Error joining collaboration room ${roomId} for user ${userId}: ${error.message}`);
      throw new Error('Failed to join collaboration room.');
    }
  }

  /**
   * Leave the collaboration room and notify other users.
   * @param {String} roomId - The ID of the room being left.
   * @param {String} userId - The ID of the user leaving the room.
   */
  leaveCollaborationRoom(roomId, userId) {
    try {
      if (this.activeRooms[roomId]) {
        this.activeRooms[roomId] = this.activeRooms[roomId].filter(user => user !== userId);
        logger.info(`User ${userId} left room ${roomId}`);

        // Notify others in the room
        this.io.to(roomId).emit('userLeft', { userId, roomId });

        // Clean up if room is empty
        if (this.activeRooms[roomId].length === 0) {
          delete this.activeRooms[roomId];
        }

        return this.activeRooms[roomId];
      }
    } catch (error) {
      logger.error(`Error leaving collaboration room ${roomId} for user ${userId}: ${error.message}`);
      throw new Error('Failed to leave collaboration room.');
    }
  }

  /**
   * Broadcast a message to all users in the room.
   * @param {String} roomId - The ID of the room where the message is being sent.
   * @param {String} userId - The ID of the user sending the message.
   * @param {String} message - The message content.
   */
  broadcastMessage(roomId, userId, message) {
    try {
      if (!this.activeRooms[roomId]) {
        throw new Error('Room does not exist.');
      }

      // Emit the message to all users in the room
      this.io.to(roomId).emit('message', { userId, message });
      logger.info(`User ${userId} broadcasted message in room ${roomId}: ${message}`);
    } catch (error) {
      logger.error(`Error broadcasting message in room ${roomId} for user ${userId}: ${error.message}`);
      throw new Error('Failed to broadcast message.');
    }
  }
}

module.exports = new CollaborationService();
