// /src/real-time/notifyUsersInRealTime.js

const { getSocketServer } = require('./socketServer');
const logger = require('../utils/loggerService');

class NotifyUsersInRealTime {
  constructor() {
    this.io = getSocketServer();
  }

  /**
   * Notify users when a new vote is submitted.
   * @param {String} userId - The ID of the user who submitted the vote.
   * @param {String} itemId - The ID of the item being voted on.
   */
  notifyVoteSubmission(userId, itemId) {
    try {
      this.io.emit('voteSubmitted', { userId, itemId });
      logger.info(`User ${userId} submitted a vote for item ${itemId}`);
    } catch (error) {
      logger.error(`Error notifying vote submission: ${error.message}`);
    }
  }

  /**
   * Notify users when a role change occurs.
   * @param {String} userId - The ID of the user whose role changed.
   * @param {String} newRole - The new role assigned to the user.
   */
  notifyRoleChange(userId, newRole) {
    try {
      this.io.emit('roleChanged', { userId, newRole });
      logger.info(`User ${userId}'s role changed to ${newRole}`);
    } catch (error) {
      logger.error(`Error notifying role change: ${error.message}`);
    }
  }

  /**
   * Notify users when new content becomes available.
   * @param {String} contentTitle - The title of the new content.
   * @param {String} contentId - The ID of the new content.
   */
  notifyNewContent(contentTitle, contentId) {
    try {
      this.io.emit('newContent', { contentTitle, contentId });
      logger.info(`New content available: ${contentTitle} (ID: ${contentId})`);
    } catch (error) {
      logger.error(`Error notifying new content: ${error.message}`);
    }
  }
}

module.exports = new NotifyUsersInRealTime();
