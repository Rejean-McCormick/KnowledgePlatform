// /src/services/councilService.js

const UserMetricsService = require('./userMetrics');
const User = require('../models/userModel');
const logger = require('../utils/loggerService');

class CouncilService {
  /**
   * Select a rotating group of high-contributing users to form the Council of Influence.
   * @returns {Array} An array of user IDs representing the selected Council of Influence.
   */
  async selectCouncilOfInfluence() {
    try {
      // Fetch all users from the database
      const users = await User.find();

      // Calculate the contribution metrics for each user
      const userMetrics = await Promise.all(
        users.map(async (user) => {
          const metrics = await UserMetricsService.getUserMetrics(user._id);
          return {
            userId: user._id,
            reputation: metrics.reputation,
            expertise: metrics.expertise,
            ethicalStanding: metrics.ethicalStanding,
          };
        })
      );

      // Filter out high-contributing users based on metrics thresholds
      const highContributors = userMetrics.filter(
        (metrics) => metrics.reputation >= 80 && metrics.expertise >= 70 && metrics.ethicalStanding >= 75
      );

      // Sort high-contributing users by their reputation and expertise
      highContributors.sort((a, b) => {
        if (b.reputation !== a.reputation) {
          return b.reputation - a.reputation; // Sort by reputation first
        }
        return b.expertise - a.expertise; // Then sort by expertise
      });

      // Select the top 10 users for the Council of Influence
      const selectedCouncil = highContributors.slice(0, 10).map((user) => user.userId);

      logger.info(`Selected Council of Influence: ${selectedCouncil}`);
      return selectedCouncil;
    } catch (error) {
      logger.error(`Error selecting Council of Influence: ${error.message}`);
      throw new Error('Failed to select Council of Influence.');
    }
  }
}

module.exports = new CouncilService();
