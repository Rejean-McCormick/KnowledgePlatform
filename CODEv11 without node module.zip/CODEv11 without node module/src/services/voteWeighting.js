// /src/services/voteWeighting.js

const { calculateAIWeight } = require('../ai/aiVoteWeighting');
const UserMetricsService = require('./userMetrics');
const logger = require('../utils/loggerService');

class VoteWeightingService {
  /**
   * Calculate the final vote weight based on manual and AI-driven methods.
   * @param {String} userId - The ID of the user casting the vote.
   * @param {Number} baseVoteValue - The base value of the vote (1 to 10).
   * @returns {Number} The final calculated vote weight.
   */
  async calculateFinalVoteWeight(userId, baseVoteValue) {
    try {
      // Fetch user metrics (e.g., reputation, expertise, ethical standing)
      const userMetrics = await UserMetricsService.getUserMetrics(userId);
      
      // Manual vote weight calculation based on user metrics
      const manualWeight = this.calculateManualWeight(userMetrics);

      // AI-driven vote weight calculation
      const aiWeight = await calculateAIWeight(userId, baseVoteValue, userMetrics);

      // Combine manual and AI weights to calculate the final weight
      const finalWeight = this.combineWeights(manualWeight, aiWeight);

      logger.info(`Final vote weight calculated for user ${userId}: ${finalWeight}`);
      return finalWeight;
    } catch (error) {
      logger.error(`Error calculating vote weight for user ${userId}: ${error.message}`);
      throw new Error('Failed to calculate final vote weight.');
    }
  }

  /**
   * Calculate manual vote weight based on user metrics.
   * @param {Object} userMetrics - The user's metrics (e.g., reputation, expertise).
   * @returns {Number} The manually calculated vote weight.
   */
  calculateManualWeight(userMetrics) {
    const { reputation, expertise, ethicalStanding } = userMetrics;

    // Assign weight multipliers based on user roles
    const reputationWeight = reputation * 0.5; // Example weighting factor
    const expertiseWeight = expertise * 0.3;
    const ethicalStandingWeight = ethicalStanding * 0.2;

    return reputationWeight + expertiseWeight + ethicalStandingWeight;
  }

  /**
   * Combine manual and AI-driven weights to generate the final vote weight.
   * @param {Number} manualWeight - The manually calculated vote weight.
   * @param {Number} aiWeight - The AI-driven vote weight.
   * @returns {Number} The combined final vote weight.
   */
  combineWeights(manualWeight, aiWeight) {
    // Example combination: 60% manual, 40% AI
    return (manualWeight * 0.6) + (aiWeight * 0.4);
  }
}

module.exports = new VoteWeightingService();
