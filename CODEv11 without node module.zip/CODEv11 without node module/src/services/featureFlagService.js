// /frontend/featureFlagService.js

class FeatureFlagService {
  constructor() {
    this.flags = {}; // Store feature flags
  }

  /**
   * Load feature flags from the server or external source.
   * @param {Object} featureFlags - An object containing all feature flags.
   */
  loadFeatureFlags(featureFlags) {
    this.flags = featureFlags;
  }

  /**
   * Check if a feature flag is enabled for a specific user.
   * @param {String} flagName - The name of the feature flag.
   * @param {Object} user - The user object (may contain user group, role, etc.).
   * @returns {Boolean} Whether the feature is enabled for the user.
   */
  isFeatureEnabled(flagName, user) {
    const flag = this.flags[flagName];
    if (!flag) return false;

    // Check if feature is available for the user's group or role
    if (flag.groups && flag.groups.includes(user.group)) {
      return true;
    }

    if (flag.roles && flag.roles.includes(user.role)) {
      return true;
    }

    return false;
  }

  /**
   * Gradually enable a feature for a percentage of users.
   * @param {String} flagName - The name of the feature flag.
   * @param {Object} user - The user object.
   * @returns {Boolean} Whether the feature is enabled for the user based on percentage rollout.
   */
  isFeatureEnabledForPercentage(flagName, user) {
    const flag = this.flags[flagName];
    if (!flag || !flag.rolloutPercentage) return false;

    // Simulate percentage-based rollout (using user ID hash or other metric)
    const userHash = this.getUserHash(user.id);
    return userHash % 100 < flag.rolloutPercentage;
  }

  /**
   * Generate a hash from the user ID for percentage-based rollouts.
   * @param {String} userId - The user's ID.
   * @returns {Number} A numeric hash for the user ID.
   */
  getUserHash(userId) {
    let hash = 0;
    for (let i = 0; i < userId.length; i++) {
      hash = (hash << 5) - hash + userId.charCodeAt(i);
      hash |= 0; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }
}

module.exports = new FeatureFlagService();
