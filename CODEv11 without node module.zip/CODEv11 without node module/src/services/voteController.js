const voteService = require('../services/voteService');

// Handle vote submission
const submitVote = async (req, res) => {
  try {
    const { option } = req.body;
    const user = req.user; // Assumes the user is attached to the request after authentication

    if (!option) {
      return res.status(400).json({ message: 'Vote option is required.' });
    }

    // Pass the vote data to the vote service for processing
    const updatedVotes = await voteService.submitVote(user, option);
    return res.status(200).json({ message: 'Vote submitted successfully', updatedVotes });
  } catch (error) {
    console.error('Error submitting vote:', error);
    return res.status(500).json({ message: 'Error submitting vote' });
  }
};

// Retrieve vote results
const getVoteResults = async (req, res) => {
  try {
    const voteResults = await voteService.calculateResults();
    return res.status(200).json(voteResults);
  } catch (error) {
    console.error('Error fetching vote results:', error);
    return res.status(500).json({ message: 'Error fetching vote results' });
  }
};

// Retrieve individual vote history for a user
const getUserVoteHistory = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming the user is attached to the request after authentication
    const voteHistory = await voteService.getUserVoteHistory(userId);
    return res.status(200).json(voteHistory);
  } catch (error) {
    console.error('Error fetching vote history:', error);
    return res.status(500).json({ message: 'Error fetching vote history' });
  }
};

module.exports = {
  submitVote,
  getVoteResults,
  getUserVoteHistory,
};
