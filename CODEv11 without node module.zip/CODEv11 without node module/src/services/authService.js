// /src/services/authService.js

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/userModel');
const { jwtSecret, jwtExpiration } = require('../config/authConfig');
const logger = require('../utils/loggerService');

class AuthService {
  /**
   * Register a new user by hashing their password and saving them to the database.
   * @param {Object} userData - The user's registration data (email, password, etc.).
   * @returns {Object} The newly registered user.
   */
  async registerUser(userData) {
    try {
      const { email, password, name } = userData;

      // Check if user already exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        throw new Error('User already exists.');
      }

      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create new user and save to database
      const user = new User({
        name,
        email,
        password: hashedPassword,
      });
      await user.save();

      logger.info(`User registered with email: ${email}`);
      return user;
    } catch (error) {
      logger.error(`Error registering user: ${error.message}`);
      throw new Error('Failed to register user.');
    }
  }

  /**
   * Authenticate a user and return a JWT token if successful.
   * @param {String} email - The user's email.
   * @param {String} password - The user's password.
   * @returns {String} The JWT token if authentication is successful.
   */
  async loginUser(email, password) {
    try {
      // Find user by email
      const user = await User.findOne({ email });
      if (!user) {
        throw new Error('User not found.');
      }

      // Check password
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        throw new Error('Invalid password.');
      }

      // Generate JWT token
      const token = this.generateToken(user._id);

      logger.info(`User logged in: ${email}`);
      return { token, user };
    } catch (error) {
      logger.error(`Error logging in user: ${error.message}`);
      throw new Error('Failed to log in user.');
    }
  }

  /**
   * Generate a JWT token for a user.
   * @param {String} userId - The ID of the user.
   * @returns {String} The generated JWT token.
   */
  generateToken(userId) {
    return jwt.sign({ userId }, jwtSecret, { expiresIn: jwtExpiration });
  }

  /**
   * Validate a JWT token and return the user ID if valid.
   * @param {String} token - The JWT token to validate.
   * @returns {String} The user ID if the token is valid.
   */
  async validateToken(token) {
    try {
      const decoded = jwt.verify(token, jwtSecret);
      return decoded.userId;
    } catch (error) {
      logger.error(`Invalid token: ${error.message}`);
      throw new Error('Invalid token.');
    }
  }
}

module.exports = new AuthService();
