// /src/services/mentorshipService.js

const axios = require('axios');

// Fetch all users (mentors and mentees) from the backend
const fetchUsers = async () => {
  try {
    const response = await axios.get('/api/admin/users');
    return response.data; // Return the list of users
  } catch (error) {
    console.error('Error fetching users:', error);
    throw new Error('Could not fetch users');
  }
};

// Fetch all mentorship assignments from the backend
const fetchMentorships = async () => {
  try {
    const response = await axios.get('/api/admin/mentorships');
    return response.data; // Return the list of mentorships
  } catch (error) {
    console.error('Error fetching mentorships:', error);
    throw new Error('Could not fetch mentorships');
  }
};

// Assign a mentor to a mentee by making a request to the backend
const assignMentor = async (mentorId, menteeId) => {
  try {
    const response = await axios.post('/api/admin/mentorships/assign', {
      mentorId,
      menteeId,
    });
    return response.data; // Return the assignment result
  } catch (error) {
    console.error('Error assigning mentor:', error);
    throw new Error('Could not assign mentor');
  }
};

module.exports = {
  fetchUsers,
  fetchMentorships,
  assignMentor,
};
