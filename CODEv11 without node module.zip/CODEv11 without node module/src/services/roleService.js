// /src/services/roleService.js

const User = require('../models/userModel');
const ContributionService = require('./contributionService');
const logger = require('../utils/loggerService');

class RoleService {
  /**
   * Dynamically assigns or updates a user's role based on vote history,
   * contributions, and AI-driven metrics.
   * 
   * @param {String} userId - The ID of the user whose role is being managed.
   * @returns {String} The updated role of the user.
   */
  async assignRole(userId) {
    try {
      // Fetch user details and metrics
      const user = await User.findById(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // Retrieve user contribution metrics
      const contributionMetrics = await ContributionService.getUserContributionMetrics(userId);
      const { votesCast, influenceScore, ethicalStanding } = contributionMetrics;

      // Determine the role based on vote history and contribution metrics
      const newRole = this.calculateRole(votesCast, influenceScore, ethicalStanding);

      // Update user role in the database if it has changed
      if (user.role !== newRole) {
        user.role = newRole;
        await user.save();
        logger.info(`User role updated for ${userId} to ${newRole}`);
      }

      return newRole;
    } catch (error) {
      logger.error(`Error assigning role for user ${userId}: ${error.message}`);
      throw new Error('Failed to assign role.');
    }
  }

  /**
   * Calculate the user's role based on metrics like votes cast, influence score, and ethical standing.
   * 
   * @param {Number} votesCast - The total number of votes cast by the user.
   * @param {Number} influenceScore - The user's overall influence score.
   * @param {Number} ethicalStanding - The user's ethical behavior score.
   * @returns {String} The role assigned to the user (student, specialist, klown).
   */
  calculateRole(votesCast, influenceScore, ethicalStanding) {
    if (ethicalStanding < 5) {
      return 'klown';  // Users with low ethical scores are demoted to "klown"
    }

    if (influenceScore > 80 && votesCast > 100) {
      return 'specialist';  // High contribution and influence grants "specialist" role
    }

    return 'student';  // Default role for users with moderate or low metrics
  }
}

module.exports = new RoleService();
