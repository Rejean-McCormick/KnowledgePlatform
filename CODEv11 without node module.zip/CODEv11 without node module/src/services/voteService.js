// /src/services/voteService.js

const { getRedisClient } = require('../config/redisConfig');
const Vote = require('../models/voteModel');
const VoteWeightingService = require('./voteWeighting');
const logger = require('../utils/loggerService');
const redisClient = getRedisClient();

class VoteService {
  /**
   * Submit a vote, calculate its weight using both AI and manual methods, and store the result.
   * @param {Object} voteData - The data of the vote being submitted.
   * @param {String} voteData.userId - The ID of the user submitting the vote.
   * @param {String} voteData.itemId - The ID of the item being voted on.
   * @param {Number} voteData.voteValue - The vote value (1 to 10).
   * @returns {Object} The final vote result including the weighted score.
   */
  async submitVote(voteData) {
    try {
      const { userId, itemId, voteValue } = voteData;
      
      // Validate vote value
      if (voteValue < 1 || voteValue > 10) {
        throw new Error('Vote value must be between 1 and 10.');
      }

      // Check if results already exist in the cache
      const cacheKey = `vote:${itemId}`;
      const cachedResult = await redisClient.get(cacheKey);
      if (cachedResult) {
        logger.info(`Returning cached result for item ${itemId}`);
        return JSON.parse(cachedResult);
      }

      // Calculate the final vote weight using manual and AI-driven methods
      const weightedVote = await VoteWeightingService.calculateFinalVoteWeight(userId, voteValue);

      // Save the vote to the database
      const vote = new Vote({
        userId,
        itemId,
        voteValue,
        weightedVote,
      });
      await vote.save();

      // Calculate the aggregated results for the item
      const voteResults = await this.calculateResults(itemId);

      // Cache the results for future requests
      await redisClient.set(cacheKey, JSON.stringify(voteResults), 'EX', 3600); // Cache expires in 1 hour

      return voteResults;
    } catch (error) {
      logger.error(`Error submitting vote for item ${itemId}: ${error.message}`);
      throw new Error('Failed to submit vote.');
    }
  }

  /**
   * Calculate the total voting results for an item.
   * @param {String} itemId - The ID of the item being voted on.
   * @returns {Object} The aggregated vote results.
   */
  async calculateResults(itemId) {
    try {
      const votes = await Vote.find({ itemId });

      if (votes.length === 0) {
        throw new Error('No votes found for this item.');
      }

      // Aggregate the results
      const totalWeightedResult = votes.reduce((total, vote) => total + vote.weightedVote, 0);
      const averageWeightedResult = totalWeightedResult / votes.length;

      return {
        itemId,
        totalVotes: votes.length,
        totalWeightedResult,
        averageWeightedResult,
      };
    } catch (error) {
      logger.error(`Error calculating results for item ${itemId}: ${error.message}`);
      throw new Error('Failed to calculate vote results.');
    }
  }
}

module.exports = new VoteService();
