// /frontend/feedbackService.js

export default class FeedbackService {
  /**
   * Collects feedback from users and sends it to the backend for analysis.
   * @param {String} userId - The ID of the user submitting feedback.
   * @param {String} feedbackType - The type of feedback (e.g., "vote", "ui", "experience").
   * @param {String} feedbackContent - The user's feedback content.
   * @returns {Promise<Object>} - The server response.
   */
  static async submitFeedback(userId, feedbackType, feedbackContent) {
    try {
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          feedbackType,
          feedbackContent,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }

      return await response.json();
    } catch (error) {
      console.error('Error submitting feedback:', error);
      return { error: error.message };
    }
  }

  /**
   * Fetch feedback categories from the backend for populating feedback forms.
   * @returns {Promise<Array>} - An array of feedback categories.
   */
  static async getFeedbackCategories() {
    try {
      const response = await fetch('/api/feedback/categories', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch feedback categories');
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching feedback categories:', error);
      return [];
    }
  }
}
