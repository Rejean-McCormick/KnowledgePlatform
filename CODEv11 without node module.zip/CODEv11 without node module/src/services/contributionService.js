// /src/services/contributionService.js

const Vote = require('../models/voteModel');
const Discussion = require('../models/discussionModel');  // Hypothetical model
const Engagement = require('../models/engagementModel');  // Hypothetical model
const logger = require('../utils/loggerService');

class ContributionService {
  /**
   * Get the contribution metrics for a user, including votes, discussions, and engagements.
   * @param {String} userId - The ID of the user whose contributions are being tracked.
   * @returns {Object} Contribution metrics, including votes, discussions, and engagements count.
   */
  async getUserContributionMetrics(userId) {
    try {
      // Get the number of votes cast by the user
      const votesCast = await Vote.countDocuments({ userId });

      // Get the number of discussions the user has participated in
      const discussionsParticipated = await Discussion.countDocuments({ participants: userId });

      // Get the user's engagement score (based on hypothetical user activity)
      const engagementScore = await Engagement.aggregate([
        { $match: { userId } },
        { $group: { _id: null, totalEngagement: { $sum: '$engagementValue' } } }
      ]);

      const contributionMetrics = {
        votesCast,
        discussionsParticipated,
        engagementScore: engagementScore[0] ? engagementScore[0].totalEngagement : 0,
      };

      logger.info(`User contribution metrics for user ${userId}: ${JSON.stringify(contributionMetrics)}`);
      return contributionMetrics;
    } catch (error) {
      logger.error(`Error fetching contribution metrics for user ${userId}: ${error.message}`);
      throw new Error('Failed to fetch user contribution metrics.');
    }
  }

  /**
   * Tracks a new vote contribution for a user.
   * @param {Object} voteData - The data of the vote being submitted.
   * @returns {Object} The saved vote.
   */
  async trackVoteContribution(voteData) {
    try {
      const vote = new Vote(voteData);
      await vote.save();
      logger.info(`Vote contribution tracked for user ${voteData.userId}`);
      return vote;
    } catch (error) {
      logger.error(`Error tracking vote contribution: ${error.message}`);
      throw new Error('Failed to track vote contribution.');
    }
  }

  /**
   * Tracks a new discussion participation for a user.
   * @param {Object} discussionData - The data of the discussion participation.
   * @returns {Object} The saved discussion.
   */
  async trackDiscussionContribution(discussionData) {
    try {
      const discussion = new Discussion(discussionData);
      await discussion.save();
      logger.info(`Discussion contribution tracked for user ${discussionData.userId}`);
      return discussion;
    } catch (error) {
      logger.error(`Error tracking discussion contribution: ${error.message}`);
      throw new Error('Failed to track discussion contribution.');
    }
  }

  /**
   * Tracks user engagements (e.g., likes, comments).
   * @param {Object} engagementData - The data related to user engagement.
   * @returns {Object} The saved engagement.
   */
  async trackEngagement(engagementData) {
    try {
      const engagement = new Engagement(engagementData);
      await engagement.save();
      logger.info(`Engagement tracked for user ${engagementData.userId}`);
      return engagement;
    } catch (error) {
      logger.error(`Error tracking engagement: ${error.message}`);
      throw new Error('Failed to track user engagement.');
    }
  }
}

module.exports = new ContributionService();
