import React, { createContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for v6 navigation
import { getUserProfile } from '../services/userService';

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    const fetchUser = async () => {
      const savedUser = JSON.parse(localStorage.getItem('user'));
      if (savedUser) {
        const userData = await getUserProfile(savedUser.id);
        setUser(userData);
      }
      setLoading(false);
    };
    fetchUser();
  }, []);

  const login = (userData) => {
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    navigate('/dashboard'); // Navigate to dashboard after login
  };

  const logout = () => {
    localStorage.removeItem('user');
    setUser(null);
    navigate('/login'); // Navigate to login page after logout
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
