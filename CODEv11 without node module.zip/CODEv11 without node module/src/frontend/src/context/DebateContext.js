 
import React, { createContext, useState, useEffect } from 'react';
import { getDebates } from '../services/debateService';

export const DebateContext = createContext();

const DebateProvider = ({ children }) => {
  const [debates, setDebates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDebates = async () => {
      const data = await getDebates();
      setDebates(data);
      setLoading(false);
    };
    fetchDebates();
  }, []);

  return (
    <DebateContext.Provider value={{ debates, loading }}>
      {children}
    </DebateContext.Provider>
  );
};

export default DebateProvider;
