 
import React, { createContext, useState, useEffect } from 'react';
import { getVotes } from '../services/voteService';

export const VoteContext = createContext();

const VoteProvider = ({ children }) => {
  const [votes, setVotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVotes = async () => {
      const data = await getVotes();
      setVotes(data);
      setLoading(false);
    };
    fetchVotes();
  }, []);

  return (
    <VoteContext.Provider value={{ votes, loading }}>
      {children}
    </VoteContext.Provider>
  );
};

export default VoteProvider;
