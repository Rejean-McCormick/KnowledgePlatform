 
import React, { createContext, useState } from 'react';

export const SmartVoteContext = createContext();

const SmartVoteProvider = ({ children }) => {
  const [rankings, setRankings] = useState({});

  const updateRank = (contentId, rank) => {
    setRankings((prev) => ({
      ...prev,
      [contentId]: rank,
    }));
  };

  return (
    <SmartVoteContext.Provider value={{ rankings, updateRank }}>
      {children}
    </SmartVoteContext.Provider>
  );
};

export default SmartVoteProvider;
