import React from 'react';
import AppRouter from './router/AppRouter';  // Import the centralized router
import AuthProvider from './context/AuthContext';  // Auth context for managing authentication
import VoteProvider from './context/VoteContext';  // Vote context for managing vote-related data
import DebateProvider from './context/DebateContext';  // Debate context for managing debates
import SmartVoteProvider from './context/SmartVoteContext';  // SmartVote context for handling smart voting features
import ProjectProvider from './context/ProjectContext';  // Project context for managing project collaboration
import './styles/Global.css';  // Import global styles

// Main App component
const App = () => {
  return (
    <AuthProvider>  {/* Provide authentication context */}
      <VoteProvider>  {/* Provide voting context */}
        <DebateProvider>  {/* Provide debate context */}
          <SmartVoteProvider>  {/* Provide smart voting context */}
            <ProjectProvider>  {/* Provide project collaboration context */}
              <AppRouter />  {/* Centralized routing logic */}
            </ProjectProvider>
          </SmartVoteProvider>
        </DebateProvider>
      </VoteProvider>
    </AuthProvider>
  );
};

export default App;
