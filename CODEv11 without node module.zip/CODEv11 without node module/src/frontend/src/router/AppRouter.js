import React from 'react';
import { Routes, Route } from 'react-router-dom';  // No BrowserRouter here
import HomePage from '../pages/HomePage';
import SchoolPage from '../pages/SchoolPage';
import DebatesPage from '../pages/DebatesPage';
import VotePage from '../pages/VotePage';
import ResearchDevelopmentPage from '../pages/ResearchDevelopmentPage';
import ProfilePage from '../pages/ProfilePage';
import ErrorPage from '../pages/ErrorPage';  

const AppRouter = () => {
  return (
    <Routes>  {/* No need to wrap Routes in Router */}
      <Route path="/" element={<HomePage />} />
      <Route path="/school" element={<SchoolPage />} />
      <Route path="/debates" element={<DebatesPage />} />
      <Route path="/voting" element={<VotePage />} />
      <Route path="/research" element={<ResearchDevelopmentPage />} />
      <Route path="/profile" element={<ProfilePage />} />
      
      {/* Fallback route for non-existent paths (404) */}
      <Route path="*" element={<ErrorPage />} />
    </Routes>
  );
};

export default AppRouter;
