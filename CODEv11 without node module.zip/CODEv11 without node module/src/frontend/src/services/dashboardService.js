 
import axios from 'axios';

const API_URL = '/api/dashboard';

export const getDashboardData = async (userId) => {
  const response = await axios.get(`${API_URL}/${userId}`);
  return response.data;
};
