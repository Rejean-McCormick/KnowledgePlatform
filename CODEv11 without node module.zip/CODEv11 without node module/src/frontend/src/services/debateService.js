 
import axios from 'axios';

const API_URL = '/api/debates';

export const getDebates = async () => {
  const response = await axios.get(`${API_URL}`);
  return response.data;
};

export const getDebateById = async (debateId) => {
  const response = await axios.get(`${API_URL}/${debateId}`);
  return response.data;
};
