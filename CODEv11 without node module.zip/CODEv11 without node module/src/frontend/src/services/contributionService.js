 
import axios from 'axios';

const API_URL = '/api/contributions';

export const submitContribution = async (projectId, contributionData) => {
  const response = await axios.post(`${API_URL}/${projectId}/contribute`, contributionData);
  return response.data;
};
