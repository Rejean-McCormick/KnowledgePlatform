 
import axios from 'axios';

const API_URL = '/api/courses';

export const getCourses = async () => {
  const response = await axios.get(`${API_URL}`);
  return response.data;
};

export const getCourseById = async (courseId) => {
  const response = await axios.get(`${API_URL}/${courseId}`);
  return response.data;
};
