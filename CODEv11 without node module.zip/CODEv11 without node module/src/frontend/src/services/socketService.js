 
import io from 'socket.io-client';

const socket = io('/');

export const subscribeToUpdates = (callback) => {
  socket.on('update', (data) => {
    callback(data);
  });
};

export const unsubscribeFromUpdates = () => {
  socket.off('update');
};
