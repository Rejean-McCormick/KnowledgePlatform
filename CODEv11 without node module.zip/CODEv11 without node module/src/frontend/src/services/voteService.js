 
import axios from 'axios';

const API_URL = '/api/votes';

export const getVotes = async () => {
  const response = await axios.get(`${API_URL}`);
  return response.data;
};

export const voteOnItem = async (voteId, voteData) => {
  const response = await axios.post(`${API_URL}/${voteId}/vote`, voteData);
  return response.data;
};
