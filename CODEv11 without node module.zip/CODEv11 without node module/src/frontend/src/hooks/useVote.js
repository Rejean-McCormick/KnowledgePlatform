 
import { useContext } from 'react';
import { VoteContext } from '../context/VoteContext';

const useVote = () => {
  const context = useContext(VoteContext);
  if (!context) {
    throw new Error('useVote must be used within a VoteProvider');
  }
  return context;
};

export default useVote;
