 
import { useContext } from 'react';
import { DebateContext } from '../context/DebateContext';

const useDebates = () => {
  const context = useContext(DebateContext);
  if (!context) {
    throw new Error('useDebates must be used within a DebateProvider');
  }
  return context;
};

export default useDebates;
