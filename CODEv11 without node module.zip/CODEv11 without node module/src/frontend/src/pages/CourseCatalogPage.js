 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseList from '../components/CourseList';
import './CourseCatalogPage.module.css';

const CourseCatalogPage = ({ courses }) => {
  return (
    <div className="course-catalog-page">
      <Header />
      <h1>Course Catalog</h1>
      <CourseList courses={courses} />
      <Footer />
    </div>
  );
};

export default CourseCatalogPage;
