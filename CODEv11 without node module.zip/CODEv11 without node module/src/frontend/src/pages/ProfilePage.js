import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import './ProfilePage.module.css';

const ProfilePage = ({ user }) => {
  return (
    <div className="profile-page">
      <Header />
      <h1>Profile</h1>
      <div className="profile-info">
        <p><strong>Name:</strong> {user?.name || 'No name available'}</p>
        <p><strong>Email:</strong> {user?.email || 'No email available'}</p>
        <p><strong>Reputation:</strong> {user?.reputation || 'No reputation available'}</p>
      </div>
      <Footer />
    </div>
  );
};

export default ProfilePage;
