 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProjectList from '../components/ProjectList';
import './ResearchDevelopmentPage.module.css';

const ResearchDevelopmentPage = ({ projects }) => {
  return (
    <div className="research-development-page">
      <Header />
      <h1>Research & Development</h1>
      <ProjectList projects={projects} />
      <Footer />
    </div>
  );
};

export default ResearchDevelopmentPage;
