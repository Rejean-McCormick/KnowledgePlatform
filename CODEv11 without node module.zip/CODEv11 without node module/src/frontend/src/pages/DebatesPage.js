 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import DebateList from '../components/DebateList';
import './DebatesPage.module.css';

const DebatesPage = ({ debates }) => {
  return (
    <div className="debates-page">
      <Header />
      <h1>Debates</h1>
      <DebateList debates={debates} />
      <Footer />
    </div>
  );
};

export default DebatesPage;
