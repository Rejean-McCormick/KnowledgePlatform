 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseDetails from '../components/CourseDetails';
import './CoursePage.module.css';

const CoursePage = ({ course }) => {
  return (
    <div className="course-page">
      <Header />
      <CourseDetails course={course} />
      <Footer />
    </div>
  );
};

export default CoursePage;
