import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ErrorPage.module.css';

const ErrorPage = () => {
  return (
    <div className={styles.errorPage}>
      <div className={styles.errorContent}>
        <h1 className={styles.errorTitle}>Oops! Page Not Found</h1>
        <p className={styles.errorMessage}>
          Sorry, the page you are looking for doesn't exist. It might have been moved or deleted.
        </p>
        <Link to="/" className={styles.homeLink}>
          Return to Home
        </Link>
      </div>
    </div>
  );
};

export default ErrorPage;
