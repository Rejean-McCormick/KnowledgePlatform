 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ArchiveItem from '../components/ArchiveItem';
import './DebateArchivePage.module.css';

const DebateArchivePage = ({ archive }) => {
  return (
    <div className="debate-archive-page">
      <Header />
      <h1>Debate Archive</h1>
      {archive.map((item) => (
        <ArchiveItem key={item.id} archive={item} />
      ))}
      <Footer />
    </div>
  );
};

export default DebateArchivePage;
