 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseList from '../components/CourseList';
import './MyCoursesPage.module.css';

const MyCoursesPage = ({ courses }) => {
  return (
    <div className="my-courses-page">
      <Header />
      <h1>My Courses</h1>
      <CourseList courses={courses} />
      <Footer />
    </div>
  );
};

export default MyCoursesPage;
