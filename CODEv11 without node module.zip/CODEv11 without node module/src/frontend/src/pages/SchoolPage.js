 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CourseList from '../components/CourseList';
import './SchoolPage.module.css';

const SchoolPage = ({ courses }) => {
  return (
    <div className="school-page">
      <Header />
      <h1>School</h1>
      <CourseList courses={courses} />
      <Footer />
    </div>
  );
};

export default SchoolPage;
