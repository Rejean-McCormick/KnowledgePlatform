import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import VoteItem from '../components/VoteItem';
import './VotePage.module.css';

const VotePage = ({ votes }) => {
  return (
    <div className="vote-page">
      <Header />
      <h1>Voting Center</h1>
      {votes?.length > 0 ? (
        votes.map((vote) => (
          <VoteItem key={vote.id} vote={vote} />
        ))
      ) : (
        <p>No votes available</p>
      )}
      <Footer />
    </div>
  );
};

export default VotePage;
