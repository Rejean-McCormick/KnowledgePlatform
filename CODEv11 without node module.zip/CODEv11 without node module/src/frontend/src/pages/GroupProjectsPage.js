 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProjectList from '../components/ProjectList';
import './GroupProjectsPage.module.css';

const GroupProjectsPage = ({ projects }) => {
  return (
    <div className="group-projects-page">
      <Header />
      <h1>Collaborative Learning Projects</h1>
      <ProjectList projects={projects} />
      <Footer />
    </div>
  );
};

export default GroupProjectsPage;
