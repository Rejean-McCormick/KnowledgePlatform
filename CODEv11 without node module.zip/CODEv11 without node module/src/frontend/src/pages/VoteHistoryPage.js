 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HistoryItem from '../components/HistoryItem';
import './VoteHistoryPage.module.css';

const VoteHistoryPage = ({ history }) => {
  return (
    <div className="vote-history-page">
      <Header />
      <h1>Vote History</h1>
      {history.map((item) => (
        <HistoryItem key={item.id} history={item} />
      ))}
      <Footer />
    </div>
  );
};

export default VoteHistoryPage;
