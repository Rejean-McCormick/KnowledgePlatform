 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import DebateList from '../components/DebateList';
import './MyDebatesPage.module.css';

const MyDebatesPage = ({ debates }) => {
  return (
    <div className="my-debates-page">
      <Header />
      <h1>My Debates</h1>
      <DebateList debates={debates} />
      <Footer />
    </div>
  );
};

export default MyDebatesPage;
