 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProjectCard from '../components/ProjectCard';
import './ProjectOverviewPage.module.css';

const ProjectOverviewPage = ({ projects }) => {
  return (
    <div className="project-overview-page">
      <Header />
      <h1>Project Overview</h1>
      {projects.map((project) => (
        <ProjectCard key={project.id} project={project} />
      ))}
      <Footer />
    </div>
  );
};

export default ProjectOverviewPage;
