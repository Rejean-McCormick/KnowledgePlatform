 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProjectList from '../components/ProjectList';
import './MyProjectsPage.module.css';

const MyProjectsPage = ({ projects }) => {
  return (
    <div className="my-projects-page">
      <Header />
      <h1>My Projects</h1>
      <ProjectList projects={projects} />
      <Footer />
    </div>
  );
};

export default MyProjectsPage;
