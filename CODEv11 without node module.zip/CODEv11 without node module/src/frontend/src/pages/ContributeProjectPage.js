import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ContributionForm from '../components/ContributionForm';
import './ContributeProjectPage.module.css';

const ContributeProjectPage = ({ onSubmit }) => {
  return (
    <div className="contribute-project-page">
      <Header />
      <h1>Contribute to Project</h1>
      <ContributionForm onSubmit={onSubmit} />
      <Footer />
    </div>
  );
};

export default ContributeProjectPage;
