 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import SettingsForm from '../components/SettingsForm';
import './AccountSettingsPage.module.css';

const AccountSettingsPage = ({ user, onUpdate }) => {
  return (
    <div className="account-settings-page">
      <Header />
      <h1>Account Settings</h1>
      <SettingsForm user={user} onUpdate={onUpdate} />
      <Footer />
    </div>
  );
};

export default AccountSettingsPage;
