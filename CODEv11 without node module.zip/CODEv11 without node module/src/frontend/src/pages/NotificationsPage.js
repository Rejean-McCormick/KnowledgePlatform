 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import './NotificationsPage.module.css';

const NotificationsPage = ({ notifications }) => {
  return (
    <div className="notifications-page">
      <Header />
      <h1>Notifications</h1>
      <ul className="notifications-list">
        {notifications.map((notification) => (
          <li key={notification.id}>{notification.message}</li>
        ))}
      </ul>
      <Footer />
    </div>
  );
};

export default NotificationsPage;
