 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import VoteItem from '../components/VoteItem';
import './ActiveVotesPage.module.css';

const ActiveVotesPage = ({ votes }) => {
  return (
    <div className="active-votes-page">
      <Header />
      <h1>Active Votes</h1>
      {votes.map((vote) => (
        <VoteItem key={vote.id} vote={vote} />
      ))}
      <Footer />
    </div>
  );
};

export default ActiveVotesPage;
