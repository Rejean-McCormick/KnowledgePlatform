 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ArgumentThread from '../components/ArgumentThread';
import './DebateRoomPage.module.css';

const DebateRoomPage = ({ debate, onVote }) => {
  return (
    <div className="debate-room-page">
      <Header />
      <h1>{debate.title}</h1>
      {debate.arguments.map((argument) => (
        <ArgumentThread key={argument.id} argument={argument} onVote={onVote} />
      ))}
      <Footer />
    </div>
  );
};

export default DebateRoomPage;
