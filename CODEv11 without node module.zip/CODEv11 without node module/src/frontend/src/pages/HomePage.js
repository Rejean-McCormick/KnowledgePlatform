 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Dashboard from '../components/Dashboard';
import './HomePage.module.css';

const HomePage = ({ widgets }) => {
  return (
    <div className="home-page">
      <Header />
      <Dashboard widgets={widgets} />
      <Footer />
    </div>
  );
};

export default HomePage;
