 
import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import AchievementBadge from '../components/AchievementBadge';
import './AchievementsPage.module.css';

const AchievementsPage = ({ achievements }) => {
  return (
    <div className="achievements-page">
      <Header />
      <h1>Achievements</h1>
      <div className="achievements">
        {achievements.map((badge) => (
          <AchievementBadge key={badge.id} badge={badge} />
        ))}
      </div>
      <Footer />
    </div>
  );
};

export default AchievementsPage;
