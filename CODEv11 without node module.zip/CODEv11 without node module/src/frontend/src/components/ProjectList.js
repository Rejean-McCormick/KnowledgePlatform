import React from 'react';
import ProjectCard from './ProjectCard';
import './ProjectList.module.css';

const ProjectList = ({ projects = [] }) => {
  return (
    <div className="project-list">
      {projects?.length > 0 ? (
        projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))
      ) : (
        <p>No projects available</p>
      )}
    </div>
  );
};

export default ProjectList;
