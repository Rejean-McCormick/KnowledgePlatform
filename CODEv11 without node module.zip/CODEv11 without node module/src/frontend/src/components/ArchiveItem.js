import React from 'react';
import './ArchiveItem.module.css';

const ArchiveItem = ({ archive }) => {
  return (
    <div className="archive-item">
      <h3>{archive?.title || 'Untitled Archive'}</h3>
      <p>{archive?.summary || 'No summary available'}</p>

      {/* Optional chaining to ensure files exist before mapping */}
      {archive?.files?.length > 0 ? (
        <ul>
          {archive.files.map((file, index) => (
            <li key={index}>
              <a href={file?.url || '#'} target="_blank" rel="noopener noreferrer">
                {file?.name || 'Unnamed File'}
              </a>
            </li>
          ))}
        </ul>
      ) : (
        <p>No files available</p>
      )}
    </div>
  );
};

export default ArchiveItem;
