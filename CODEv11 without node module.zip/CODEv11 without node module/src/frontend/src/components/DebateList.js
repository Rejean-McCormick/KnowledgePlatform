import React from 'react';
import { Link } from 'react-router-dom';
import './DebateList.module.css';

const DebateList = ({ debates }) => {
  return (
    <ul className="debate-list">
      {debates?.length > 0 ? (
        debates.map((debate) => (
          <li key={debate.id}>
            <Link to={`/debates/${debate.id}`}>{debate.title}</Link>
          </li>
        ))
      ) : (
        <p>No debates available</p>
      )}
    </ul>
  );
};

export default DebateList;
