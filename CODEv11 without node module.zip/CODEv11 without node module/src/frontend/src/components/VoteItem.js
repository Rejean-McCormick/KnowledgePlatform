import React from 'react';
import './VoteItem.module.css';

const VoteItem = ({ vote }) => {
  return (
    <div className="vote-item">
      <h3>{vote?.title || 'Untitled Vote'}</h3>
      <p>{vote?.description || 'No description available'}</p>
      <button>Vote Now</button>
    </div>
  );
};

export default VoteItem;
