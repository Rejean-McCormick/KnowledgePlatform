import React from 'react';
import './SmartVoteRank.module.css';

const SmartVoteRank = ({ rank }) => {
  return (
    <div className="smartvote-rank">
      <span>Current Rank: {rank || 'Unranked'}</span>
    </div>
  );
};

export default SmartVoteRank;
