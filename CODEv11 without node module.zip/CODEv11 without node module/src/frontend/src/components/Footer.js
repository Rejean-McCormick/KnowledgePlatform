import React from 'react';
import './Footer.module.css';

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; 2024 Knowledge Platform. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
