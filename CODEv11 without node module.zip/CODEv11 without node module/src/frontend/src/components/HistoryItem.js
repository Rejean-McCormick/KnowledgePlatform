import React from 'react';
import './HistoryItem.module.css';

const HistoryItem = ({ history }) => {
  return (
    <div className="history-item">
      <h4>{history?.title || 'Untitled History'}</h4>
      <p>{history?.result || 'No result available'}</p>
    </div>
  );
};

export default HistoryItem;
