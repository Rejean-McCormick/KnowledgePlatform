import React, { useState } from 'react';
import './ContributionForm.module.css';

const ContributionForm = ({ onSubmit }) => {
  const [contribution, setContribution] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit?.(contribution);  // Optional chaining to ensure onSubmit is defined
    setContribution('');  // Clear the input after submission
  };

  return (
    <form className="contribution-form" onSubmit={handleSubmit}>
      <label htmlFor="contribution">Your Contribution</label>
      <textarea
        id="contribution"
        value={contribution}
        onChange={(e) => setContribution(e.target.value)}
      ></textarea>
      <button type="submit">Submit</button>
    </form>
  );
};

export default ContributionForm;
