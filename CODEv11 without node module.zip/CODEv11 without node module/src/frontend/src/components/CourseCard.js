import React from 'react';
import './CourseCard.module.css';

const CourseCard = ({ course }) => {
  return (
    <div className="course-card">
      <h3>{course?.title || 'Untitled Course'}</h3>
      <p>{course?.description || 'No description available'}</p>
      <button>Start Course</button>
    </div>
  );
};

export default CourseCard;
