import React from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.module.css';

const Sidebar = ({ items = [], selectedItem }) => {
  return (
    <aside className="sidebar">
      <ul>
        {items?.length > 0 ? (
          items.map(item => (
            <li key={item} className={selectedItem === item ? 'active' : ''}>
              <Link to={`/${item}`}>{item}</Link>
            </li>
          ))
        ) : (
          <p>No items available</p>
        )}
      </ul>
    </aside>
  );
};

export default Sidebar;
