import React from 'react';
import CourseCard from './CourseCard';
import './CourseList.module.css';

const CourseList = ({ courses }) => {
  return (
    <div className="course-list">
      {courses?.length > 0 ? (
        courses.map((course) => (
          <CourseCard key={course.id} course={course} />
        ))
      ) : (
        <p>No courses available</p>
      )}
    </div>
  );
};

export default CourseList;
