 
import React from 'react';
import './AchievementBadge.module.css';

const AchievementBadge = ({ badge }) => {
  return (
    <div className="achievement-badge">
      <img src={badge.icon} alt={badge.name} />
      <span>{badge.name}</span>
    </div>
  );
};

export default AchievementBadge;
