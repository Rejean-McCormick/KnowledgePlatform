import React from 'react';
import './Dashboard.module.css';

const Dashboard = ({ widgets = [] }) => {
  return (
    <div className="dashboard">
      {widgets?.length > 0 ? (
        widgets.map((widget, index) => (
          <div key={index} className="widget">
            {widget}
          </div>
        ))
      ) : (
        <p>No widgets available</p>
      )}
    </div>
  );
};

export default Dashboard;
