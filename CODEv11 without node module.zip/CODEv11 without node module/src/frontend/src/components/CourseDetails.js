import React from 'react';
import './CourseDetails.module.css';

const CourseDetails = ({ course }) => {
  return (
    <div className="course-details">
      <h2>{course?.title || 'Untitled Course'}</h2>
      <p>{course?.description || 'No description available'}</p>
      <section>
        <h3>Course Syllabus:</h3>
        <ul>
          {course?.syllabus?.length > 0 ? (
            course.syllabus.map((item, index) => (
              <li key={index}>{item}</li>
            ))
          ) : (
            <p>No syllabus available</p>
          )}
        </ul>
      </section>
    </div>
  );
};

export default CourseDetails;
