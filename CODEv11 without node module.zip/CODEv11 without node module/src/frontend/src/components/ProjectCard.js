import React from 'react';
import './ProjectCard.module.css';

const ProjectCard = ({ project }) => {
  return (
    <div className="project-card">
      <h3>{project?.title || 'Untitled Project'}</h3>
      <p>{project?.description || 'No description available'}</p>
      <button>Contribute</button>
    </div>
  );
};

export default ProjectCard;
