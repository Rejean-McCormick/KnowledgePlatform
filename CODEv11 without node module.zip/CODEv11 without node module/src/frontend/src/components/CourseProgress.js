import React from 'react';
import './CourseProgress.module.css';

const CourseProgress = ({ progress }) => {
  return (
    <div className="course-progress">
      <h3>Course Progress</h3>
      <progress value={progress || 0} max="100"></progress>
      <span>{progress || 0}% Complete</span>
    </div>
  );
};

export default CourseProgress;
