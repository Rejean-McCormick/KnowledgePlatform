import React from 'react';
import './ArgumentThread.module.css';

const ArgumentThread = ({ argument, onVote }) => {
  return (
    <div className="argument-thread">
      <p>{argument?.text || 'No argument text available'}</p>
      <div className="votes">
        <button onClick={() => onVote('up')}>Upvote</button>
        <button onClick={() => onVote('down')}>Downvote</button>
      </div>
    </div>
  );
};

export default ArgumentThread;
