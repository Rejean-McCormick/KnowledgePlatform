import React, { useState } from 'react';
import './SettingsForm.module.css';

const SettingsForm = ({ user = {}, onUpdate }) => {
  const [formData, setFormData] = useState({ ...user });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onUpdate?.(formData); // Optional chaining for onUpdate
  };

  return (
    <form className="settings-form" onSubmit={handleSubmit}>
      <label htmlFor="name">Name</label>
      <input
        type="text"
        id="name"
        name="name"
        value={formData.name || ''}
        onChange={handleChange}
      />

      <label htmlFor="email">Email</label>
      <input
        type="email"
        id="email"
        name="email"
        value={formData.email || ''}
        onChange={handleChange}
      />

      <button type="submit">Update</button>
    </form>
  );
};

export default SettingsForm;
