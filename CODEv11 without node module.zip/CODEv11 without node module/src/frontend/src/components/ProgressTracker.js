import React from 'react';
import './ProgressTracker.module.css';

const ProgressTracker = ({ progress = 0 }) => {
  return (
    <div className="progress-tracker">
      <progress value={progress} max="100"></progress>
      <span>{progress}% Complete</span>
    </div>
  );
};

export default ProgressTracker;
