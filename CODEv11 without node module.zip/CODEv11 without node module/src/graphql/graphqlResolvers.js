const { User, Vote } = require('../models');
const voteService = require('../services/voteService');
const badgeSystem = require('../services/badgeSystem');
const { recalculateUserRoles } = require('../services/userService');

const resolvers = {
  // Resolvers for Query type
  Query: {
    // Fetch all users
    users: async () => {
      try {
        return await User.find({});
      } catch (error) {
        throw new Error('Error fetching users');
      }
    },

    // Fetch a single user by ID
    user: async (parent, { id }) => {
      try {
        return await User.findById(id);
      } catch (error) {
        throw new Error('Error fetching user');
      }
    },

    // Fetch vote history for a specific user
    voteHistory: async (parent, { userId }) => {
      try {
        return await Vote.find({ user: userId });
      } catch (error) {
        throw new Error('Error fetching vote history');
      }
    },

    // Fetch platform metrics
    platformMetrics: async () => {
      try {
        const totalUsers = await User.countDocuments();
        const totalVotes = await Vote.countDocuments();
        const averageReputation = await User.aggregate([
          { $group: { _id: null, avgReputation: { $avg: '$reputation' } } },
        ]);

        return {
          totalUsers,
          totalVotes,
          averageReputation: averageReputation[0]?.avgReputation || 0,
        };
      } catch (error) {
        throw new Error('Error fetching platform metrics');
      }
    },
  },

  // Resolvers for Mutation type
  Mutation: {
    // Submit a vote
    submitVote: async (parent, { userId, issue, option }) => {
      try {
        const user = await User.findById(userId);
        if (!user) {
          throw new Error('User not found');
        }

        const updatedVotes = await voteService.submitVote(user, option);

        return {
          id: updatedVotes._id,
          issue,
          option,
          weight: updatedVotes.weight,
          user,
        };
      } catch (error) {
        throw new Error('Error submitting vote');
      }
    },

    // Assign a badge to a user
    assignBadge: async (parent, { userId, badge }) => {
      try {
        const user = await badgeSystem.assignBadges(userId);
        if (!user.badges.includes(badge)) {
          throw new Error('Badge assignment failed');
        }
        return user;
      } catch (error) {
        throw new Error('Error assigning badge');
      }
    },

    // Update a user's role
    updateUserRole: async (parent, { userId, role }) => {
      try {
        const updatedUser = await recalculateUserRoles(userId, role);
        return updatedUser;
      } catch (error) {
        throw new Error('Error updating user role');
      }
    },
  },

  // Resolve user field inside Vote type
  Vote: {
    user: async (parent) => {
      return await User.findById(parent.user);
    },
  },
};

module.exports = resolvers;
