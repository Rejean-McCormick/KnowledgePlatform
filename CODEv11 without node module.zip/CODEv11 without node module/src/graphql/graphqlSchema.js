const { gql } = require('apollo-server-express');

// Define the GraphQL schema
const typeDefs = gql`
  # User type definition
  type User {
    id: ID!
    username: String!
    email: String!
    reputation: Int
    influenceScore: Int
    ethicalStanding: Int
    role: String!
    badges: [String]
    voteHistory: [Vote]
  }

  # Vote type definition
  type Vote {
    id: ID!
    issue: String!
    option: String!
    weight: Float
    user: User
  }

  # Metrics type definition
  type Metrics {
    totalUsers: Int
    totalVotes: Int
    averageReputation: Float
  }

  # Queries for fetching data
  type Query {
    # Get all users
    users: [User]

    # Get a single user by ID
    user(id: ID!): User

    # Get vote history for a specific user
    voteHistory(userId: ID!): [Vote]

    # Get overall platform metrics
    platformMetrics: Metrics
  }

  # Mutations for creating or updating data
  type Mutation {
    # Submit a vote
    submitVote(userId: ID!, issue: String!, option: String!): Vote

    # Assign a badge to a user
    assignBadge(userId: ID!, badge: String!): User

    # Update a user's role
    updateUserRole(userId: ID!, role: String!): User
  }
`;

module.exports = typeDefs;
