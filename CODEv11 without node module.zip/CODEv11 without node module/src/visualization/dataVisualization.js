// /frontend/visualization/dataVisualization.js

import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

/**
 * Function to visualize vote results using Chart.js
 * @param {Object} data - The vote results data
 */
export function VoteResultsChart({ data }) {
  const chartRef = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');
    const chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.map((item) => item.label),
        datasets: [
          {
            label: 'Votes',
            data: data.map((item) => item.votes),
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      chart.destroy();
    };
  }, [data]);

  return <canvas ref={chartRef}></canvas>;
}

/**
 * Function to visualize role updates using Chart.js
 * @param {Object} roleData - The role update data
 */
export function RoleUpdatesChart({ roleData }) {
  const chartRef = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');
    const chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: roleData.map((item) => item.timestamp),
        datasets: [
          {
            label: 'Role Updates',
            data: roleData.map((item) => item.roleChangeCount),
            backgroundColor: 'rgba(153, 102, 255, 0.2)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1,
            fill: true,
          },
        ],
      },
      options: {
        scales: {
          x: {
            type: 'time',
            time: {
              unit: 'day',
            },
          },
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      chart.destroy();
    };
  }, [roleData]);

  return <canvas ref={chartRef}></canvas>;
}
