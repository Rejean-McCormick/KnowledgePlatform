// /src/middlewares/loggingMiddleware.js

const logger = require('../utils/loggerService');

/**
 * Middleware to log incoming API requests and responses.
 * Captures metadata like method, URL, response status, and execution time for auditing.
 */
function loggingMiddleware(req, res, next) {
  const startTime = Date.now();

  // Log request metadata
  logger.info(`Incoming request: ${req.method} ${req.url}`);

  // Capture the response status and execution time
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    logger.info(`Response: ${req.method} ${req.url} - Status: ${res.statusCode} - Duration: ${duration}ms`);
  });

  // Proceed to the next middleware or route handler
  next();
}

module.exports = loggingMiddleware;
