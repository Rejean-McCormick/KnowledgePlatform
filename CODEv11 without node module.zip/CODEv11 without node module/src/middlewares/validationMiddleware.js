// /src/middlewares/validationMiddleware.js

const { validationResult } = require('express-validator');
const logger = require('../utils/loggerService');

/**
 * Middleware to validate incoming request payloads.
 * Ensures that data such as vote submissions and user inputs are correctly formatted.
 */
function validationMiddleware(req, res, next) {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    // Log validation errors
    logger.error(`Validation error: ${JSON.stringify(errors.array())}`);
    
    // Send validation errors as a response
    return res.status(400).json({
      status: 'fail',
      message: 'Invalid input data',
      errors: errors.array(),
    });
  }

  // Proceed to the next middleware or route handler
  next();
}

module.exports = validationMiddleware;
