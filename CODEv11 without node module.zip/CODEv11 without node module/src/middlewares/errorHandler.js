// /src/middlewares/errorHandler.js

const logger = require('../utils/loggerService');

/**
 * Centralized error handling middleware for the platform.
 * Logs exceptions and responds with meaningful error messages.
 */
function errorHandler(err, req, res, next) {
  // Log the error details
  logger.error(`Error: ${err.message}`, {
    method: req.method,
    url: req.url,
    stack: err.stack,
  });

  // Determine the appropriate status code and message
  const statusCode = err.statusCode || 500;
  const errorMessage = statusCode === 500 ? 'Internal Server Error' : err.message;

  // Send the error response to the client
  res.status(statusCode).json({
    status: 'error',
    message: errorMessage,
  });
}

module.exports = errorHandler;
