// /src/services/openaiService.js

const axios = require('axios');
const { openaiApiKey } = require('../config/openai'); // OpenAI API config
const logger = require('../utils/loggerService');

class OpenAIService {
  constructor() {
    this.apiUrl = 'https://api.openai.com/v1/completions';
    this.apiKey = openaiApiKey;
  }

  /**
   * Generates a prompt based on user metrics and voting context.
   * @param {Object} userMetrics - The user's metrics, including reputation, expertise, etc.
   * @param {Number} baseVoteValue - The base value of the vote.
   * @returns {String} The generated prompt.
   */
  generatePrompt(userMetrics, baseVoteValue) {
    const { reputation, expertise, ethicalStanding, specialistInfluence } = userMetrics;
    return `
      Given the following user metrics:
      - Reputation: ${reputation}
      - Expertise: ${expertise}
      - Ethical Standing: ${ethicalStanding}
      - Specialist Influence: ${specialistInfluence}

      Please adjust the base vote value of ${baseVoteValue} to reflect the influence of these metrics.
    `;
  }

  /**
   * Makes a request to the OpenAI API to retrieve AI-generated vote weight adjustments.
   * @param {Object} userMetrics - The user's metrics for generating the prompt.
   * @param {Number} baseVoteValue - The base vote value.
   * @returns {Number} The AI-adjusted vote weight.
   */
  async callOpenAI(userMetrics, baseVoteValue) {
    try {
      const prompt = this.generatePrompt(userMetrics, baseVoteValue);

      const response = await axios.post(this.apiUrl, {
        model: 'text-davinci-003',
        prompt: prompt,
        max_tokens: 50,
        temperature: 0.5,
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      const aiResponse = response.data.choices[0].text.trim();
      const adjustedVoteWeight = this.extractVoteWeight(aiResponse, baseVoteValue);
      
      logger.info(`AI-generated vote weight: ${adjustedVoteWeight} based on user metrics.`);
      return adjustedVoteWeight;
    } catch (error) {
      logger.error(`Error calling OpenAI API: ${error.message}`);
      // Fall back to base vote value if the API call fails
      return baseVoteValue;
    }
  }

  /**
   * Extracts the vote weight from the OpenAI response.
   * @param {String} aiResponse - The raw text response from the AI model.
   * @param {Number} baseVoteValue - The original base vote value.
   * @returns {Number} The extracted vote weight, or the base vote value if parsing fails.
   */
  extractVoteWeight(aiResponse, baseVoteValue) {
    const parsedWeight = parseFloat(aiResponse);
    if (!isNaN(parsedWeight)) {
      return Math.max(1, Math.min(parsedWeight, 10)); // Clamps value between 1 and 10
    }
    return baseVoteValue; // Fallback to base value if parsing fails
  }
}

module.exports = new OpenAIService();
