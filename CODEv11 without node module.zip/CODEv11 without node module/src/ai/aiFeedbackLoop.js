// /src/ai/aiFeedbackLoop.js

const logger = require('../utils/loggerService');
const { calculateVoteWeight } = require('./aiVoteWeighting');
const Vote = require('../models/voteModel');
const UserMetricsService = require('../services/userMetrics');

class AIFeedbackLoop {
  /**
   * Recalibrate vote weight formulas based on user behavior and voting patterns.
   * Continuously adjusts AI vote weightings for improved fairness and accuracy.
   */
  async recalibrateVoteWeights() {
    try {
      // Get all recent votes from the database
      const recentVotes = await Vote.find({ createdAt: { $gte: this.getRecalibrationWindow() } });

      // Iterate through recent votes and adjust weights based on user behavior
      for (const vote of recentVotes) {
        const userMetrics = await UserMetricsService.getUserMetrics(vote.userId);

        // Use the AI-driven vote weight recalibration logic
        const newVoteWeight = await calculateVoteWeight(vote.userId, vote.voteValue, userMetrics);

        // Apply the recalibrated vote weight to the vote
        vote.weightedVote = newVoteWeight;
        await vote.save();

        logger.info(`Recalibrated vote weight for user ${vote.userId} on vote ${vote._id}`);
      }

      logger.info('Vote weight recalibration complete.');
    } catch (error) {
      logger.error(`Error recalibrating vote weights: ${error.message}`);
      throw new Error('Failed to recalibrate vote weights.');
    }
  }

  /**
   * Define the recalibration window (e.g., last 30 days).
   * @returns {Date} The starting point for the recalibration window.
   */
  getRecalibrationWindow() {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return thirtyDaysAgo;
  }
}

module.exports = new AIFeedbackLoop();
