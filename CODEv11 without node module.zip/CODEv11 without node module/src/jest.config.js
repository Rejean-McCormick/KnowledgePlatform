module.exports = {
  testEnvironment: 'node', // Use Node.js environment for testing
  verbose: true, // Display detailed test results
  testMatch: ['**/tests/**/*.test.js'], // Match test files in the /tests folder
  collectCoverage: true, // Enable test coverage reporting
  collectCoverageFrom: [
    'src/**/*.js', // Include all JS files in /src for coverage
    '!src/**/index.js', // Exclude index.js files from coverage
    '!src/**/*.config.js', // Exclude configuration files from coverage
  ],
  coverageDirectory: 'coverage', // Specify the directory to store coverage reports
  coverageReporters: ['json', 'lcov', 'text', 'clover'], // Generate different coverage report formats
  moduleFileExtensions: ['js', 'json'], // Supported file types
  setupFilesAfterEnv: ['./jest.setup.js'], // Optional: Configure setup file for global test settings
  testTimeout: 10000, // Set a global timeout of 10 seconds for tests
  resetMocks: true, // Reset mocks between each test to avoid test contamination
  clearMocks: true, // Clear mocks automatically after each test
};
