const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const { json, urlencoded } = require('body-parser');

// Import routes
const voteRoutes = require('./routes/voteRoutes');
const userRoutes = require('./routes/userRoutes');

// Import middleware
const authMiddleware = require('./middlewares/authMiddleware');
const errorHandler = require('./middlewares/errorHandler');

// WebSocket setup
const { setupWebSocket } = require('./real-time/socketServer');

// Initialize Express app
const app = express();

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https:"], // Adjust CSP for your case
      objectSrc: ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  crossOriginResourcePolicy: { policy: "same-origin" },
}));
app.use(cors({
  origin: process.env.CLIENT_ORIGIN || '*', // Adjust based on your production domain
  methods: ['GET', 'POST'],
}));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Body parsing middleware
app.use(json());
app.use(urlencoded({ extended: true }));

// Authentication middleware
app.use(authMiddleware);

// API routes
app.use('/api/votes', voteRoutes);
app.use('/api/users', userRoutes);

// Serve static files from the React frontend only in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'src/frontend/build')));

  // Fallback route to serve index.html for unknown routes
  app.get('*', (req, res, next) => {
    res.sendFile(path.join(__dirname, 'src/frontend/build', 'index.html'), (err) => {
      if (err) {
        next(err);
      }
    });
  });
}

// Error handling middleware
app.use(errorHandler);

// Create HTTP server and WebSocket server
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.CLIENT_ORIGIN || '*', // Adjust origin in production
    methods: ['GET', 'POST'],
    credentials: true, // If sending cookies or authentication tokens
  },
});

// Set up WebSocket connections
setupWebSocket(io);

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
