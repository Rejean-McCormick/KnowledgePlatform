// reportWebVitals.js
// Frontend Guide: This file tracks and logs performance metrics of the application for analysis or external monitoring.

const reportWebVitals = (onPerfEntry) => {
  if (onPerfEntry && typeof onPerfEntry === 'function') {
    import('web-vitals').then(({ getCLS, getFID, getFCP, getLCP, getTTFB }) => {
      // Cumulative Layout Shift (CLS) - measures visual stability.
      getCLS(onPerfEntry);

      // First Input Delay (FID) - measures responsiveness to user input.
      getFID(onPerfEntry);

      // First Contentful Paint (FCP) - measures the time until the first content appears on the screen.
      getFCP(onPerfEntry);

      // Largest Contentful Paint (LCP) - measures loading performance, from navigation to the largest visual element appearing.
      getLCP(onPerfEntry);

      // Time to First Byte (TTFB) - measures the delay between the start of the request and the first byte received from the server.
      getTTFB(onPerfEntry);
    }).catch((err) => {
      console.error('Failed to load web-vitals module:', err);
    });
  }
};

export default reportWebVitals;
