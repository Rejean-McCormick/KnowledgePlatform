// /src/services/redisCacheService.js

const { getRedisClient } = require('../config/redisConfig');
const logger = require('../utils/loggerService');

class RedisCacheService {
  constructor() {
    this.redisClient = getRedisClient();
  }

  /**
   * Cache data in Redis with a specified expiration time.
   * @param {String} key - The cache key.
   * @param {Object} value - The data to cache.
   * @param {Number} expiration - Expiration time in seconds (default: 3600 seconds / 1 hour).
   */
  async cacheData(key, value, expiration = 3600) {
    try {
      await this.redisClient.set(key, JSON.stringify(value), 'EX', expiration);
      logger.info(`Data cached for key: ${key}`);
    } catch (error) {
      logger.error(`Error caching data for key ${key}: ${error.message}`);
      throw new Error('Failed to cache data.');
    }
  }

  /**
   * Retrieve data from the Redis cache by key.
   * @param {String} key - The cache key.
   * @returns {Object|null} The cached data, or null if not found.
   */
  async getData(key) {
    try {
      const cachedData = await this.redisClient.get(key);
      if (cachedData) {
        logger.info(`Cache hit for key: ${key}`);
        return JSON.parse(cachedData);
      }
      logger.info(`Cache miss for key: ${key}`);
      return null;
    } catch (error) {
      logger.error(`Error retrieving data from cache for key ${key}: ${error.message}`);
      throw new Error('Failed to retrieve cached data.');
    }
  }

  /**
   * Invalidate cache by key.
   * @param {String} key - The cache key.
   */
  async invalidateCache(key) {
    try {
      await this.redisClient.del(key);
      logger.info(`Cache invalidated for key: ${key}`);
    } catch (error) {
      logger.error(`Error invalidating cache for key ${key}: ${error.message}`);
      throw new Error('Failed to invalidate cache.');
    }
  }

  /**
   * Cache user metrics for quicker access during calculations.
   * @param {String} userId - The user's ID.
   * @param {Object} metrics - The user's metrics to cache.
   */
  async cacheUserMetrics(userId, metrics) {
    const cacheKey = `user:metrics:${userId}`;
    await this.cacheData(cacheKey, metrics, 3600);
  }

  /**
   * Retrieve cached user metrics by user ID.
   * @param {String} userId - The user's ID.
   * @returns {Object|null} The cached user metrics or null if not found.
   */
  async getUserMetrics(userId) {
    const cacheKey = `user:metrics:${userId}`;
    return await this.getData(cacheKey);
  }

  /**
   * Cache vote results for quicker access during result aggregation.
   * @param {String} voteId - The ID of the vote.
   * @param {Object} results - The vote results to cache.
   */
  async cacheVoteResults(voteId, results) {
    const cacheKey = `vote:results:${voteId}`;
    await this.cacheData(cacheKey, results, 3600);
  }

  /**
   * Retrieve cached vote results by vote ID.
   * @param {String} voteId - The ID of the vote.
   * @returns {Object|null} The cached vote results or null if not found.
   */
  async getVoteResults(voteId) {
    const cacheKey = `vote:results:${voteId}`;
    return await this.getData(cacheKey);
  }
}

module.exports = new RedisCacheService();
