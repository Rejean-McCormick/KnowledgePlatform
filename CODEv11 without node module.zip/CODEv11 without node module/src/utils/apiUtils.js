import axios from 'axios';

const API_URL = 'https://api.example.com';

export const getAuthToken = () => {
  return localStorage.getItem('authToken');
};

export const setAuthToken = (token) => {
  localStorage.setItem('authToken', token);
};

export const clearAuthToken = () => {
  localStorage.removeItem('authToken');
};

const apiRequest = async (method, url, data = null, headers = {}) => {
  const token = getAuthToken();
  const config = {
    method,
    url: `${API_URL}${url}`,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...headers,
    },
    data,
  };

  try {
    const response = await axios(config);
    return response.data;
  } catch (error) {
    console.error('API Request Error:', error.response || error.message);
    throw error.response ? error.response.data : error;
  }
};

export const get = (url, headers = {}) => apiRequest('GET', url, null, headers);

export const post = (url, data, headers = {}) => apiRequest('POST', url, data, headers);

export const put = (url, data, headers = {}) => apiRequest('PUT', url, data, headers);

export const del = (url, headers = {}) => apiRequest('DELETE', url, null, headers);
 
