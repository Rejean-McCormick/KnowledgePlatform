// /src/utils/authUtils.js

export const getAuthToken = () => {
  try {
    return localStorage.getItem('authToken');
  } catch (error) {
    console.error('Error accessing localStorage:', error);
    return null;
  }
};

export const setAuthToken = (token) => {
  try {
    localStorage.setItem('authToken', token);
  } catch (error) {
    console.error('Error setting auth token in localStorage:', error);
  }
};

export const clearAuthToken = () => {
  try {
    localStorage.removeItem('authToken');
  } catch (error) {
    console.error('Error clearing auth token from localStorage:', error);
  }
};

export const isTokenExpired = (token) => {
  if (!token) return true;
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const expiration = payload.exp * 1000;
    return Date.now() >= expiration;
  } catch (error) {
    console.error('Error decoding token:', error);
    return true;
  }
};

export const login = (token) => {
  setAuthToken(token);
};

export const logout = () => {
  clearAuthToken();
};

export const isAuthenticated = () => {
  const token = getAuthToken();
  return token && !isTokenExpired(token);
};
