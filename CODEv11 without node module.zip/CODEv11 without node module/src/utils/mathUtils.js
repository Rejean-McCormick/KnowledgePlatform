// Calculate the weighted average of an array of values with corresponding weights
const weightedAverage = (values, weights) => {
  const totalWeight = weights.reduce((acc, weight) => acc + weight, 0);
  const weightedSum = values.reduce((acc, value, index) => acc + value * weights[index], 0);
  return weightedSum / totalWeight;
};

// Calculate the sum of an array of numbers
const sum = (numbers) => {
  return numbers.reduce((acc, num) => acc + num, 0);
};

// Calculate the mean of an array of numbers
const mean = (numbers) => {
  return sum(numbers) / numbers.length;
};

// Round a number to a specific number of decimal places
const roundToDecimal = (num, decimalPlaces) => {
  const factor = Math.pow(10, decimalPlaces);
  return Math.round(num * factor) / factor;
};

// Calculate the standard deviation of an array of numbers
const standardDeviation = (numbers) => {
  const avg = mean(numbers);
  const variance = mean(numbers.map(num => Math.pow(num - avg, 2)));
  return Math.sqrt(variance);
};

module.exports = {
  weightedAverage,
  sum,
  mean,
  roundToDecimal,
  standardDeviation,
};
