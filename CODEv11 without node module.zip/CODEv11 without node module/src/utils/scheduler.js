const cron = require('node-cron');
const { recalculateUserRoles } = require('./userService');
const { cleanupOldVotes, cleanupLogs } = require('./databaseCleanupService');
const logger = require('../utils/loggerService');

// Schedule role recalculations every day at midnight
const scheduleUserRoleRecalculation = () => {
  cron.schedule('0 0 * * *', async () => {
    try {
      logger.logInfo('Starting user role recalculation job');
      await recalculateUserRoles();
      logger.logInfo('User role recalculation job completed');
    } catch (error) {
      logger.logError('Error during user role recalculation job', error);
    }
  });
};

// Schedule database cleanup every Sunday at 3:00 AM
const scheduleDatabaseCleanup = () => {
  cron.schedule('0 3 * * 0', async () => {
    try {
      logger.logInfo('Starting database cleanup job');
      await cleanupOldVotes();
      await cleanupLogs();
      logger.logInfo('Database cleanup job completed');
    } catch (error) {
      logger.logError('Error during database cleanup job', error);
    }
  });
};

// Start all scheduled jobs
const startScheduledJobs = () => {
  scheduleUserRoleRecalculation();
  scheduleDatabaseCleanup();
  logger.logInfo('All scheduled jobs have been started');
};

module.exports = {
  startScheduledJobs,
};
