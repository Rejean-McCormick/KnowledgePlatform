const jwt = require('jsonwebtoken');
const { promisify } = require('util');

// Generate JWT
const generateToken = (payload, secretKey, expiresIn = '1h') => {
  return jwt.sign(payload, secretKey, { expiresIn });
};

// Verify JWT
const verifyToken = async (token, secretKey) => {
  try {
    const decoded = await promisify(jwt.verify)(token, secretKey);
    return { valid: true, expired: false, decoded };
  } catch (err) {
    return { valid: false, expired: err.name === 'TokenExpiredError', decoded: null };
  }
};

// Decode JWT without verification
const decodeToken = (token) => {
  return jwt.decode(token);
};

module.exports = {
  generateToken,
  verifyToken,
  decodeToken,
};
