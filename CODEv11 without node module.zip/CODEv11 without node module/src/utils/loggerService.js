// /src/utils/loggerService.js

const winston = require('winston');

// Create a logger instance using Winston
const logger = winston.createLogger({
  level: 'info', // Default logging level
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message} ${Object.keys(meta).length ? JSON.stringify(meta) : ''}`;
    })
  ),
  transports: [
    // Log to a file for persistent logging
    new winston.transports.File({ filename: 'logs/app.log', level: 'info' }),

    // Log errors to a separate file
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),

    // Console logging for real-time debugging in development
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    }),
  ],
});

/**
 * Capture important events across the platform:
 * - `info`: Regular application activity (e.g., service activity).
 * - `error`: Captures errors (e.g., exceptions, API failures).
 * - `warn`: Warning level logs.
 * - `debug`: Detailed logs for debugging purposes.
 */

module.exports = logger;
