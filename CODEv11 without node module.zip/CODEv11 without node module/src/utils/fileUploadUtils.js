export const isValidFileType = (file, allowedTypes) => {
  return allowedTypes.includes(file.type);
};

export const isFileSizeValid = (file, maxSizeInMB) => {
  const maxSizeInBytes = maxSizeInMB * 1024 * 1024;
  return file.size <= maxSizeInBytes;
};

export const uploadFile = async (file, url, onProgress) => {
  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch(url, {
      method: 'POST',
      body: formData,
      headers: {
        Authorization: `Bearer ${localStorage.getItem('authToken')}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Upload failed with status ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('File upload error:', error);
    throw error;
  }
};

export const handleFileUpload = async (file, url, allowedTypes, maxSizeInMB, onProgress) => {
  if (!isValidFileType(file, allowedTypes)) {
    throw new Error('Invalid file type');
  }

  if (!isFileSizeValid(file, maxSizeInMB)) {
    throw new Error('File size exceeds limit');
  }

  return uploadFile(file, url, onProgress);
};
 
