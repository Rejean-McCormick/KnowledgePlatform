// Format large numbers with commas (e.g., 1000 -> 1,000)
const formatNumberWithCommas = (number) => {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

// Format a percentage value (e.g., 0.1234 -> "12.34%")
const formatPercentage = (value, decimalPlaces = 2) => {
  return (value * 100).toFixed(decimalPlaces) + '%';
};

// Format vote results as a percentage (e.g., 0.75 -> "75%")
const formatVoteResult = (value) => {
  return formatPercentage(value, 0);
};

// Format a metric with a label (e.g., 1200 votes -> "1,200 votes")
const formatMetric = (value, label) => {
  return `${formatNumberWithCommas(value)} ${label}`;
};

// Capitalize the first letter of a string
const capitalizeFirstLetter = (str) => {
  return str.charAt(0).toUpperCase() + str.slice(1);
};

module.exports = {
  formatNumberWithCommas,
  formatPercentage,
  formatVoteResult,
  formatMetric,
  capitalizeFirstLetter,
};
