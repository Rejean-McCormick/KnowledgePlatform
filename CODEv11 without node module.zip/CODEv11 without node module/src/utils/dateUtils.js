export const formatDate = (date, locale = 'en-US', options = {}) => {
  return new Date(date).toLocaleDateString(locale, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    ...options,
  });
};

export const timeAgo = (date) => {
  const now = new Date();
  const past = new Date(date);
  const seconds = Math.floor((now - past) / 1000);

  const intervals = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60,
  };

  for (let key in intervals) {
    const value = Math.floor(seconds / intervals[key]);
    if (value > 1) {
      return `${value} ${key}s ago`;
    } else if (value === 1) {
      return `1 ${key} ago`;
    }
  }

  return 'Just now';
};

export const formatDateToTimeZone = (date, timeZone, locale = 'en-US', options = {}) => {
  return new Date(date).toLocaleString(locale, {
    timeZone,
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    ...options,
  });
};
 
