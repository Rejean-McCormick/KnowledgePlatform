const validator = require('validator');

// Validate email format
const validateEmail = (email) => {
  return validator.isEmail(email);
};

// Validate password strength (at least 8 characters, 1 letter, 1 number)
const validatePassword = (password) => {
  const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
  return passwordRegex.test(password);
};

// Validate vote option (must be a non-empty string)
const validateVoteOption = (voteOption) => {
  return typeof voteOption === 'string' && voteOption.trim().length > 0;
};

// Validate username (alphanumeric, 3-16 characters)
const validateUsername = (username) => {
  const usernameRegex = /^[a-zA-Z0-9]{3,16}$/;
  return usernameRegex.test(username);
};

module.exports = {
  validateEmail,
  validatePassword,
  validateVoteOption,
  validateUsername,
};
