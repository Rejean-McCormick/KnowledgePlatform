// Remove duplicates from an array
const removeDuplicates = (arr) => {
  return [...new Set(arr)];
};

// Sort an array of objects by a specific key
const sortByKey = (arr, key, ascending = true) => {
  return arr.sort((a, b) => {
    if (a[key] < b[key]) return ascending ? -1 : 1;
    if (a[key] > b[key]) return ascending ? 1 : -1;
    return 0;
  });
};

// Filter an array of objects by a specific key and value
const filterByKey = (arr, key, value) => {
  return arr.filter(item => item[key] === value);
};

// Chunk an array into smaller arrays of a specified size
const chunkArray = (arr, size) => {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
};

// Flatten a multi-dimensional array into a single array
const flattenArray = (arr) => {
  return arr.reduce((acc, val) => acc.concat(Array.isArray(val) ? flattenArray(val) : val), []);
};

module.exports = {
  removeDuplicates,
  sortByKey,
  filterByKey,
  chunkArray,
  flattenArray,
};
