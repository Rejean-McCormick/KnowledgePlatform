import React, { useState } from 'react';
import './SubmitPage.module.css';

const SubmitPage = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const allowedFileTypes = ['application/pdf', 'image/jpeg', 'image/png'];
  const maxFileSizeInMB = 5;

  const isValidFileType = (file, allowedFileTypes) => {
    return allowedFileTypes.includes(file.type);
  };

  const isFileSizeValid = (file, maxFileSizeInMB) => {
    const maxSizeInBytes = maxFileSizeInMB * 1024 * 1024;
    return file.size <= maxSizeInBytes;
  };

  const handleFileUpload = async (file, uploadUrl) => {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(uploadUrl, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('File upload failed');
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!title || !content) {
      setError('Title and content are required');
      return;
    }

    if (file) {
      if (!isValidFileType(file, allowedFileTypes)) {
        setError('Invalid file type');
        return;
      }

      if (!isFileSizeValid(file, maxFileSizeInMB)) {
        setError(`File size exceeds the limit of ${maxFileSizeInMB}MB`);
        return;
      }
    }

    setIsSubmitting(true);
    try {
      if (file) {
        await handleFileUpload(file, '/api/upload');
      }

      const submissionData = {
        title,
        content,
      };

      await fetch('/api/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(submissionData),
      });

      setError('');
      alert('Submission successful');
    } catch (err) {
      setError('Submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  return (
    <div className="submit-page">
      <h1>Submit Content</h1>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label htmlFor="title">Title</label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <label htmlFor="content">Content</label>
        <textarea
          id="content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />

        <label htmlFor="file">Upload File (optional)</label>
        <input type="file" id="file" onChange={handleFileChange} />

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default SubmitPage;
