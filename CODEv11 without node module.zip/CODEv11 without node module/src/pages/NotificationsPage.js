import React, { useState, useEffect } from 'react';
import './NotificationsPage.module.css';

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await fetch('/api/notifications');
        const data = await response.json();
        setNotifications(data);
      } catch (err) {
        setError('Failed to load notifications.');
      }
    };

    fetchNotifications();

    const interval = setInterval(fetchNotifications, 5000); // Real-time updates every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const markAsRead = async (notificationId) => {
    try {
      await fetch(`/api/notifications/${notificationId}/read`, { method: 'POST' });
      setNotifications(notifications.map((notification) =>
        notification.id === notificationId ? { ...notification, read: true } : notification
      ));
    } catch (err) {
      setError('Failed to mark notification as read.');
    }
  };

  return (
    <div className="notifications-page">
      <h1>Notifications</h1>
      {error && <p className="error-message">{error}</p>}
      <ul className="notifications-list">
        {notifications.map((notification) => (
          <li key={notification.id} className={notification.read ? 'read' : 'unread'}>
            <p>{notification.message}</p>
            <span>{notification.date}</span>
            {!notification.read && (
              <button onClick={() => markAsRead(notification.id)} aria-label="Mark as read">
                Mark as Read
              </button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NotificationsPage;
 
