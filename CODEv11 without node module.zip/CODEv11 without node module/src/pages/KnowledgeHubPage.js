import React, { useState, useEffect } from 'react';
import './KnowledgeHubPage.module.css';
import SearchBar from '../components/SearchBar';

import Pagination from '../components/Pagination';


const KnowledgeHubPage = () => {
  const [resources, setResources] = useState([]);
  const [filteredResources, setFilteredResources] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [resourcesPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('all');

  useEffect(() => {
    const fetchResources = async () => {
      const response = await fetch('/api/resources');
      const data = await response.json();
      setResources(data);
      setFilteredResources(data);
    };
    fetchResources();
  }, []);

  const handleSearch = (term) => {
    setSearchTerm(term);
    filterResources(term, category);
  };

  const handleCategoryChange = (category) => {
    setCategory(category);
    filterResources(searchTerm, category);
  };

  const filterResources = (term, category) => {
    let updatedResources = resources;
    if (term) {
      updatedResources = updatedResources.filter((resource) =>
        resource.title.toLowerCase().includes(term.toLowerCase())
      );
    }
    if (category !== 'all') {
      updatedResources = updatedResources.filter((resource) => resource.category === category);
    }
    setFilteredResources(updatedResources);
  };

  const indexOfLastResource = currentPage * resourcesPerPage;
  const indexOfFirstResource = indexOfLastResource - resourcesPerPage;
  const currentResources = filteredResources.slice(indexOfFirstResource, indexOfLastResource);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="knowledge-hub-page">
      <h1>Knowledge Hub</h1>
      <SearchBar onSearch={handleSearch} />
      <select
        aria-label="Filter by category"
        value={category}
        onChange={(e) => handleCategoryChange(e.target.value)}
      >
        <option value="all">All Categories</option>
        <option value="articles">Articles</option>
        <option value="resources">Resources</option>
        <option value="discussions">Discussions</option>
      </select>
      <ul className="resource-list">
        {currentResources.map((resource) => (
          <li key={resource.id} className="resource-item">
            <h2>{resource.title}</h2>
            <p>{resource.description}</p>
            <span>Category: {resource.category}</span>
          </li>
        ))}
      </ul>
      <Pagination
        itemsPerPage={resourcesPerPage}
        totalItems={filteredResources.length}
        paginate={paginate}
        currentPage={currentPage}
      />
    </div>
  );
};

export default KnowledgeHubPage;
 
