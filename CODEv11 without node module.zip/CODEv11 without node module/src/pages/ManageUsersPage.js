import React, { useState, useEffect } from 'react';
import './ManageUsersPage.module.css';

const ManageUsersPage = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [role, setRole] = useState('');
  const [accountStatus, setAccountStatus] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('/api/admin/users');
        const data = await response.json();
        setUsers(data);
      } catch (err) {
        setError('Failed to load users.');
      }
    };
    fetchUsers();
  }, []);

  const handleEditUser = (user) => {
    setSelectedUser(user);
    setRole(user.role);
    setAccountStatus(user.status);
  };

  const handleSave = async () => {
    try {
      const updatedUser = { ...selectedUser, role, status: accountStatus };
      await fetch(`/api/admin/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedUser),
      });
      setUsers(users.map((user) => (user.id === selectedUser.id ? updatedUser : user)));
      setSelectedUser(null);
    } catch (err) {
      setError('Failed to update user.');
    }
  };

  return (
    <div className="manage-users-page">
      <h1>Manage Users</h1>
      {error && <p className="error-message">{error}</p>}
      <ul className="user-list">
        {users.map((user) => (
          <li key={user.id}>
            <span>{user.name}</span>
            <span>{user.role}</span>
            <span>{user.status}</span>
            <button onClick={() => handleEditUser(user)}>Edit</button>
          </li>
        ))}
      </ul>

      {selectedUser && (
        <div className="user-edit-form">
          <h2>Edit User: {selectedUser.name}</h2>
          <label htmlFor="role">Role</label>
          <select id="role" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="moderator">Moderator</option>
          </select>

          <label htmlFor="status">Account Status</label>
          <select id="status" value={accountStatus} onChange={(e) => setAccountStatus(e.target.value)}>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
            <option value="inactive">Inactive</option>
          </select>

          <button onClick={handleSave}>Save Changes</button>
          <button onClick={() => setSelectedUser(null)}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default ManageUsersPage;
 
