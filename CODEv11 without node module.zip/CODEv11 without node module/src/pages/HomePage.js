import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.module.css'; // Importing CSS for the page

const HomePage = () => {
  return (
    <div className="home-page">
      {/* Main header with navigation */}
      <header className="main-header">
        <nav aria-label="Main Navigation">
          <div className="logo">
            <Link to="/">
              <img src="/images/logo.png" alt="Knowledge Platform Logo" />
            </Link>
          </div>
          <ul className="navigation">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/topics">Topics</Link></li>
            <li><Link to="/dashboard">Dashboard</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <h1>Welcome to Knowledge Platform</h1>
        <p>Your hub for sharing and exploring knowledge across various topics and domains.</p>
        <Link to="/topics" className="cta-button">Explore Topics</Link>
      </section>

      {/* Features Section */}
      <section className="features">
        <h2>Platform Features</h2>
        <div className="feature-grid">
          <div className="feature-card">
            <h3>Share Knowledge</h3>
            <p>Contribute articles, research, and insights to a growing community of knowledge seekers.</p>
          </div>
          <div className="feature-card">
            <h3>Engage in Discussions</h3>
            <p>Join discussions on trending topics and engage with experts across different fields.</p>
          </div>
          <div className="feature-card">
            <h3>Collaborate</h3>
            <p>Work together on projects, debates, and research to develop new ideas and solutions.</p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials">
        <h2>What People Are Saying</h2>
        <div className="testimonial">
          <p>"The Knowledge Platform has transformed the way I collaborate with peers. It’s a one-stop solution for engaging with the global community!"</p>
          <span>- Maria L., Researcher</span>
        </div>
        <div className="testimonial">
          <p>"A fantastic resource for sharing knowledge. The ability to connect with like-minded individuals is amazing."</p>
          <span>- John D., Entrepreneur</span>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="main-footer">
        <p>&copy; 2024 Knowledge Platform. All rights reserved.</p>
        <ul className="social-media">
          <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><img src="/images/facebook-icon.png" alt="Facebook" /></a></li>
          <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer"><img src="/images/twitter-icon.png" alt="Twitter" /></a></li>
          <li><a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"><img src="/images/linkedin-icon.png" alt="LinkedIn" /></a></li>
        </ul>
      </footer>
    </div>
  );
};

export default HomePage;
