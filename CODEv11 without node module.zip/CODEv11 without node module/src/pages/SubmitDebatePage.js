import React, { useState } from 'react';
import './SubmitDebatePage.module.css';

const SubmitDebatePage = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!title || !description || !category) {
      setError('All fields are required');
      return;
    }

    setIsSubmitting(true);
    try {
      const debateData = {
        title,
        description,
        category,
      };

      await fetch('/api/debates', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(debateData),
      });

      setError('');
      alert('Debate submitted successfully');
    } catch (err) {
      setError('Submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
    if (e.target.value.trim().length < 5) {
      setError('Title must be at least 5 characters');
    } else {
      setError('');
    }
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
    if (e.target.value.trim().length < 10) {
      setError('Description must be at least 10 characters');
    } else {
      setError('');
    }
  };

  return (
    <div className="submit-debate-page">
      <h1>Submit a Debate Topic</h1>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label htmlFor="title">Title</label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={handleTitleChange}
          required
        />

        <label htmlFor="description">Description</label>
        <textarea
          id="description"
          value={description}
          onChange={handleDescriptionChange}
          required
        />

        <label htmlFor="category">Category</label>
        <select
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          required
        >
          <option value="">Select a category</option>
          <option value="politics">Politics</option>
          <option value="technology">Technology</option>
          <option value="health">Health</option>
        </select>

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default SubmitDebatePage;
 
