import React, { useState, useEffect } from 'react';
import './TopicsPage.module.css';
import SearchBar from '../components/SearchBar';

import Pagination from '../components/Pagination';


const TopicsPage = () => {
  const [topics, setTopics] = useState([]);
  const [filteredTopics, setFilteredTopics] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [topicsPerPage] = useState(10);
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('all');

  useEffect(() => {
    // Simulate fetching topics from API
    const fetchTopics = async () => {
      const response = await fetch('/api/topics');
      const data = await response.json();
      setTopics(data);
      setFilteredTopics(data);
    };
    fetchTopics();
  }, []);

  const handleSearch = (term) => {
    setSearchTerm(term);
    filterTopics(term, category);
  };

  const handleCategoryChange = (category) => {
    setCategory(category);
    filterTopics(searchTerm, category);
  };

  const filterTopics = (term, category) => {
    let updatedTopics = topics;
    if (term) {
      updatedTopics = updatedTopics.filter((topic) =>
        topic.title.toLowerCase().includes(term.toLowerCase())
      );
    }
    if (category !== 'all') {
      updatedTopics = updatedTopics.filter((topic) => topic.category === category);
    }
    setFilteredTopics(updatedTopics);
  };

  const indexOfLastTopic = currentPage * topicsPerPage;
  const indexOfFirstTopic = indexOfLastTopic - topicsPerPage;
  const currentTopics = filteredTopics.slice(indexOfFirstTopic, indexOfLastTopic);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="topics-page">
      <h1>Topics</h1>
      <SearchBar onSearch={handleSearch} />
      <select
        aria-label="Filter by category"
        value={category}
        onChange={(e) => handleCategoryChange(e.target.value)}
      >
        <option value="all">All Categories</option>
        <option value="technology">Technology</option>
        <option value="health">Health</option>
        <option value="environment">Environment</option>
      </select>
      <ul className="topics-list">
        {currentTopics.map((topic) => (
          <li key={topic.id} className="topic-item">
            <h2>{topic.title}</h2>
            <p>{topic.description}</p>
            <span>Category: {topic.category}</span>
          </li>
        ))}
      </ul>
      <Pagination
        topicsPerPage={topicsPerPage}
        totalTopics={filteredTopics.length}
        paginate={paginate}
        currentPage={currentPage}
      />
    </div>
  );
};

export default TopicsPage;
 
