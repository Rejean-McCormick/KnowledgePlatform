import React, { useState, useEffect } from 'react';
import './CollaborationHubPage.module.css';

const CollaborationHubPage = () => {
  const [projects, setProjects] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await fetch('/api/collaborations');
        const data = await response.json();
        setProjects(data);
      } catch (err) {
        setError('Failed to load projects.');
      }
    };

    fetchProjects();
  }, []);

  return (
    <div className="collaboration-hub-page">
      <h1>Collaboration Hub</h1>
      {error && <p className="error-message">{error}</p>}
      <ul className="project-list">
        {projects.map((project) => (
          <li key={project.id} className="project-card">
            <h2>{project.title}</h2>
            <p>{project.description}</p>
            <h4>Contributors:</h4>
            <ul className="contributors-list">
              {project.contributors.map((contributor) => (
                <li key={contributor.id}>{contributor.name}</li>
              ))}
            </ul>
            <h4>Progress:</h4>
            <p>{project.progress}% complete</p>
            <a href={`/projects/${project.id}`} className="button">View Project</a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CollaborationHubPage;
 
