import React, { useState, useEffect } from 'react';
import './VotePage.module.css';

const VotePage = ({ topicId }) => {
  const [topic, setTopic] = useState(null);
  const [userVote, setUserVote] = useState(null);
  const [voteCounts, setVoteCounts] = useState({ upvotes: 0, downvotes: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTopic = async () => {
      try {
        const response = await fetch(`/api/votes/topics/${topicId}`);
        const data = await response.json();
        setTopic(data.topic);
        setVoteCounts({ upvotes: data.upvotes, downvotes: data.downvotes });
        setUserVote(data.userVote);
      } catch (err) {
        setError('Failed to load topic data.');
      } finally {
        setLoading(false);
      }
    };

    fetchTopic();

    const interval = setInterval(fetchTopic, 5000); // Real-time vote updates every 5 seconds
    return () => clearInterval(interval);
  }, [topicId]);

  const handleVote = async (voteType) => {
    if (userVote === voteType) return; // Prevent duplicate voting
    try {
      const response = await fetch(`/api/votes/topics/${topicId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vote: voteType }),
      });

      const data = await response.json();
      setVoteCounts(data.voteCounts);
      setUserVote(voteType);
    } catch (err) {
      setError('Failed to submit vote.');
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div className="vote-page">
      <h1>{topic.title}</h1>
      <p>{topic.description}</p>

      <div className="vote-buttons">
        <button
          onClick={() => handleVote('upvote')}
          className={userVote === 'upvote' ? 'voted' : ''}
          aria-label="Upvote"
        >
          Upvote ({voteCounts.upvotes})
        </button>
        <button
          onClick={() => handleVote('downvote')}
          className={userVote === 'downvote' ? 'voted' : ''}
          aria-label="Downvote"
        >
          Downvote ({voteCounts.downvotes})
        </button>
      </div>
    </div>
  );
};

export default VotePage;
 
