import React, { useState, useEffect } from 'react';
import { useUser } from '../contexts/userContext'; 
import { useVoteContext } from '../contexts/voteContext';
import './DashboardPage.module.css';  // Importing CSS for the dashboard page

const DashboardPage = () => {
  const { user } = useUser();  // Access user context
  const { votes } = useVoteContext() || {};  // Access vote context and fallback to empty object
  const [metrics, setMetrics] = useState({});
  const [notifications, setNotifications] = useState([]);
  const [userStats, setUserStats] = useState({});
  const [recentActivity, setRecentActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch user metrics, notifications, stats, and activity on component mount
  useEffect(() => {
    // Log the user data for debugging
    console.log('User:', user);

    if (!user || !user.id || !user.token) {
      setError("User not authenticated");
      return;
    }

    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        const [metricsRes, notificationsRes, statsRes, activityRes] = await Promise.all([
          fetch(`/api/users/${user.id}/metrics`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
          fetch(`/api/users/${user.id}/notifications`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
          fetch('/api/dashboard/stats'),
          fetch('/api/dashboard/activity'),
        ]);

        // Check if the response is ok, if not throw an error for each
        if (!metricsRes.ok) throw new Error(`Failed to load metrics: ${metricsRes.status}`);
        if (!notificationsRes.ok) throw new Error(`Failed to load notifications: ${notificationsRes.status}`);
        if (!statsRes.ok) throw new Error(`Failed to load stats: ${statsRes.status}`);
        if (!activityRes.ok) throw new Error(`Failed to load recent activity: ${activityRes.status}`);

        // Parse JSON data
        const metricsData = await metricsRes.json();
        const notificationsData = await notificationsRes.json();
        const statsData = await statsRes.json();
        const activityData = await activityRes.json();

        setMetrics(metricsData);
        setNotifications(notificationsData);
        setUserStats(statsData);
        setRecentActivity(activityData);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);  // Log the error for debugging
        setError(err.message);  // Set the error state
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [user]);

  if (loading) {
    return <p>Loading dashboard...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  return (
    <div className="dashboard-page">
      <h1>Welcome, {user.username}</h1>

      {/* User Metrics Section */}
      <section className="user-metrics">
        <h2>Your Contributions</h2>
        <ul>
          <li><strong>Reputation:</strong> {metrics.reputation}</li>
          <li><strong>Votes Submitted:</strong> {metrics.votesSubmitted}</li>
          <li><strong>Influence Score:</strong> {metrics.influenceScore}</li>
          <li><strong>Ethical Standing:</strong> {metrics.ethicalStanding}</li>
        </ul>
      </section>

      {/* Voting History Section */}
      <section className="voting-history">
        <h2>Your Voting History</h2>
        {votes.history && votes.history.length > 0 ? (
          <ul>
            {votes.history.map((vote, index) => (
              <li key={index}>
                <strong>Issue:</strong> {vote.issue} - <strong>Your Vote:</strong> {vote.option}
              </li>
            ))}
          </ul>
        ) : (
          <p>You haven't voted yet.</p>
        )}
      </section>

      {/* Notifications Section */}
      <section className="notifications">
        <h2>Notifications</h2>
        {notifications.length > 0 ? (
          <ul>
            {notifications.map((notification, index) => (
              <li key={index}>
                {notification.message} - <em>{new Date(notification.date).toLocaleString()}</em>
              </li>
            ))}
          </ul>
        ) : (
          <p>No notifications at the moment.</p>
        )}
      </section>

      {/* User Stats Section */}
      <section className="stats-section">
        <h2>Your Stats</h2>
        <p>Articles Submitted: {userStats.articlesSubmitted}</p>
        <p>Discussions Participated: {userStats.discussionsParticipated}</p>
        <p>Followers: {userStats.followers}</p>
      </section>

      {/* Recent Activity Section */}
      <section className="recent-activity-section">
        <h2>Recent Activity</h2>
        <ul>
          {recentActivity.map((activity) => (
            <li key={activity.id}>
              <p>{activity.description}</p>
              <span>{activity.date}</span>
            </li>
          ))}
        </ul>
      </section>

      {/* Quick Links Section */}
      <section className="quick-links">
        <h2>Quick Links</h2>
        <ul>
          <li><a href="/submit">Submit New Article</a></li>
          <li><a href="/topics">Explore Topics</a></li>
          <li><a href="/profile">Edit Profile</a></li>
        </ul>
      </section>
    </div>
  );
};

export default DashboardPage;
