import React, { useState, useEffect } from 'react';
import './ProfilePage.module.css';

const ProfilePage = () => {
  const [profile, setProfile] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [updatedProfile, setUpdatedProfile] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch('/api/profile');
        if (!response.ok) throw new Error('Failed to fetch profile');
        const data = await response.json();
        setProfile(data);
        setUpdatedProfile(data);
      } catch (err) {
        setError('Unable to load profile details.');
      }
    };

    fetchProfile();
  }, []);

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    setUpdatedProfile(profile);
    setIsEditing(false);
  };

  const handleSave = async () => {
    try {
      const response = await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedProfile),
      });

      if (!response.ok) throw new Error('Failed to update profile');
      const data = await response.json();
      setProfile(data);
      setIsEditing(false);
    } catch (err) {
      setError('Unable to update profile.');
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedProfile({ ...updatedProfile, [name]: value });
  };

  if (error) {
    return <p>{error}</p>;
  }

  if (!profile) {
    return <p>Loading profile...</p>;
  }

  return (
    <div className="profile-page">
      <h1>Profile</h1>
      {isEditing ? (
        <div className="profile-edit">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={updatedProfile.name}
            onChange={handleChange}
          />

          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={updatedProfile.email}
            onChange={handleChange}
          />

          <label htmlFor="bio">Bio</label>
          <textarea
            id="bio"
            name="bio"
            value={updatedProfile.bio}
            onChange={handleChange}
          />

          <button onClick={handleSave}>Save</button>
          <button onClick={handleCancel}>Cancel</button>
        </div>
      ) : (
        <div className="profile-details">
          <p><strong>Name:</strong> {profile.name}</p>
          <p><strong>Email:</strong> {profile.email}</p>
          <p><strong>Bio:</strong> {profile.bio}</p>
          <button onClick={handleEdit}>Edit Profile</button>
        </div>
      )}

      <section className="profile-contributions">
        <h2>Your Contributions</h2>
        <ul>
          {profile.contributions.map((contribution) => (
            <li key={contribution.id}>
              <h3>{contribution.title}</h3>
              <p>{contribution.description}</p>
              <p>{new Date(contribution.date).toLocaleDateString()}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="profile-activity">
        <h2>Recent Activity</h2>
        <ul>
          {profile.activity.map((activity) => (
            <li key={activity.id}>
              <p>{activity.description}</p>
              <p>{new Date(activity.date).toLocaleDateString()}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default ProfilePage;
 
