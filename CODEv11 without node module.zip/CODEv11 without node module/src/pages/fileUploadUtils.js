// fileUploadUtils.js
import axios from 'axios';

/**
 * Upload a file to the server.
 * 
 * @param {File} file - The file object to be uploaded.
 * @param {String} uploadUrl - The URL where the file should be uploaded.
 * @param {Object} [additionalData] - Any additional data to send with the file upload request (optional).
 * @param {Function} [onUploadProgress] - A callback function to track the upload progress (optional).
 * @returns {Promise} - The response from the server after file upload.
 */
export const uploadFile = async (file, uploadUrl, additionalData = {}, onUploadProgress) => {
  try {
    const formData = new FormData();
    formData.append('file', file);

    // Append any additional data to the formData
    for (const key in additionalData) {
      if (Object.hasOwnProperty.call(additionalData, key)) {
        formData.append(key, additionalData[key]);
      }
    }

    const response = await axios.post(uploadUrl, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: onUploadProgress ? (progressEvent) => {
        const percentage = Math.round((progressEvent.loaded * 100) / progressEvent.total);
        onUploadProgress(percentage);
      } : null,
    });

    return response.data;
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
};

/**
 * Handle file selection and upload.
 * 
 * @param {Event} event - The file input change event.
 * @param {String} uploadUrl - The server URL for uploading files.
 * @param {Function} onSuccess - A callback function triggered upon successful upload.
 * @param {Function} onError - A callback function triggered upon upload failure.
 * @param {Function} [onUploadProgress] - A callback to track the progress (optional).
 * @returns {Promise<void>}
 */
export const handleFileSelectionAndUpload = async (event, uploadUrl, onSuccess, onError, onUploadProgress) => {
  const file = event.target.files[0];

  if (file) {
    try {
      const uploadedData = await uploadFile(file, uploadUrl, {}, onUploadProgress);
      onSuccess(uploadedData);
    } catch (error) {
      onError(error);
    }
  } else {
    console.error('No file selected for upload');
  }
};
