import React, { useState } from 'react';
import './AccountSettingsPage.module.css';

const AccountSettingsPage = () => {
  const [email, setEmail] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [notifications, setNotifications] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (newPassword && newPassword !== confirmPassword) {
      setError('New password and confirm password do not match');
      return;
    }

    setIsSubmitting(true);
    try {
      const settingsData = {
        email,
        currentPassword,
        newPassword,
        notifications,
      };

      await fetch('/api/account-settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(settingsData),
      });

      setError('');
      alert('Settings updated successfully');
    } catch (err) {
      setError('Failed to update account settings');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="account-settings-page">
      <h1>Account Settings</h1>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <label htmlFor="currentPassword">Current Password</label>
        <input
          type="password"
          id="currentPassword"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          required
        />

        <label htmlFor="newPassword">New Password</label>
        <input
          type="password"
          id="newPassword"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />

        <label htmlFor="confirmPassword">Confirm New Password</label>
        <input
          type="password"
          id="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />

        <label htmlFor="notifications">Email Notifications</label>
        <input
          type="checkbox"
          id="notifications"
          checked={notifications}
          onChange={(e) => setNotifications(e.target.checked)}
        />

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Updating...' : 'Update Settings'}
        </button>
      </form>
    </div>
  );
};

export default AccountSettingsPage;
 
