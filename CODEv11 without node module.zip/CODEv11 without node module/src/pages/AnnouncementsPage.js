import React, { useState, useEffect } from 'react';
import './AnnouncementsPage.module.css';

const AnnouncementsPage = () => {
  const [announcements, setAnnouncements] = useState([]);
  const [filteredAnnouncements, setFilteredAnnouncements] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [announcementsPerPage] = useState(5);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchAnnouncements = async () => {
      try {
        const response = await fetch('/api/announcements');
        const data = await response.json();
        setAnnouncements(data);
        setFilteredAnnouncements(data);
      } catch (err) {
        setError('Failed to load announcements.');
      }
    };

    fetchAnnouncements();
  }, []);

  useEffect(() => {
    let filtered = announcements;

    if (category !== 'all') {
      filtered = filtered.filter(announcement => announcement.category === category);
    }

    if (searchTerm) {
      filtered = filtered.filter(announcement =>
        announcement.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredAnnouncements(filtered);
    setCurrentPage(1); // Reset to first page when filters change
  }, [searchTerm, category, announcements]);

  const indexOfLastAnnouncement = currentPage * announcementsPerPage;
  const indexOfFirstAnnouncement = indexOfLastAnnouncement - announcementsPerPage;
  const currentAnnouncements = filteredAnnouncements.slice(indexOfFirstAnnouncement, indexOfLastAnnouncement);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="announcements-page">
      <h1>Platform Announcements</h1>
      {error && <p className="error-message">{error}</p>}

      <div className="filters">
        <input
          type="text"
          placeholder="Search announcements..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          aria-label="Search announcements"
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
          <option value="all">All Categories</option>
          <option value="update">Updates</option>
          <option value="event">Events</option>
          <option value="feature">Features</option>
        </select>
      </div>

      <ul className="announcement-list">
        {currentAnnouncements.map((announcement) => (
          <li key={announcement.id}>
            <div className="announcement-card">
              <h3>{announcement.title}</h3>
              <p>{announcement.description}</p>
              <span>{announcement.date}</span>
            </div>
          </li>
        ))}
      </ul>

      <div className="pagination">
        {Array.from({ length: Math.ceil(filteredAnnouncements.length / announcementsPerPage) }, (_, i) => (
          <button key={i + 1} onClick={() => paginate(i + 1)} className={currentPage === i + 1 ? 'active' : ''}>
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default AnnouncementsPage;
 
