import React from 'react';
import { useLocation } from 'react-router-dom';
import './ErrorPage.module.css';

const ErrorPage = () => {
  const location = useLocation();
  const errorCode = location.state?.errorCode || 404;

  const getErrorMessage = () => {
    switch (errorCode) {
      case 404:
        return "Page not found";
      case 500:
        return "Internal server error";
      default:
        return "An unexpected error occurred";
    }
  };

  return (
    <div className="error-page">
      <h1>Error {errorCode}</h1>
      <p>{getErrorMessage()}</p>
      <a href="/" className="button">Go to Home</a>
    </div>
  );
};

export default ErrorPage;
 
