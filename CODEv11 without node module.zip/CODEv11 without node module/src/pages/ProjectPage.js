import React, { useState, useEffect } from 'react';
import './ProjectPage.module.css';

const ProjectPage = ({ projectId }) => {
  const [project, setProject] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProject = async () => {
      try {
        const response = await fetch(`/api/projects/${projectId}`);
        if (!response.ok) throw new Error('Failed to fetch project');
        const data = await response.json();
        setProject(data);
      } catch (err) {
        setError('Unable to load project details.');
      }
    };

    fetchProject();
  }, [projectId]);

  if (error) {
    return <p>{error}</p>;
  }

  if (!project) {
    return <p>Loading project...</p>;
  }

  return (
    <div className="project-page">
      <h1>{project.name}</h1>
      <p>{project.description}</p>

      <section className="contributors">
        <h2>Contributors</h2>
        <ul>
          {project.contributors.map((contributor) => (
            <li key={contributor.id}>{contributor.name}</li>
          ))}
        </ul>
      </section>

      <section className="resources">
        <h2>Resources</h2>
        <ul>
          {project.resources.map((resource) => (
            <li key={resource.id}>
              <a href={resource.url} target="_blank" rel="noopener noreferrer">
                {resource.name}
              </a>
            </li>
          ))}
        </ul>
      </section>

      <section className="updates">
        <h2>Project Updates</h2>
        <ul>
          {project.updates.map((update) => (
            <li key={update.id}>
              <h3>{update.title}</h3>
              <p>{update.description}</p>
              <p>{new Date(update.date).toLocaleDateString()}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default ProjectPage;
 
