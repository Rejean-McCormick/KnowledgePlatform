import React from 'react';
import './PrivacyPage.module.css';

const PrivacyPage = () => {
  return (
    <div className="privacy-page">
      <h1>Privacy Policy</h1>
      <section className="privacy-text">
        <p>
          Your privacy is important to us. This privacy policy explains how we collect, use, and share your personal information when you use our platform.
        </p>
        <h2>1. Information We Collect</h2>
        <p>
          We collect information that you provide to us directly, such as when you create an account, submit content, or communicate with us.
        </p>
        <h2>2. How We Use Your Information</h2>
        <p>
          We use your information to provide and improve our services, personalize your experience, and communicate with you.
        </p>
        <h2>3. Sharing of Information</h2>
        <p>
          We do not share your personal information with third parties except as necessary to provide our services, comply with the law, or protect our rights.
        </p>
        <h2>4. Data Security</h2>
        <p>
          We take reasonable measures to protect your information from unauthorized access, but no security measure is completely secure.
        </p>
        <h2>5. Your Rights</h2>
        <p>
          You have the right to access, correct, or delete your personal information. You can manage your privacy settings in your account.
        </p>
        <p>
          For the full privacy policy, please download the PDF below.
        </p>
      </section>

      <div className="download-privacy">
        <a href="/privacy.pdf" download="privacy_policy.pdf" className="download-button">
          Download Privacy Policy as PDF
        </a>
      </div>
    </div>
  );
};

export default PrivacyPage;
 
