import React, { useState, useEffect } from 'react';
import './ResourcesPage.module.css';

const ResourcesPage = () => {
  const [resources, setResources] = useState([]);
  const [filteredResources, setFilteredResources] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState('all');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchResources = async () => {
      try {
        const response = await fetch('/api/resources');
        const data = await response.json();
        setResources(data);
        setFilteredResources(data);
      } catch (err) {
        setError('Failed to load resources.');
      }
    };

    fetchResources();
  }, []);

  useEffect(() => {
    let filtered = resources;

    if (category !== 'all') {
      filtered = filtered.filter(resource => resource.category === category);
    }

    if (searchTerm) {
      filtered = filtered.filter(resource =>
        resource.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredResources(filtered);
  }, [searchTerm, category, resources]);

  return (
    <div className="resources-page">
      <h1>Educational Resources</h1>
      {error && <p className="error-message">{error}</p>}

      <div className="filters">
        <input
          type="text"
          placeholder="Search resources..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          aria-label="Search resources"
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
          <option value="all">All Categories</option>
          <option value="technology">Technology</option>
          <option value="science">Science</option>
          <option value="math">Math</option>
          <option value="history">History</option>
        </select>
      </div>

      <ul className="resource-list">
        {filteredResources.map((resource) => (
          <li key={resource.id}>
            <h3>{resource.title}</h3>
            <p>{resource.description}</p>
            <a href={resource.link} target="_blank" rel="noopener noreferrer">
              Access Resource
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ResourcesPage;
 
