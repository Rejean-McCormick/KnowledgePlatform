import React, { useState, useEffect } from 'react';
import './TestimonialsPage.module.css';

const TestimonialsPage = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [newTestimonial, setNewTestimonial] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [testimonialsPerPage] = useState(5);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        const response = await fetch('/api/testimonials');
        const data = await response.json();
        setTestimonials(data);
      } catch (err) {
        setError('Failed to load testimonials.');
      }
    };

    fetchTestimonials();
  }, []);

  const handleSubmitTestimonial = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/testimonials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newTestimonial }),
      });
      const newEntry = await response.json();
      setTestimonials([newEntry, ...testimonials]);
      setNewTestimonial('');
    } catch (err) {
      setError('Failed to submit testimonial.');
    }
  };

  const indexOfLastTestimonial = currentPage * testimonialsPerPage;
  const indexOfFirstTestimonial = indexOfLastTestimonial - testimonialsPerPage;
  const currentTestimonials = testimonials.slice(indexOfFirstTestimonial, indexOfLastTestimonial);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="testimonials-page">
      <h1>User Testimonials</h1>
      {error && <p className="error-message">{error}</p>}

      <form onSubmit={handleSubmitTestimonial} className="testimonial-form">
        <textarea
          value={newTestimonial}
          onChange={(e) => setNewTestimonial(e.target.value)}
          placeholder="Write your testimonial here..."
          required
          aria-label="New testimonial"
        />
        <button type="submit">Submit Testimonial</button>
      </form>

      <ul className="testimonial-list">
        {currentTestimonials.map((testimonial) => (
          <li key={testimonial.id}>
            <div className="testimonial-card">
              <p>{testimonial.content}</p>
              <span>{testimonial.date}</span>
            </div>
          </li>
        ))}
      </ul>

      <div className="pagination">
        {Array.from({ length: Math.ceil(testimonials.length / testimonialsPerPage) }, (_, i) => (
          <button key={i + 1} onClick={() => paginate(i + 1)} className={currentPage === i + 1 ? 'active' : ''}>
            {i + 1}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TestimonialsPage;
 
