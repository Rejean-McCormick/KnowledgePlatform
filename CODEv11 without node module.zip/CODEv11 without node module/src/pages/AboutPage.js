import React from 'react';
import './AboutPage.module.css';

const AboutPage = () => {
  const teamMembers = [
    { id: 1, name: 'John Doe', role: 'Founder & CEO', bio: 'John is passionate about knowledge sharing and technology.' },
    { id: 2, name: 'Jane Smith', role: 'CTO', bio: 'Jane leads the tech team and drives platform innovation.' },
    { id: 3, name: 'Sam Wilson', role: 'Head of Community', bio: 'Sam ensures the community is thriving and engaged.' },
  ];

  return (
    <div className="about-page">
      <h1>About Us</h1>
      <section className="mission">
        <h2>Our Mission</h2>
        <p>
          Our mission is to create a centralized platform for knowledge sharing and collaboration, empowering individuals to
          connect and contribute to a global community of learners and innovators.
        </p>
      </section>

      <section className="goals">
        <h2>Our Goals</h2>
        <ul>
          <li>Facilitate access to high-quality resources and discussions</li>
          <li>Empower users to share their knowledge and ideas</li>
          <li>Create a collaborative environment for project development</li>
        </ul>
      </section>

      <section className="team">
        <h2>Meet Our Team</h2>
        <ul className="team-list">
          {teamMembers.map((member) => (
            <li key={member.id} className="team-member">
              <h3>{member.name}</h3>
              <p>{member.role}</p>
              <p>{member.bio}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default AboutPage;
 
