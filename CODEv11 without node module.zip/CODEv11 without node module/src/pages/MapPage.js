import React, { useState, useEffect } from 'react';
import './MapPage.module.css';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

const MapPage = () => {
  const [mapData, setMapData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMapData = async () => {
      try {
        const response = await fetch('/api/map/topics');
        const data = await response.json();
        setMapData(data);
      } catch (err) {
        setError('Failed to load map data.');
      } finally {
        setLoading(false);
      }
    };

    fetchMapData();
  }, []);

  if (loading) {
    return <p>Loading map...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div className="map-page">
      <h1>Knowledge Map</h1>
      <MapContainer center={[51.505, -0.09]} zoom={2} className="map-container">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {mapData.map((topic) => (
          <Marker key={topic.id} position={[topic.latitude, topic.longitude]}>
            <Popup>
              <h3>{topic.title}</h3>
              <p>{topic.description}</p>
              <a href={`/topics/${topic.id}`}>Explore Topic</a>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default MapPage;
 
