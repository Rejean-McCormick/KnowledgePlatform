import React from 'react';
import './FeedbackConfirmationPage.module.css';

const FeedbackConfirmationPage = () => {
  return (
    <div className="feedback-confirmation-page">
      <h1>Thank You for Your Feedback!</h1>
      <p>Your feedback has been submitted successfully. We appreciate your input to help us improve the platform.</p>
      
      <div className="feedback-links">
        <a href="/dashboard" className="button">Back to Dashboard</a>
        <a href="/topics" className="button">Explore Topics</a>
        <a href="/submit" className="button">Submit More Feedback</a>
      </div>
    </div>
  );
};

export default FeedbackConfirmationPage;
 
