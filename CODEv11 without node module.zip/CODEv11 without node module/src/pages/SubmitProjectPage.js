import React, { useState } from 'react';
import './SubmitProjectPage.module.css';

const SubmitProjectPage = () => {
  const [projectName, setProjectName] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const allowedFileTypes = ['application/pdf', 'image/jpeg', 'image/png'];
  const maxFileSizeInMB = 10;

  const isValidFileType = (file, allowedFileTypes) => {
    return allowedFileTypes.includes(file.type);
  };

  const isFileSizeValid = (file, maxFileSizeInMB) => {
    const maxSizeInBytes = maxFileSizeInMB * 1024 * 1024;
    return file.size <= maxSizeInBytes;
  };

  const handleFileUpload = async (file, uploadUrl) => {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(uploadUrl, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('File upload failed');
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!projectName || !description) {
      setError('Project name and description are required');
      return;
    }

    if (file) {
      if (!isValidFileType(file, allowedFileTypes)) {
        setError('Invalid file type');
        return;
      }

      if (!isFileSizeValid(file, maxFileSizeInMB)) {
        setError(`File size exceeds the limit of ${maxFileSizeInMB}MB`);
        return;
      }
    }

    setIsSubmitting(true);
    try {
      if (file) {
        await handleFileUpload(file, '/api/upload');
      }

      const projectData = {
        projectName,
        description,
      };

      await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(projectData),
      });

      setError('');
      alert('Project submitted successfully');
    } catch (err) {
      setError('Submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  return (
    <div className="submit-project-page">
      <h1>Submit a Collaboration Project</h1>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label htmlFor="projectName">Project Name</label>
        <input
          type="text"
          id="projectName"
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
          required
        />

        <label htmlFor="description">Description</label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />

        <label htmlFor="file">Upload File (optional)</label>
        <input type="file" id="file" onChange={handleFileChange} />

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Submitting...' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default SubmitProjectPage;
