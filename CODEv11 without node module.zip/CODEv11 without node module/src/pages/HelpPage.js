import React, { useState, useEffect } from 'react';
import './HelpPage.module.css';
import SearchBar from '../components/SearchBar';


const HelpPage = () => {
  const [faqs, setFaqs] = useState([]);
  const [filteredFaqs, setFilteredFaqs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchFaqs = async () => {
      const response = await fetch('/api/faqs');
      const data = await response.json();
      setFaqs(data);
      setFilteredFaqs(data);
    };
    fetchFaqs();
  }, []);

  const handleSearch = (term) => {
    setSearchTerm(term);
    const filtered = faqs.filter((faq) =>
      faq.question.toLowerCase().includes(term.toLowerCase())
    );
    setFilteredFaqs(filtered);
  };

  return (
    <div className="help-page">
      <h1>Help & User Guide</h1>
      <SearchBar onSearch={handleSearch} />
      
      <section className="user-guide">
        <h2>User Guide</h2>
        <p>Welcome to the Knowledge Platform! This guide will help you navigate through the platform.</p>
        <ul>
          <li>Creating an account</li>
          <li>How to participate in discussions</li>
          <li>Submitting content and articles</li>
          <li>Managing your profile and settings</li>
        </ul>
      </section>

      <section className="faq">
        <h2>Frequently Asked Questions (FAQs)</h2>
        <ul>
          {filteredFaqs.map((faq) => (
            <li key={faq.id}>
              <h3>{faq.question}</h3>
              <p>{faq.answer}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default HelpPage;
 
