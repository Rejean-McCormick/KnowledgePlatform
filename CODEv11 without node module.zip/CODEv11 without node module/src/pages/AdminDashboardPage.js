import React, { useState, useEffect } from 'react';
import './AdminDashboardPage.module.css';
import Sidebar from '../components/Sidebar';

const AdminDashboardPage = () => {
  const [users, setUsers] = useState([]);
  const [content, setContent] = useState([]);
  const [settings, setSettings] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchAdminData = async () => {
      try {
        const usersResponse = await fetch('/api/admin/users');
        const contentResponse = await fetch('/api/admin/content');
        const settingsResponse = await fetch('/api/admin/settings');

        if (!usersResponse.ok || !contentResponse.ok || !settingsResponse.ok) {
          throw new Error('Failed to fetch admin data');
        }

        const usersData = await usersResponse.json();
        const contentData = await contentResponse.json();
        const settingsData = await settingsResponse.json();

        setUsers(usersData);
        setContent(contentData);
        setSettings(settingsData);
      } catch (err) {
        setError('Unable to load admin data.');
      }
    };

    fetchAdminData();
  }, []);

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div className="admin-dashboard-page">
      <Sidebar />
      <main className="admin-main">
        <h1>Admin Dashboard</h1>
        
        <section className="admin-section">
          <h2>Manage Users</h2>
          <ul>
            {users.map((user) => (
              <li key={user.id}>{user.name} - {user.role}</li>
            ))}
          </ul>
        </section>

        <section className="admin-section">
          <h2>Manage Content</h2>
          <ul>
            {content.map((item) => (
              <li key={item.id}>{item.title} - {item.status}</li>
            ))}
          </ul>
        </section>

        <section className="admin-section">
          <h2>Platform Settings</h2>
          <p>Current theme: {settings.theme}</p>
          <p>Allow registrations: {settings.allowRegistrations ? 'Yes' : 'No'}</p>
        </section>
      </main>
    </div>
  );
};

export default AdminDashboardPage;
 
