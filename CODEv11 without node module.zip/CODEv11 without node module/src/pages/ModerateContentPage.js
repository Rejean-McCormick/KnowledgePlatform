import React, { useState, useEffect } from 'react';
import './ModerateContentPage.module.css';

const ModerateContentPage = () => {
  const [contentQueue, setContentQueue] = useState([]);
  const [selectedContent, setSelectedContent] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchContentQueue = async () => {
      try {
        const response = await fetch('/api/moderation/content');
        const data = await response.json();
        setContentQueue(data);
      } catch (err) {
        setError('Failed to load content queue.');
      }
    };
    fetchContentQueue();

    const interval = setInterval(fetchContentQueue, 5000); // Real-time updates every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const handleApprove = async (contentId) => {
    try {
      await fetch(`/api/moderation/content/${contentId}/approve`, { method: 'POST' });
      setContentQueue(contentQueue.filter((item) => item.id !== contentId));
      setSelectedContent(null);
    } catch (err) {
      setError('Failed to approve content.');
    }
  };

  const handleReject = async (contentId) => {
    try {
      await fetch(`/api/moderation/content/${contentId}/reject`, { method: 'POST' });
      setContentQueue(contentQueue.filter((item) => item.id !== contentId));
      setSelectedContent(null);
    } catch (err) {
      setError('Failed to reject content.');
    }
  };

  return (
    <div className="moderate-content-page">
      <h1>Moderate Content</h1>
      {error && <p className="error-message">{error}</p>}
      <ul className="content-queue">
        {contentQueue.map((content) => (
          <li key={content.id}>
            <span>{content.title}</span>
            <button onClick={() => setSelectedContent(content)}>Review</button>
          </li>
        ))}
      </ul>

      {selectedContent && (
        <div className="content-review">
          <h2>Review Content: {selectedContent.title}</h2>
          <p>{selectedContent.body}</p>
          <button onClick={() => handleApprove(selectedContent.id)}>Approve</button>
          <button onClick={() => handleReject(selectedContent.id)}>Reject</button>
          <button onClick={() => setSelectedContent(null)}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default ModerateContentPage;
 
