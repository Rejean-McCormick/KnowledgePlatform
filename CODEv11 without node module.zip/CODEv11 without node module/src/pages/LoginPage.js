import React, { useState } from 'react';
import './LoginPage.module.css';
import { useAuth } from '../contexts/authContext';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { handleLogin } = useAuth();  // Corrected function name

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Username and password are required.');
      return;
    }
    
    try {
      // Replace this with your authentication logic
      const token = await fakeLoginApi(username, password);  // Simulate getting a token
      handleLogin(token);  // Use handleLogin from context
    } catch (err) {
      setError('Invalid username or password.');
    }
  };

  return (
    <div className="login-page">
      <h1>Login</h1>
      {error && <p className="error-message">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            aria-required="true"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            aria-required="true"
          />
        </div>
        <button type="submit" className="button">Login</button>
      </form>
    </div>
  );
};

// Simulate an API login response, replace this with actual API call
const fakeLoginApi = (username, password) => {
  return new Promise((resolve, reject) => {
    if (username === "admin" && password === "password") {
      resolve("fake-jwt-token");
    } else {
      reject("Invalid credentials");
    }
  });
};

export default LoginPage;
