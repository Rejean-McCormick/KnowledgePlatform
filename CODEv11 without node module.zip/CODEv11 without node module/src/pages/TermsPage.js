import React from 'react';
import './TermsPage.module.css';

const TermsPage = () => {
  return (
    <div className="terms-page">
      <h1>Terms and Conditions</h1>
      <section className="terms-text">
        <p>
          Welcome to the Knowledge Platform. By accessing and using our platform, you agree to comply with the following terms and conditions.
        </p>
        <h2>1. Introduction</h2>
        <p>
          These terms and conditions govern your use of the platform and all related services. By using the platform, you accept these terms in full.
        </p>
        <h2>2. User Obligations</h2>
        <p>
          You agree to provide accurate information and to comply with all applicable laws while using the platform.
        </p>
        <h2>3. Content Submission</h2>
        <p>
          Users may submit content to the platform, but the platform reserves the right to review and remove any content that violates our policies.
        </p>
        <h2>4. Limitation of Liability</h2>
        <p>
          The platform is provided "as is," and we do not guarantee its availability, accuracy, or reliability. We are not liable for any damages resulting from the use of the platform.
        </p>
        <h2>5. Governing Law</h2>
        <p>
          These terms and conditions are governed by the laws of your jurisdiction.
        </p>
        <p>
          For the full terms and conditions, please download the PDF below.
        </p>
      </section>

      <div className="download-terms">
        <a href="/terms.pdf" download="terms_and_conditions.pdf" className="download-button">
          Download Terms as PDF
        </a>
      </div>
    </div>
  );
};

export default TermsPage;
 
