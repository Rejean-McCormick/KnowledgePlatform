import React from 'react';
import './UserGuidePage.module.css';

const UserGuidePage = () => {
  return (
    <div className="user-guide-page">
      <h1>User Guide</h1>

      <section className="getting-started">
        <h2>Getting Started</h2>
        <ol>
          <li>
            <strong>Register an Account:</strong> Sign up on the registration page with your email and a secure password.
          </li>
          <li>
            <strong>Explore Topics:</strong> Visit the topics page to browse available discussions and resources.
          </li>
          <li>
            <strong>Contribute Content:</strong> Post articles, start discussions, and share your expertise with the community.
          </li>
        </ol>
      </section>

      <section className="faq">
        <h2>Frequently Asked Questions</h2>
        <div className="faq-item">
          <h3>How do I reset my password?</h3>
          <p>
            If you’ve forgotten your password, go to the <a href="/reset-password">password reset page</a> and follow the instructions to reset it.
          </p>
        </div>
        <div className="faq-item">
          <h3>How do I submit new content?</h3>
          <p>
            Navigate to the <a href="/submit">Submit Content</a> page and fill out the form with your article or research.
          </p>
        </div>
        <div className="faq-item">
          <h3>How do I change my profile settings?</h3>
          <p>
            Visit the <a href="/account-settings">Account Settings</a> page to update your profile, email, and other preferences.
          </p>
        </div>
      </section>

      <section className="more-info">
        <h2>More Information</h2>
        <p>
          For further details on how to use the platform, please refer to the detailed user manual available for download: <a href="/user-guide.pdf" download>Download User Guide (PDF)</a>.
        </p>
      </section>

    </div>
  );
};

export default UserGuidePage;
 
