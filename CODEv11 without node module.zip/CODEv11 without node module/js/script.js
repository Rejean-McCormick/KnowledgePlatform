// Since React handles most of the rendering logic, this script will focus only on non-React related tasks.

// Global configuration for paths
const API_BASE_URL = '/api/v1'; // Base API URL
const WEBSOCKET_URL = 'ws://your-websocket-url.com/realtime'; // WebSocket URL (update accordingly)

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function () {
    // Mobile Navigation Toggle (if you still need it outside React components)
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.navigation');
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }

    // Fetch and dynamically load topics (ideally, this logic should move to React components)
    const topicsContainer = document.querySelector('.topics-list');
    if (topicsContainer) {
        loadTopics();
    }

    async function loadTopics() {
        try {
            const response = await fetch(`${API_BASE_URL}/topics`);
            if (!response.ok) throw new Error('Failed to load topics');
            const topics = await response.json();
            renderTopics(topics);
        } catch (error) {
            console.error('Error loading topics:', error);
        }
    }

    function renderTopics(topics) {
        topicsContainer.innerHTML = ''; // Clear existing content
        topics.forEach(topic => {
            const topicCard = document.createElement('div');
            topicCard.classList.add('topic-card');
            topicCard.innerHTML = `
                <h3>${topic.title}</h3>
                <p>${topic.description}</p>
                <a href="/topics/${topic.id}">Read More</a> <!-- Ensure it matches React Router paths -->
            `;
            topicsContainer.appendChild(topicCard);
        });
    }

    // WebSocket for real-time updates
    const socket = new WebSocket(WEBSOCKET_URL);

    socket.addEventListener('message', function (event) {
        const data = JSON.parse(event.data);
        handleWebSocketMessage(data);
    });

    socket.addEventListener('open', () => {
        console.log('WebSocket connection established');
    });

    socket.addEventListener('error', (error) => {
        console.error('WebSocket error:', error);
    });

    function handleWebSocketMessage(data) {
        if (data.type === 'notification') {
            showNotification(data.message);
        } else if (data.type === 'update') {
            updateDashboardElement(data.elementId, data.newValue);
        }
    }

    function showNotification(message) {
        const notificationArea = document.querySelector('.notifications');
        if (notificationArea) {
            const notification = document.createElement('div');
            notification.classList.add('notification');
            notification.textContent = message;
            notificationArea.appendChild(notification);
        }
    }

    function updateDashboardElement(elementId, newValue) {
        const dashboardElement = document.querySelector(`#${elementId}`);
        if (dashboardElement) {
            dashboardElement.textContent = newValue;
        }
    }

    // Lazy load images (move to React components if possible)
    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    lazyImages.forEach((img) => {
        img.addEventListener('load', () => {
            img.classList.add('loaded');
        });
    });

    // Scroll-to-top button functionality
    const scrollTopBtn = document.querySelector('.scroll-to-top');
    if (scrollTopBtn) {
        window.addEventListener('scroll', () => {
            scrollTopBtn.classList.toggle('visible', window.pageYOffset > 300);
        });

        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
});
