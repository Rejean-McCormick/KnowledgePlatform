// /src/monitoring/monitoringService.js

const client = require('prom-client');
const logger = require('../utils/loggerService');

// Register Prometheus metrics
const register = new client.Registry();
client.collectDefaultMetrics({ register });

class MonitoringService {
  constructor() {
    this.apiResponseTime = new client.Histogram({
      name: 'api_response_time_seconds',
      help: 'API response time in seconds',
      labelNames: ['method', 'route', 'status_code'],
      buckets: [0.1, 0.5, 1, 1.5, 2, 5],
    });

    this.errorRate = new client.Counter({
      name: 'api_error_rate',
      help: 'Count of API errors',
      labelNames: ['method', 'route', 'status_code'],
    });

    this.userActivity = new client.Gauge({
      name: 'user_activity_count',
      help: 'Number of active users on the platform',
    });

    register.registerMetric(this.apiResponseTime);
    register.registerMetric(this.errorRate);
    register.registerMetric(this.userActivity);
  }

  /**
   * Track API response time for monitoring.
   * @param {String} method - HTTP method (GET, POST, etc.).
   * @param {String} route - The API route.
   * @param {Number} statusCode - HTTP status code.
   * @param {Number} responseTime - API response time in seconds.
   */
  trackApiResponseTime(method, route, statusCode, responseTime) {
    this.apiResponseTime
      .labels(method, route, statusCode)
      .observe(responseTime);
    logger.info(`API response time for ${route}: ${responseTime}s`);
  }

  /**
   * Track API error occurrences for monitoring.
   * @param {String} method - HTTP method.
   * @param {String} route - The API route.
   * @param {Number} statusCode - HTTP status code.
   */
  trackApiError(method, route, statusCode) {
    this.errorRate.labels(method, route, statusCode).inc();
    logger.error(`Error on ${route} with status ${statusCode}`);
  }

  /**
   * Set the current number of active users.
   * @param {Number} activeUsers - The number of active users.
   */
  trackUserActivity(activeUsers) {
    this.userActivity.set(activeUsers);
    logger.info(`Current active users: ${activeUsers}`);
  }

  /**
   * Expose Prometheus metrics for scraping.
   * @param {Object} res - The HTTP response object.
   */
  async getMetrics(res) {
    try {
      res.set('Content-Type', register.contentType);
      res.end(await register.metrics());
    } catch (error) {
      logger.error(`Failed to retrieve metrics: ${error.message}`);
      res.status(500).send('Error retrieving metrics');
    }
  }
}

module.exports = new MonitoringService();
