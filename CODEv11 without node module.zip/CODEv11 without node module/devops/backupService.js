// /devops/backupService.js

const { exec } = require('child_process');
const cron = require('node-cron');
const logger = require('../utils/loggerService');

// Backup Configuration
const backupPath = '/backups';  // Directory where backups will be stored
const databaseName = 'platform';  // Name of the database
const backupTime = '0 2 * * *';  // Schedule: Daily at 2 AM

class BackupService {
  constructor() {
    this.scheduleBackup();
  }

  /**
   * Schedules a daily backup task using cron.
   */
  scheduleBackup() {
    cron.schedule(backupTime, () => {
      this.performBackup();
    });
    logger.info('Backup service scheduled to run daily at 2 AM.');
  }

  /**
   * Performs a backup of critical data.
   * This example uses a MongoDB backup command. For PostgreSQL, replace the command accordingly.
   */
  performBackup() {
    const backupCommand = `mongodump --db ${databaseName} --out ${backupPath}/backup_$(date +\\%F)`;

    exec(backupCommand, (error, stdout, stderr) => {
      if (error) {
        logger.error(`Error performing backup: ${error.message}`);
        return;
      }

      if (stderr) {
        logger.error(`Backup stderr: ${stderr}`);
        return;
      }

      logger.info(`Backup successful: ${stdout}`);
    });
  }
}

module.exports = new BackupService();
